﻿// Decompiled with JetBrains decompiler
// Type: Jint.Engine
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Native.Argument;
using Jint.Native.Array;
using Jint.Native.Boolean;
using Jint.Native.Date;
using Jint.Native.Error;
using Jint.Native.Function;
using Jint.Native.Global;
using Jint.Native.Json;
using Jint.Native.Math;
using Jint.Native.Number;
using Jint.Native.Object;
using Jint.Native.RegExp;
using Jint.Native.String;
using Jint.Parser;
using Jint.Parser.Ast;
using Jint.Runtime;
using Jint.Runtime.CallStack;
using Jint.Runtime.Debugger;
using Jint.Runtime.Descriptors;
using Jint.Runtime.Environments;
using Jint.Runtime.Interop;
using Jint.Runtime.References;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

#nullable disable
namespace Jint
{
  public class Engine
  {
    private readonly ExpressionInterpreter _expressions;
    private readonly StatementInterpreter _statements;
    private readonly Stack<ExecutionContext> _executionContexts;
    private JsValue _completionValue = JsValue.Undefined;
    private int _statementsCount;
    private long _timeoutTicks;
    private SyntaxNode _lastSyntaxNode;
    public ITypeConverter ClrTypeConverter;
    internal Dictionary<string, Type> TypeCache = new Dictionary<string, Type>();
    internal static Dictionary<Type, Func<Engine, object, JsValue>> TypeMappers = new Dictionary<Type, Func<Engine, object, JsValue>>()
    {
      {
        typeof (bool),
        (Func<Engine, object, JsValue>) ((engine, v) => new JsValue((bool) v))
      },
      {
        typeof (byte),
        (Func<Engine, object, JsValue>) ((engine, v) => new JsValue((double) (byte) v))
      },
      {
        typeof (char),
        (Func<Engine, object, JsValue>) ((engine, v) => new JsValue((double) (char) v))
      },
      {
        typeof (DateTime),
        (Func<Engine, object, JsValue>) ((engine, v) => (JsValue) (ObjectInstance) engine.Date.Construct((DateTime) v))
      },
      {
        typeof (DateTimeOffset),
        (Func<Engine, object, JsValue>) ((engine, v) => (JsValue) (ObjectInstance) engine.Date.Construct((DateTimeOffset) v))
      },
      {
        typeof (Decimal),
        (Func<Engine, object, JsValue>) ((engine, v) => new JsValue((double) (Decimal) v))
      },
      {
        typeof (double),
        (Func<Engine, object, JsValue>) ((engine, v) => new JsValue((double) v))
      },
      {
        typeof (short),
        (Func<Engine, object, JsValue>) ((engine, v) => new JsValue((double) (short) v))
      },
      {
        typeof (int),
        (Func<Engine, object, JsValue>) ((engine, v) => new JsValue((double) (int) v))
      },
      {
        typeof (long),
        (Func<Engine, object, JsValue>) ((engine, v) => new JsValue((double) (long) v))
      },
      {
        typeof (sbyte),
        (Func<Engine, object, JsValue>) ((engine, v) => new JsValue((double) (sbyte) v))
      },
      {
        typeof (float),
        (Func<Engine, object, JsValue>) ((engine, v) => new JsValue((double) (float) v))
      },
      {
        typeof (string),
        (Func<Engine, object, JsValue>) ((engine, v) => new JsValue((string) v))
      },
      {
        typeof (ushort),
        (Func<Engine, object, JsValue>) ((engine, v) => new JsValue((double) (ushort) v))
      },
      {
        typeof (uint),
        (Func<Engine, object, JsValue>) ((engine, v) => new JsValue((double) (uint) v))
      },
      {
        typeof (ulong),
        (Func<Engine, object, JsValue>) ((engine, v) => new JsValue((double) (ulong) v))
      },
      {
        typeof (JsValue),
        (Func<Engine, object, JsValue>) ((engine, v) => (JsValue) v)
      },
      {
        typeof (Regex),
        (Func<Engine, object, JsValue>) ((engine, v) => (JsValue) (ObjectInstance) engine.RegExp.Construct(((Regex) v).ToString().Trim('/')))
      }
    };
    internal JintCallStack CallStack = new JintCallStack();
    public LexicalEnvironment GlobalEnvironment;

    public Engine()
      : this((Action<Options>) null)
    {
    }

    public Engine(Action<Options> options)
    {
      this._executionContexts = new Stack<ExecutionContext>();
      this.Global = GlobalObject.CreateGlobalObject(this);
      this.Object = ObjectConstructor.CreateObjectConstructor(this);
      this.Function = FunctionConstructor.CreateFunctionConstructor(this);
      this.Array = ArrayConstructor.CreateArrayConstructor(this);
      this.String = StringConstructor.CreateStringConstructor(this);
      this.RegExp = RegExpConstructor.CreateRegExpConstructor(this);
      this.Number = NumberConstructor.CreateNumberConstructor(this);
      this.Boolean = BooleanConstructor.CreateBooleanConstructor(this);
      this.Date = DateConstructor.CreateDateConstructor(this);
      this.Math = MathInstance.CreateMathObject(this);
      this.Json = JsonInstance.CreateJsonObject(this);
      this.Error = ErrorConstructor.CreateErrorConstructor(this, nameof (Error));
      this.EvalError = ErrorConstructor.CreateErrorConstructor(this, nameof (EvalError));
      this.RangeError = ErrorConstructor.CreateErrorConstructor(this, nameof (RangeError));
      this.ReferenceError = ErrorConstructor.CreateErrorConstructor(this, nameof (ReferenceError));
      this.SyntaxError = ErrorConstructor.CreateErrorConstructor(this, nameof (SyntaxError));
      this.TypeError = ErrorConstructor.CreateErrorConstructor(this, nameof (TypeError));
      this.UriError = ErrorConstructor.CreateErrorConstructor(this, "URIError");
      this.Global.Configure();
      this.Object.Configure();
      this.Object.PrototypeObject.Configure();
      this.Function.Configure();
      this.Function.PrototypeObject.Configure();
      this.Array.Configure();
      this.Array.PrototypeObject.Configure();
      this.String.Configure();
      this.String.PrototypeObject.Configure();
      this.RegExp.Configure();
      this.RegExp.PrototypeObject.Configure();
      this.Number.Configure();
      this.Number.PrototypeObject.Configure();
      this.Boolean.Configure();
      this.Boolean.PrototypeObject.Configure();
      this.Date.Configure();
      this.Date.PrototypeObject.Configure();
      this.Math.Configure();
      this.Json.Configure();
      this.Error.Configure();
      this.Error.PrototypeObject.Configure();
      this.GlobalEnvironment = LexicalEnvironment.NewObjectEnvironment(this, (ObjectInstance) this.Global, (LexicalEnvironment) null, false);
      this.EnterExecutionContext(this.GlobalEnvironment, this.GlobalEnvironment, (JsValue) (ObjectInstance) this.Global);
      this.Options = new Options();
      if (options != null)
        options(this.Options);
      this.Eval = new EvalFunctionInstance(this, new string[0], LexicalEnvironment.NewDeclarativeEnvironment(this, this.ExecutionContext.LexicalEnvironment), StrictModeScope.IsStrictModeCode);
      this.Global.FastAddProperty("eval", (JsValue) (ObjectInstance) this.Eval, true, false, true);
      this._statements = new StatementInterpreter(this);
      this._expressions = new ExpressionInterpreter(this);
      if (this.Options._IsClrAllowed)
      {
        this.Global.FastAddProperty("System", (JsValue) (ObjectInstance) new NamespaceReference(this, "System"), false, false, false);
        this.Global.FastAddProperty("importNamespace", (JsValue) (ObjectInstance) new ClrFunctionInstance(this, (Func<JsValue, JsValue[], JsValue>) ((thisObj, arguments) => (JsValue) (ObjectInstance) new NamespaceReference(this, TypeConverter.ToString(arguments.At(0))))), false, false, false);
      }
      this.ClrTypeConverter = (ITypeConverter) new DefaultTypeConverter(this);
      this.BreakPoints = new List<BreakPoint>();
      this.DebugHandler = new DebugHandler(this);
    }

    public GlobalObject Global { get; private set; }

    public ObjectConstructor Object { get; private set; }

    public FunctionConstructor Function { get; private set; }

    public ArrayConstructor Array { get; private set; }

    public StringConstructor String { get; private set; }

    public RegExpConstructor RegExp { get; private set; }

    public BooleanConstructor Boolean { get; private set; }

    public NumberConstructor Number { get; private set; }

    public DateConstructor Date { get; private set; }

    public MathInstance Math { get; private set; }

    public JsonInstance Json { get; private set; }

    public EvalFunctionInstance Eval { get; private set; }

    public ErrorConstructor Error { get; private set; }

    public ErrorConstructor EvalError { get; private set; }

    public ErrorConstructor SyntaxError { get; private set; }

    public ErrorConstructor TypeError { get; private set; }

    public ErrorConstructor RangeError { get; private set; }

    public ErrorConstructor ReferenceError { get; private set; }

    public ErrorConstructor UriError { get; private set; }

    public ExecutionContext ExecutionContext => this._executionContexts.Peek();

    internal Options Options { get; private set; }

    public event Engine.DebugStepDelegate Step;

    public event Engine.BreakDelegate Break;

    internal DebugHandler DebugHandler { get; private set; }

    public List<BreakPoint> BreakPoints { get; private set; }

    internal StepMode? InvokeStepEvent(DebugInformation info)
    {
      return this.Step != null ? new StepMode?(this.Step((object) this, info)) : new StepMode?();
    }

    internal StepMode? InvokeBreakEvent(DebugInformation info)
    {
      return this.Break != null ? new StepMode?(this.Break((object) this, info)) : new StepMode?();
    }

    public ExecutionContext EnterExecutionContext(
      LexicalEnvironment lexicalEnvironment,
      LexicalEnvironment variableEnvironment,
      JsValue thisBinding)
    {
      ExecutionContext executionContext = new ExecutionContext()
      {
        LexicalEnvironment = lexicalEnvironment,
        VariableEnvironment = variableEnvironment,
        ThisBinding = thisBinding
      };
      this._executionContexts.Push(executionContext);
      return executionContext;
    }

    public Engine SetValue(string name, Delegate value)
    {
      this.Global.FastAddProperty(name, (JsValue) (ObjectInstance) new DelegateWrapper(this, value), true, false, true);
      return this;
    }

    public Engine SetValue(string name, string value) => this.SetValue(name, new JsValue(value));

    public Engine SetValue(string name, double value) => this.SetValue(name, new JsValue(value));

    public Engine SetValue(string name, bool value) => this.SetValue(name, new JsValue(value));

    public Engine SetValue(string name, JsValue value)
    {
      this.Global.Put(name, value, false);
      return this;
    }

    public Engine SetValue(string name, object obj)
    {
      return this.SetValue(name, JsValue.FromObject(this, obj));
    }

    public void LeaveExecutionContext() => this._executionContexts.Pop();

    public void ResetStatementsCount() => this._statementsCount = 0;

    public void ResetTimeoutTicks()
    {
      long ticks = this.Options._TimeoutInterval.Ticks;
      this._timeoutTicks = ticks > 0L ? DateTime.UtcNow.Ticks + ticks : 0L;
    }

    public void ResetCallStack() => this.CallStack.Clear();

    public Engine Execute(string source) => this.Execute(new JavaScriptParser().Parse(source));

    public Engine Execute(string source, ParserOptions parserOptions)
    {
      return this.Execute(new JavaScriptParser().Parse(source, parserOptions));
    }

    public Engine Execute(Program program)
    {
      this.ResetStatementsCount();
      this.ResetTimeoutTicks();
      this.ResetLastStatement();
      this.ResetCallStack();
      using (new StrictModeScope(this.Options._IsStrict || program.Strict))
      {
        this.DeclarationBindingInstantiation(DeclarationBindingType.GlobalCode, program.FunctionDeclarations, program.VariableDeclarations, (FunctionInstance) null, (JsValue[]) null);
        Completion completion = this._statements.ExecuteProgram(program);
        if (completion.Type == Completion.Throw)
          throw new JavaScriptException(completion.GetValueOrDefault()).SetCallstack(this, completion.Location);
        this._completionValue = completion.GetValueOrDefault();
      }
      return this;
    }

    private void ResetLastStatement() => this._lastSyntaxNode = (SyntaxNode) null;

    public JsValue GetCompletionValue() => this._completionValue;

    public Completion ExecuteStatement(Statement statement)
    {
      int maxStatements = this.Options._MaxStatements;
      if (maxStatements > 0 && this._statementsCount++ > maxStatements)
        throw new StatementsCountOverflowException();
      if (this._timeoutTicks > 0L && this._timeoutTicks < DateTime.UtcNow.Ticks)
        throw new TimeoutException();
      this._lastSyntaxNode = (SyntaxNode) statement;
      if (this.Options._IsDebugMode)
        this.DebugHandler.OnStep(statement);
      switch (statement.Type)
      {
        case SyntaxNodes.BlockStatement:
          return this._statements.ExecuteBlockStatement(statement.As<BlockStatement>());
        case SyntaxNodes.BreakStatement:
          return this._statements.ExecuteBreakStatement(statement.As<BreakStatement>());
        case SyntaxNodes.ContinueStatement:
          return this._statements.ExecuteContinueStatement(statement.As<ContinueStatement>());
        case SyntaxNodes.DoWhileStatement:
          return this._statements.ExecuteDoWhileStatement(statement.As<DoWhileStatement>());
        case SyntaxNodes.DebuggerStatement:
          return this._statements.ExecuteDebuggerStatement(statement.As<DebuggerStatement>());
        case SyntaxNodes.EmptyStatement:
          return this._statements.ExecuteEmptyStatement(statement.As<EmptyStatement>());
        case SyntaxNodes.ExpressionStatement:
          return this._statements.ExecuteExpressionStatement(statement.As<ExpressionStatement>());
        case SyntaxNodes.ForStatement:
          return this._statements.ExecuteForStatement(statement.As<ForStatement>());
        case SyntaxNodes.ForInStatement:
          return this._statements.ExecuteForInStatement(statement.As<ForInStatement>());
        case SyntaxNodes.FunctionDeclaration:
          return new Completion(Completion.Normal, (JsValue) null, (string) null);
        case SyntaxNodes.IfStatement:
          return this._statements.ExecuteIfStatement(statement.As<IfStatement>());
        case SyntaxNodes.LabeledStatement:
          return this._statements.ExecuteLabelledStatement(statement.As<LabelledStatement>());
        case SyntaxNodes.Program:
          return this._statements.ExecuteProgram(statement.As<Program>());
        case SyntaxNodes.ReturnStatement:
          return this._statements.ExecuteReturnStatement(statement.As<ReturnStatement>());
        case SyntaxNodes.SwitchStatement:
          return this._statements.ExecuteSwitchStatement(statement.As<SwitchStatement>());
        case SyntaxNodes.ThrowStatement:
          return this._statements.ExecuteThrowStatement(statement.As<ThrowStatement>());
        case SyntaxNodes.TryStatement:
          return this._statements.ExecuteTryStatement(statement.As<TryStatement>());
        case SyntaxNodes.VariableDeclaration:
          return this._statements.ExecuteVariableDeclaration(statement.As<VariableDeclaration>());
        case SyntaxNodes.WhileStatement:
          return this._statements.ExecuteWhileStatement(statement.As<WhileStatement>());
        case SyntaxNodes.WithStatement:
          return this._statements.ExecuteWithStatement(statement.As<WithStatement>());
        default:
          throw new ArgumentOutOfRangeException();
      }
    }

    public object EvaluateExpression(Expression expression)
    {
      this._lastSyntaxNode = (SyntaxNode) expression;
      switch (expression.Type)
      {
        case SyntaxNodes.AssignmentExpression:
          return (object) this._expressions.EvaluateAssignmentExpression(expression.As<AssignmentExpression>());
        case SyntaxNodes.ArrayExpression:
          return (object) this._expressions.EvaluateArrayExpression(expression.As<ArrayExpression>());
        case SyntaxNodes.BinaryExpression:
          return (object) this._expressions.EvaluateBinaryExpression(expression.As<BinaryExpression>());
        case SyntaxNodes.CallExpression:
          return (object) this._expressions.EvaluateCallExpression(expression.As<CallExpression>());
        case SyntaxNodes.ConditionalExpression:
          return (object) this._expressions.EvaluateConditionalExpression(expression.As<ConditionalExpression>());
        case SyntaxNodes.FunctionExpression:
          return (object) this._expressions.EvaluateFunctionExpression(expression.As<FunctionExpression>());
        case SyntaxNodes.Identifier:
          return (object) this._expressions.EvaluateIdentifier(expression.As<Identifier>());
        case SyntaxNodes.Literal:
          return (object) this._expressions.EvaluateLiteral(expression.As<Literal>());
        case SyntaxNodes.RegularExpressionLiteral:
          return (object) this._expressions.EvaluateLiteral(expression.As<Literal>());
        case SyntaxNodes.LogicalExpression:
          return (object) this._expressions.EvaluateLogicalExpression(expression.As<LogicalExpression>());
        case SyntaxNodes.MemberExpression:
          return (object) this._expressions.EvaluateMemberExpression(expression.As<MemberExpression>());
        case SyntaxNodes.NewExpression:
          return (object) this._expressions.EvaluateNewExpression(expression.As<NewExpression>());
        case SyntaxNodes.ObjectExpression:
          return (object) this._expressions.EvaluateObjectExpression(expression.As<ObjectExpression>());
        case SyntaxNodes.SequenceExpression:
          return (object) this._expressions.EvaluateSequenceExpression(expression.As<SequenceExpression>());
        case SyntaxNodes.ThisExpression:
          return (object) this._expressions.EvaluateThisExpression(expression.As<ThisExpression>());
        case SyntaxNodes.UnaryExpression:
          return (object) this._expressions.EvaluateUnaryExpression(expression.As<UnaryExpression>());
        case SyntaxNodes.UpdateExpression:
          return (object) this._expressions.EvaluateUpdateExpression(expression.As<UpdateExpression>());
        default:
          throw new ArgumentOutOfRangeException();
      }
    }

    public JsValue GetValue(object value)
    {
      switch (value)
      {
        case Reference reference:
          if (reference.IsUnresolvableReference())
          {
            JsValue jsValue;
            if (this.Options._ReferenceResolver != null && this.Options._ReferenceResolver.TryUnresolvableReference(this, reference, out jsValue))
              return jsValue;
            throw new JavaScriptException(this.ReferenceError, reference.GetReferencedName() + " is not defined");
          }
          JsValue thisObject = reference.GetBase();
          if (reference.IsPropertyReference())
          {
            if (this.Options._ReferenceResolver != null && this.Options._ReferenceResolver.TryPropertyReference(this, reference, ref thisObject))
              return thisObject;
            if (!reference.HasPrimitiveBase())
              return TypeConverter.ToObject(this, thisObject).Get(reference.GetReferencedName());
            PropertyDescriptor property = TypeConverter.ToObject(this, thisObject).GetProperty(reference.GetReferencedName());
            if (property == PropertyDescriptor.Undefined)
              return JsValue.Undefined;
            if (property.IsDataDescriptor())
              return property.Value;
            JsValue get = property.Get;
            return get == Undefined.Instance ? Undefined.Instance : ((ICallable) get.AsObject()).Call(thisObject, Arguments.Empty);
          }
          return (thisObject.As<EnvironmentRecord>() ?? throw new ArgumentException()).GetBindingValue(reference.GetReferencedName(), reference.IsStrict());
        case Completion completion:
          return this.GetValue((object) completion.Value);
        default:
          return (JsValue) value;
      }
    }

    public void PutValue(Reference reference, JsValue value)
    {
      if (reference.IsUnresolvableReference())
      {
        if (reference.IsStrict())
          throw new JavaScriptException(this.ReferenceError);
        this.Global.Put(reference.GetReferencedName(), value, false);
      }
      else if (reference.IsPropertyReference())
      {
        JsValue b = reference.GetBase();
        if (!reference.HasPrimitiveBase())
          b.AsObject().Put(reference.GetReferencedName(), value, reference.IsStrict());
        else
          this.PutPrimitiveBase(b, reference.GetReferencedName(), value, reference.IsStrict());
      }
      else
        (reference.GetBase().As<EnvironmentRecord>() ?? throw new ArgumentNullException()).SetMutableBinding(reference.GetReferencedName(), value, reference.IsStrict());
    }

    public void PutPrimitiveBase(JsValue b, string name, JsValue value, bool throwOnError)
    {
      ObjectInstance objectInstance = TypeConverter.ToObject(this, b);
      if (!objectInstance.CanPut(name))
      {
        if (throwOnError)
          throw new JavaScriptException(this.TypeError);
      }
      else if (objectInstance.GetOwnProperty(name).IsDataDescriptor())
      {
        if (throwOnError)
          throw new JavaScriptException(this.TypeError);
      }
      else
      {
        PropertyDescriptor property = objectInstance.GetProperty(name);
        if (property.IsAccessorDescriptor())
          ((ICallable) property.Set.AsObject()).Call(b, new JsValue[1]
          {
            value
          });
        else if (throwOnError)
          throw new JavaScriptException(this.TypeError);
      }
    }

    public JsValue Invoke(string propertyName, params object[] arguments)
    {
      return this.Invoke(propertyName, (object) null, arguments);
    }

    public JsValue Invoke(string propertyName, object thisObj, object[] arguments)
    {
      return this.Invoke(this.GetValue(propertyName), thisObj, arguments);
    }

    public JsValue Invoke(JsValue value, params object[] arguments)
    {
      return this.Invoke(value, (object) null, arguments);
    }

    public JsValue Invoke(JsValue value, object thisObj, object[] arguments)
    {
      return (value.TryCast<ICallable>() ?? throw new ArgumentException("Can only invoke functions")).Call(JsValue.FromObject(this, thisObj), ((IEnumerable<object>) arguments).Select<object, JsValue>((Func<object, JsValue>) (x => JsValue.FromObject(this, x))).ToArray<JsValue>());
    }

    public JsValue GetValue(string propertyName)
    {
      return this.GetValue((JsValue) (ObjectInstance) this.Global, propertyName);
    }

    public SyntaxNode GetLastSyntaxNode() => this._lastSyntaxNode;

    public JsValue GetValue(JsValue scope, string propertyName)
    {
      if (string.IsNullOrEmpty(propertyName))
        throw new ArgumentException(nameof (propertyName));
      return this.GetValue((object) new Reference(scope, propertyName, this.Options._IsStrict));
    }

    public void DeclarationBindingInstantiation(
      DeclarationBindingType declarationBindingType,
      IList<FunctionDeclaration> functionDeclarations,
      IList<VariableDeclaration> variableDeclarations,
      FunctionInstance functionInstance,
      JsValue[] arguments)
    {
      EnvironmentRecord record = this.ExecutionContext.VariableEnvironment.Record;
      bool canBeDeleted = declarationBindingType == DeclarationBindingType.EvalCode;
      bool isStrictModeCode = StrictModeScope.IsStrictModeCode;
      if (declarationBindingType == DeclarationBindingType.FunctionCode)
      {
        int length = arguments.Length;
        int num = 0;
        foreach (string formalParameter in functionInstance.FormalParameters)
        {
          ++num;
          JsValue jsValue = num > length ? Undefined.Instance : arguments[num - 1];
          if (!record.HasBinding(formalParameter))
            record.CreateMutableBinding(formalParameter);
          record.SetMutableBinding(formalParameter, jsValue, isStrictModeCode);
        }
      }
      foreach (FunctionDeclaration functionDeclaration in (IEnumerable<FunctionDeclaration>) functionDeclarations)
      {
        string name = functionDeclaration.Id.Name;
        FunctionInstance functionObject = this.Function.CreateFunctionObject(functionDeclaration);
        if (!record.HasBinding(name))
          record.CreateMutableBinding(name, canBeDeleted);
        else if (record == this.GlobalEnvironment.Record)
        {
          GlobalObject global = this.Global;
          PropertyDescriptor property = global.GetProperty(name);
          bool? nullable = property.Configurable;
          if (nullable.Value)
          {
            global.DefineOwnProperty(name, new PropertyDescriptor(Undefined.Instance, new bool?(true), new bool?(true), new bool?(canBeDeleted)), true);
          }
          else
          {
            nullable = !property.IsAccessorDescriptor() ? property.Enumerable : throw new JavaScriptException(this.TypeError);
            if (nullable.Value)
              goto label_16;
          }
        }
label_16:
        record.SetMutableBinding(name, (JsValue) (ObjectInstance) functionObject, isStrictModeCode);
      }
      bool flag = record.HasBinding(nameof (arguments));
      if (declarationBindingType == DeclarationBindingType.FunctionCode && !flag)
      {
        ArgumentsInstance argumentsObject = ArgumentsInstance.CreateArgumentsObject(this, functionInstance, functionInstance.FormalParameters, arguments, record, isStrictModeCode);
        if (isStrictModeCode)
        {
          if (!(record is DeclarativeEnvironmentRecord environmentRecord))
            throw new ArgumentException();
          environmentRecord.CreateImmutableBinding(nameof (arguments));
          environmentRecord.InitializeImmutableBinding(nameof (arguments), (JsValue) (ObjectInstance) argumentsObject);
        }
        else
        {
          record.CreateMutableBinding(nameof (arguments));
          record.SetMutableBinding(nameof (arguments), (JsValue) (ObjectInstance) argumentsObject, false);
        }
      }
      foreach (VariableDeclarator variableDeclarator in variableDeclarations.SelectMany<VariableDeclaration, VariableDeclarator>((Func<VariableDeclaration, IEnumerable<VariableDeclarator>>) (x => x.Declarations)))
      {
        string name = variableDeclarator.Id.Name;
        if (!record.HasBinding(name))
        {
          record.CreateMutableBinding(name, canBeDeleted);
          record.SetMutableBinding(name, Undefined.Instance, isStrictModeCode);
        }
      }
    }

    public delegate StepMode DebugStepDelegate(object sender, DebugInformation e);

    public delegate StepMode BreakDelegate(object sender, DebugInformation e);
  }
}
