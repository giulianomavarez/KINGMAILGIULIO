﻿// Decompiled with JetBrains decompiler
// Type: Jint.ReflectionExtensions
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using System;
using System.Reflection;

#nullable disable
namespace Jint
{
  internal static class ReflectionExtensions
  {
    internal static bool IsEnum(this Type type) => type.IsEnum;

    internal static bool IsGenericType(this Type type) => type.IsGenericType;

    internal static bool IsValueType(this Type type) => type.IsValueType;

    internal static bool HasAttribute<T>(this ParameterInfo member) where T : Attribute
    {
      return Attribute.IsDefined(member, typeof (T));
    }

    internal static MethodInfo GetMethodInfo(this Delegate d) => d.Method;
  }
}
