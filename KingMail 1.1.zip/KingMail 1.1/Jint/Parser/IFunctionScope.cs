﻿// Decompiled with JetBrains decompiler
// Type: Jint.Parser.IFunctionScope
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Parser.Ast;
using System.Collections.Generic;

#nullable disable
namespace Jint.Parser
{
  public interface IFunctionScope : IVariableScope
  {
    IList<FunctionDeclaration> FunctionDeclarations { get; set; }
  }
}
