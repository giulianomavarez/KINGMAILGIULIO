﻿// Decompiled with JetBrains decompiler
// Type: Jint.Parser.Position
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

#nullable disable
namespace Jint.Parser
{
  public struct Position
  {
    public int Line;
    public int Column;
  }
}
