﻿// Decompiled with JetBrains decompiler
// Type: Jint.Parser.ParserExtensions
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using System;
using System.Collections.Generic;

#nullable disable
namespace Jint.Parser
{
  public static class ParserExtensions
  {
    public static string Slice(this string source, int start, int end)
    {
      return source.Substring(start, Math.Min(source.Length, end) - start);
    }

    public static char CharCodeAt(this string source, int index)
    {
      return index < 0 || index > source.Length - 1 ? char.MinValue : source[index];
    }

    public static T Pop<T>(this List<T> list)
    {
      int index = list.Count - 1;
      T obj = list[index];
      list.RemoveAt(index);
      return obj;
    }

    public static void Push<T>(this List<T> list, T item) => list.Add(item);
  }
}
