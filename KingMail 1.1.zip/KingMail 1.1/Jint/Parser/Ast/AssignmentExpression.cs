﻿// Decompiled with JetBrains decompiler
// Type: Jint.Parser.Ast.AssignmentExpression
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using System;

#nullable disable
namespace Jint.Parser.Ast
{
  public class AssignmentExpression : Expression
  {
    public AssignmentOperator Operator;
    public Expression Left;
    public Expression Right;

    public static AssignmentOperator ParseAssignmentOperator(string op)
    {
      switch (op)
      {
        case "%=":
          return AssignmentOperator.ModuloAssign;
        case "&=":
          return AssignmentOperator.BitwiseAndAssign;
        case "*=":
          return AssignmentOperator.TimesAssign;
        case "+=":
          return AssignmentOperator.PlusAssign;
        case "-=":
          return AssignmentOperator.MinusAssign;
        case "/=":
          return AssignmentOperator.DivideAssign;
        case "<<=":
          return AssignmentOperator.LeftShiftAssign;
        case "=":
          return AssignmentOperator.Assign;
        case ">>=":
          return AssignmentOperator.RightShiftAssign;
        case ">>>=":
          return AssignmentOperator.UnsignedRightShiftAssign;
        case "^=":
          return AssignmentOperator.BitwiseXOrAssign;
        case "|=":
          return AssignmentOperator.BitwiseOrAssign;
        default:
          throw new ArgumentOutOfRangeException("Invalid assignment operator: " + op);
      }
    }
  }
}
