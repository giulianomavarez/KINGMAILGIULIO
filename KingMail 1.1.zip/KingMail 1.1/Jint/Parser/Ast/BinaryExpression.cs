﻿// Decompiled with JetBrains decompiler
// Type: Jint.Parser.Ast.BinaryExpression
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using System;

#nullable disable
namespace Jint.Parser.Ast
{
  public class BinaryExpression : Expression
  {
    public BinaryOperator Operator;
    public Expression Left;
    public Expression Right;

    public static BinaryOperator ParseBinaryOperator(string op)
    {
      switch (op)
      {
        case "!=":
          return BinaryOperator.NotEqual;
        case "!==":
          return BinaryOperator.StricltyNotEqual;
        case "%":
          return BinaryOperator.Modulo;
        case "&":
          return BinaryOperator.BitwiseAnd;
        case "*":
          return BinaryOperator.Times;
        case "+":
          return BinaryOperator.Plus;
        case "-":
          return BinaryOperator.Minus;
        case "/":
          return BinaryOperator.Divide;
        case "<":
          return BinaryOperator.Less;
        case "<<":
          return BinaryOperator.LeftShift;
        case "<=":
          return BinaryOperator.LessOrEqual;
        case "==":
          return BinaryOperator.Equal;
        case "===":
          return BinaryOperator.StrictlyEqual;
        case ">":
          return BinaryOperator.Greater;
        case ">=":
          return BinaryOperator.GreaterOrEqual;
        case ">>":
          return BinaryOperator.RightShift;
        case ">>>":
          return BinaryOperator.UnsignedRightShift;
        case "^":
          return BinaryOperator.BitwiseXOr;
        case "in":
          return BinaryOperator.In;
        case "instanceof":
          return BinaryOperator.InstanceOf;
        case "|":
          return BinaryOperator.BitwiseOr;
        default:
          throw new ArgumentOutOfRangeException("Invalid binary operator: " + op);
      }
    }
  }
}
