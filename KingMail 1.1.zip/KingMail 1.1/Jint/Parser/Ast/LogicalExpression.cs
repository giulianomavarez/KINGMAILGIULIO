﻿// Decompiled with JetBrains decompiler
// Type: Jint.Parser.Ast.LogicalExpression
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using System;

#nullable disable
namespace Jint.Parser.Ast
{
  public class LogicalExpression : Expression
  {
    public LogicalOperator Operator;
    public Expression Left;
    public Expression Right;

    public static LogicalOperator ParseLogicalOperator(string op)
    {
      switch (op)
      {
        case "&&":
          return LogicalOperator.LogicalAnd;
        case "||":
          return LogicalOperator.LogicalOr;
        default:
          throw new ArgumentOutOfRangeException("Invalid binary operator: " + op);
      }
    }
  }
}
