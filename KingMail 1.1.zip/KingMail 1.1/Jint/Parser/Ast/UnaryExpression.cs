﻿// Decompiled with JetBrains decompiler
// Type: Jint.Parser.Ast.UnaryExpression
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using System;

#nullable disable
namespace Jint.Parser.Ast
{
  public class UnaryExpression : Expression
  {
    public UnaryOperator Operator;
    public Expression Argument;
    public bool Prefix;

    public static UnaryOperator ParseUnaryOperator(string op)
    {
      switch (op)
      {
        case "!":
          return UnaryOperator.LogicalNot;
        case "+":
          return UnaryOperator.Plus;
        case "++":
          return UnaryOperator.Increment;
        case "-":
          return UnaryOperator.Minus;
        case "--":
          return UnaryOperator.Decrement;
        case "delete":
          return UnaryOperator.Delete;
        case "typeof":
          return UnaryOperator.TypeOf;
        case "void":
          return UnaryOperator.Void;
        case "~":
          return UnaryOperator.BitwiseNot;
        default:
          throw new ArgumentOutOfRangeException("Invalid unary operator: " + op);
      }
    }
  }
}
