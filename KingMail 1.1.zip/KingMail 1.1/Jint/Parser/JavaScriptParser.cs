﻿// Decompiled with JetBrains decompiler
// Type: Jint.Parser.JavaScriptParser
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.String;
using Jint.Parser.Ast;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

#nullable disable
namespace Jint.Parser
{
  public class JavaScriptParser
  {
    private static readonly HashSet<string> Keywords = new HashSet<string>()
    {
      "if",
      "in",
      "do",
      "var",
      "for",
      "new",
      "try",
      "let",
      "this",
      "else",
      "case",
      "void",
      "with",
      "enum",
      "while",
      "break",
      "catch",
      "throw",
      "const",
      "yield",
      "class",
      "super",
      "return",
      "typeof",
      "delete",
      "switch",
      "export",
      "import",
      "default",
      "finally",
      "extends",
      "function",
      "continue",
      "debugger",
      "instanceof"
    };
    private static readonly HashSet<string> StrictModeReservedWords = new HashSet<string>()
    {
      "implements",
      "interface",
      "package",
      "private",
      "protected",
      "public",
      "static",
      "yield",
      "let"
    };
    private static readonly HashSet<string> FutureReservedWords = new HashSet<string>()
    {
      "class",
      "enum",
      "export",
      "extends",
      "import",
      "super"
    };
    private JavaScriptParser.Extra _extra;
    private int _index;
    private int _length;
    private int _lineNumber;
    private int _lineStart;
    private Location _location;
    private Token _lookahead;
    private string _source;
    private State _state;
    private bool _strict;
    private readonly Stack<IVariableScope> _variableScopes = new Stack<IVariableScope>();
    private readonly Stack<IFunctionScope> _functionScopes = new Stack<IFunctionScope>();

    public JavaScriptParser()
    {
    }

    public JavaScriptParser(bool strict) => this._strict = strict;

    private static bool IsDecimalDigit(char ch) => ch >= '0' && ch <= '9';

    private static bool IsHexDigit(char ch)
    {
      if (ch >= '0' && ch <= '9' || ch >= 'a' && ch <= 'f')
        return true;
      return ch >= 'A' && ch <= 'F';
    }

    private static bool IsOctalDigit(char ch) => ch >= '0' && ch <= '7';

    private static bool IsWhiteSpace(char ch)
    {
      if (ch == ' ' || ch == '\t' || ch == '\v' || ch == '\f' || ch == ' ')
        return true;
      if (ch < ' ')
        return false;
      return ch == ' ' || ch == '\u180E' || ch >= ' ' && ch <= ' ' || ch == ' ' || ch == ' ' || ch == '　' || ch == '\uFEFF';
    }

    private static bool IsLineTerminator(char ch)
    {
      return ch == '\n' || ch == '\r' || ch == '\u2028' || ch == '\u2029';
    }

    private static bool IsIdentifierStart(char ch)
    {
      if (ch == '$' || ch == '_' || ch >= 'A' && ch <= 'Z' || ch >= 'a' && ch <= 'z' || ch == '\\')
        return true;
      return ch >= '\u0080' && JavaScriptParser.Regexes.NonAsciiIdentifierStart.IsMatch(ch.ToString());
    }

    private static bool IsIdentifierPart(char ch)
    {
      if (ch == '$' || ch == '_' || ch >= 'A' && ch <= 'Z' || ch >= 'a' && ch <= 'z' || ch >= '0' && ch <= '9' || ch == '\\')
        return true;
      return ch >= '\u0080' && JavaScriptParser.Regexes.NonAsciiIdentifierPart.IsMatch(ch.ToString());
    }

    private static bool IsFutureReservedWord(string id)
    {
      return JavaScriptParser.FutureReservedWords.Contains(id);
    }

    private static bool IsStrictModeReservedWord(string id)
    {
      return JavaScriptParser.StrictModeReservedWords.Contains(id);
    }

    private static bool IsRestrictedWord(string id) => "eval".Equals(id) || "arguments".Equals(id);

    private bool IsKeyword(string id)
    {
      return this._strict && JavaScriptParser.IsStrictModeReservedWord(id) || JavaScriptParser.Keywords.Contains(id);
    }

    private void AddComment(string type, string value, int start, int end, Location location)
    {
      if (this._state.LastCommentStart >= start)
        return;
      this._state.LastCommentStart = start;
      Comment comment = new Comment()
      {
        Type = type,
        Value = value
      };
      if (this._extra.Range != null)
        comment.Range = new int[2]{ start, end };
      if (this._extra.Loc.HasValue)
        comment.Location = location;
      this._extra.Comments.Add(comment);
    }

    private void SkipSingleLineComment(int offset)
    {
      int start = this._index - offset;
      this._location = new Location()
      {
        Start = new Position()
        {
          Line = this._lineNumber,
          Column = this._index - this._lineStart - offset
        }
      };
      while (this._index < this._length)
      {
        char ch = this._source.CharCodeAt(this._index);
        ++this._index;
        if (JavaScriptParser.IsLineTerminator(ch))
        {
          if (this._extra.Comments != null)
          {
            string str = this._source.Slice(start + 2, this._index - 1);
            this._location.End = new Position()
            {
              Line = this._lineNumber,
              Column = this._index - this._lineStart - 1
            };
            this.AddComment("Line", str, start, this._index - 1, this._location);
          }
          if (ch == '\r' && this._source.CharCodeAt(this._index) == '\n')
            ++this._index;
          ++this._lineNumber;
          this._lineStart = this._index;
          return;
        }
      }
      if (this._extra.Comments == null)
        return;
      string str1 = this._source.Slice(start + offset, this._index);
      this._location.End = new Position()
      {
        Line = this._lineNumber,
        Column = this._index - this._lineStart
      };
      this.AddComment("Line", str1, start, this._index, this._location);
    }

    private void SkipMultiLineComment()
    {
      int start = 0;
      Position position1;
      if (this._extra.Comments != null)
      {
        start = this._index - 2;
        Location location = new Location();
        position1 = new Position();
        position1.Line = this._lineNumber;
        position1.Column = this._index - this._lineStart - 2;
        location.Start = position1;
        this._location = location;
      }
      while (this._index < this._length)
      {
        char ch = this._source.CharCodeAt(this._index);
        if (JavaScriptParser.IsLineTerminator(ch))
        {
          if (ch == '\r' && this._source.CharCodeAt(this._index + 1) == '\n')
            ++this._index;
          ++this._lineNumber;
          ++this._index;
          this._lineStart = this._index;
          if (this._index >= this._length)
            this.ThrowError((Token) null, Messages.UnexpectedToken, (object) "ILLEGAL");
        }
        else if (ch == '*')
        {
          if (this._source.CharCodeAt(this._index + 1) == '/')
          {
            ++this._index;
            ++this._index;
            if (this._extra.Comments == null)
              return;
            string str = this._source.Slice(start + 2, this._index - 2);
            Location location = this._location;
            position1 = new Position();
            position1.Line = this._lineNumber;
            position1.Column = this._index - this._lineStart;
            Position position2 = position1;
            location.End = position2;
            this.AddComment("Block", str, start, this._index, this._location);
            return;
          }
          ++this._index;
        }
        else
          ++this._index;
      }
      this.ThrowError((Token) null, Messages.UnexpectedToken, (object) "ILLEGAL");
    }

    private void SkipComment()
    {
      bool flag = this._index == 0;
      while (this._index < this._length)
      {
        char ch = this._source.CharCodeAt(this._index);
        if (JavaScriptParser.IsWhiteSpace(ch))
          ++this._index;
        else if (JavaScriptParser.IsLineTerminator(ch))
        {
          ++this._index;
          if (ch == '\r' && this._source.CharCodeAt(this._index) == '\n')
            ++this._index;
          ++this._lineNumber;
          this._lineStart = this._index;
          flag = true;
        }
        else if (ch == '/')
        {
          switch (this._source.CharCodeAt(this._index + 1))
          {
            case '*':
              ++this._index;
              ++this._index;
              this.SkipMultiLineComment();
              continue;
            case '/':
              ++this._index;
              ++this._index;
              this.SkipSingleLineComment(2);
              flag = true;
              continue;
            default:
              return;
          }
        }
        else if (flag && ch == '-')
        {
          if (this._source.CharCodeAt(this._index + 1) != '-' || this._source.CharCodeAt(this._index + 2) != '>')
            break;
          this._index += 3;
          this.SkipSingleLineComment(3);
        }
        else
        {
          if (ch != '<' || !(this._source.Slice(this._index + 1, this._index + 4) == "!--"))
            break;
          ++this._index;
          ++this._index;
          ++this._index;
          ++this._index;
          this.SkipSingleLineComment(4);
        }
      }
    }

    private bool ScanHexEscape(char prefix, out char result)
    {
      int num1 = 0;
      int num2 = prefix == 'u' ? 4 : 2;
      for (int index = 0; index < num2; ++index)
      {
        if (this._index < this._length && JavaScriptParser.IsHexDigit(this._source.CharCodeAt(this._index)))
        {
          char ch = this._source.CharCodeAt(this._index++);
          num1 = num1 * 16 + "0123456789abcdef".IndexOf(ch.ToString(), StringComparison.OrdinalIgnoreCase);
        }
        else
        {
          result = char.MinValue;
          return false;
        }
      }
      result = (char) num1;
      return true;
    }

    private string GetEscapedIdentifier()
    {
      char result = this._source.CharCodeAt(this._index++);
      StringBuilder stringBuilder = new StringBuilder(result.ToString());
      if (result == '\\')
      {
        if (this._source.CharCodeAt(this._index) != 'u')
          this.ThrowError((Token) null, Messages.UnexpectedToken, (object) "ILLEGAL");
        ++this._index;
        if (!this.ScanHexEscape('u', out result) || result == '\\' || !JavaScriptParser.IsIdentifierStart(result))
          this.ThrowError((Token) null, Messages.UnexpectedToken, (object) "ILLEGAL");
        stringBuilder = new StringBuilder(result.ToString());
      }
      while (this._index < this._length)
      {
        result = this._source.CharCodeAt(this._index);
        if (JavaScriptParser.IsIdentifierPart(result))
        {
          ++this._index;
          if (result == '\\')
          {
            if (this._source.CharCodeAt(this._index) != 'u')
              this.ThrowError((Token) null, Messages.UnexpectedToken, (object) "ILLEGAL");
            ++this._index;
            if (!this.ScanHexEscape('u', out result) || result == '\\' || !JavaScriptParser.IsIdentifierPart(result))
              this.ThrowError((Token) null, Messages.UnexpectedToken, (object) "ILLEGAL");
            stringBuilder.Append(result);
          }
          else
            stringBuilder.Append(result);
        }
        else
          break;
      }
      return stringBuilder.ToString();
    }

    private string GetIdentifier()
    {
      int start;
      for (start = this._index++; this._index < this._length; ++this._index)
      {
        char ch = this._source.CharCodeAt(this._index);
        if (ch == '\\')
        {
          this._index = start;
          return this.GetEscapedIdentifier();
        }
        if (!JavaScriptParser.IsIdentifierPart(ch))
          break;
      }
      return this._source.Slice(start, this._index);
    }

    private Token ScanIdentifier()
    {
      int index = this._index;
      string id = this._source.CharCodeAt(this._index) == '\\' ? this.GetEscapedIdentifier() : this.GetIdentifier();
      Tokens tokens = id.Length != 1 ? (!this.IsKeyword(id) ? (!"null".Equals(id) ? ("true".Equals(id) || "false".Equals(id) ? Tokens.BooleanLiteral : Tokens.Identifier) : Tokens.NullLiteral) : Tokens.Keyword) : Tokens.Identifier;
      return new Token()
      {
        Type = tokens,
        Value = (object) id,
        LineNumber = new int?(this._lineNumber),
        LineStart = this._lineStart,
        Range = new int[2]{ index, this._index }
      };
    }

    private Token ScanPunctuator()
    {
      int index = this._index;
      char ch1 = this._source.CharCodeAt(this._index);
      char ch2 = this._source.CharCodeAt(this._index);
      switch (ch1)
      {
        case '(':
        case ')':
        case ',':
        case '.':
        case ':':
        case ';':
        case '?':
        case '[':
        case ']':
        case '{':
        case '}':
        case '~':
          ++this._index;
          return new Token()
          {
            Type = Tokens.Punctuator,
            Value = (object) ch1.ToString(),
            LineNumber = new int?(this._lineNumber),
            LineStart = this._lineStart,
            Range = new int[2]{ index, this._index }
          };
        default:
          char ch3 = this._source.CharCodeAt(this._index + 1);
          if (ch3 == '=')
          {
            switch (ch1)
            {
              case '!':
              case '=':
                this._index += 2;
                if (this._source.CharCodeAt(this._index) == '=')
                  ++this._index;
                return new Token()
                {
                  Type = Tokens.Punctuator,
                  Value = (object) this._source.Slice(index, this._index),
                  LineNumber = new int?(this._lineNumber),
                  LineStart = this._lineStart,
                  Range = new int[2]{ index, this._index }
                };
              case '%':
              case '&':
              case '*':
              case '+':
              case '-':
              case '/':
              case '<':
              case '>':
              case '^':
              case '|':
                this._index += 2;
                return new Token()
                {
                  Type = Tokens.Punctuator,
                  Value = (object) (ch1.ToString() + ch3.ToString()),
                  LineNumber = new int?(this._lineNumber),
                  LineStart = this._lineStart,
                  Range = new int[2]{ index, this._index }
                };
            }
          }
          char ch4 = this._source.CharCodeAt(this._index + 1);
          char ch5 = this._source.CharCodeAt(this._index + 2);
          char ch6 = this._source.CharCodeAt(this._index + 3);
          if (ch2 == '>' && ch4 == '>' && ch5 == '>' && ch6 == '=')
          {
            this._index += 4;
            return new Token()
            {
              Type = Tokens.Punctuator,
              Value = (object) ">>>=",
              LineNumber = new int?(this._lineNumber),
              LineStart = this._lineStart,
              Range = new int[2]{ index, this._index }
            };
          }
          if (ch2 == '>' && ch4 == '>' && ch5 == '>')
          {
            this._index += 3;
            return new Token()
            {
              Type = Tokens.Punctuator,
              Value = (object) ">>>",
              LineNumber = new int?(this._lineNumber),
              LineStart = this._lineStart,
              Range = new int[2]{ index, this._index }
            };
          }
          if (ch2 == '<' && ch4 == '<' && ch5 == '=')
          {
            this._index += 3;
            return new Token()
            {
              Type = Tokens.Punctuator,
              Value = (object) "<<=",
              LineNumber = new int?(this._lineNumber),
              LineStart = this._lineStart,
              Range = new int[2]{ index, this._index }
            };
          }
          if (ch2 == '>' && ch4 == '>' && ch5 == '=')
          {
            this._index += 3;
            return new Token()
            {
              Type = Tokens.Punctuator,
              Value = (object) ">>=",
              LineNumber = new int?(this._lineNumber),
              LineStart = this._lineStart,
              Range = new int[2]{ index, this._index }
            };
          }
          if ((int) ch2 == (int) ch4 && "+-<>&|".IndexOf(ch2) >= 0)
          {
            this._index += 2;
            return new Token()
            {
              Type = Tokens.Punctuator,
              Value = (object) (ch2.ToString() + ch4.ToString()),
              LineNumber = new int?(this._lineNumber),
              LineStart = this._lineStart,
              Range = new int[2]{ index, this._index }
            };
          }
          if ("<>=!+-*%&|^/".IndexOf(ch2) >= 0)
          {
            ++this._index;
            return new Token()
            {
              Type = Tokens.Punctuator,
              Value = (object) ch2.ToString(),
              LineNumber = new int?(this._lineNumber),
              LineStart = this._lineStart,
              Range = new int[2]{ index, this._index }
            };
          }
          this.ThrowError((Token) null, Messages.UnexpectedToken, (object) "ILLEGAL");
          return (Token) null;
      }
    }

    private Token ScanHexLiteral(int start)
    {
      string str = "";
      while (this._index < this._length && JavaScriptParser.IsHexDigit(this._source.CharCodeAt(this._index)))
        str += this._source.CharCodeAt(this._index++).ToString();
      if (str.Length == 0)
        this.ThrowError((Token) null, Messages.UnexpectedToken, (object) "ILLEGAL");
      if (JavaScriptParser.IsIdentifierStart(this._source.CharCodeAt(this._index)))
        this.ThrowError((Token) null, Messages.UnexpectedToken, (object) "ILLEGAL");
      double num1 = 0.0;
      if (str.Length < 16)
        num1 = (double) Convert.ToUInt64(str, 16);
      else if (str.Length > (int) byte.MaxValue)
      {
        num1 = double.PositiveInfinity;
      }
      else
      {
        double num2 = 1.0;
        string lowerInvariant = str.ToLowerInvariant();
        for (int index = lowerInvariant.Length - 1; index >= 0; --index)
        {
          char ch = lowerInvariant[index];
          if (ch <= '9')
            num1 += num2 * (double) ((int) ch - 48);
          else
            num1 += num2 * (double) ((int) ch - 97 + 10);
          num2 *= 16.0;
        }
      }
      return new Token()
      {
        Type = Tokens.NumericLiteral,
        Value = (object) num1,
        LineNumber = new int?(this._lineNumber),
        LineStart = this._lineStart,
        Range = new int[2]{ start, this._index }
      };
    }

    private Token ScanOctalLiteral(int start)
    {
      string str = "0" + this._source.CharCodeAt(this._index++).ToString();
      while (this._index < this._length && JavaScriptParser.IsOctalDigit(this._source.CharCodeAt(this._index)))
        str += this._source.CharCodeAt(this._index++).ToString();
      if (JavaScriptParser.IsIdentifierStart(this._source.CharCodeAt(this._index)) || JavaScriptParser.IsDecimalDigit(this._source.CharCodeAt(this._index)))
        this.ThrowError((Token) null, Messages.UnexpectedToken, (object) "ILLEGAL");
      return new Token()
      {
        Type = Tokens.NumericLiteral,
        Value = (object) Convert.ToInt32(str, 8),
        Octal = true,
        LineNumber = new int?(this._lineNumber),
        LineStart = this._lineStart,
        Range = new int[2]{ start, this._index }
      };
    }

    private Token ScanNumericLiteral()
    {
      char ch1 = this._source.CharCodeAt(this._index);
      int index = this._index;
      string s = "";
      char ch2;
      if (ch1 != '.')
      {
        ch2 = this._source.CharCodeAt(this._index++);
        s = ch2.ToString();
        char ch3 = this._source.CharCodeAt(this._index);
        if (s == "0")
        {
          if (ch3 == 'x' || ch3 == 'X')
          {
            ++this._index;
            return this.ScanHexLiteral(index);
          }
          if (JavaScriptParser.IsOctalDigit(ch3))
            return this.ScanOctalLiteral(index);
          if (ch3 > char.MinValue && JavaScriptParser.IsDecimalDigit(ch3))
            this.ThrowError((Token) null, Messages.UnexpectedToken, (object) "ILLEGAL");
        }
        while (JavaScriptParser.IsDecimalDigit(this._source.CharCodeAt(this._index)))
        {
          string str1 = s;
          ch2 = this._source.CharCodeAt(this._index++);
          string str2 = ch2.ToString();
          s = str1 + str2;
        }
        ch1 = this._source.CharCodeAt(this._index);
      }
      if (ch1 == '.')
      {
        string str3 = s;
        ch2 = this._source.CharCodeAt(this._index++);
        string str4 = ch2.ToString();
        s = str3 + str4;
        while (JavaScriptParser.IsDecimalDigit(this._source.CharCodeAt(this._index)))
        {
          string str5 = s;
          ch2 = this._source.CharCodeAt(this._index++);
          string str6 = ch2.ToString();
          s = str5 + str6;
        }
        ch1 = this._source.CharCodeAt(this._index);
      }
      if (ch1 == 'e' || ch1 == 'E')
      {
        string str7 = s;
        ch2 = this._source.CharCodeAt(this._index++);
        string str8 = ch2.ToString();
        s = str7 + str8;
        switch (this._source.CharCodeAt(this._index))
        {
          case '+':
          case '-':
            string str9 = s;
            ch2 = this._source.CharCodeAt(this._index++);
            string str10 = ch2.ToString();
            s = str9 + str10;
            break;
        }
        if (JavaScriptParser.IsDecimalDigit(this._source.CharCodeAt(this._index)))
        {
          while (JavaScriptParser.IsDecimalDigit(this._source.CharCodeAt(this._index)))
          {
            string str11 = s;
            ch2 = this._source.CharCodeAt(this._index++);
            string str12 = ch2.ToString();
            s = str11 + str12;
          }
        }
        else
          this.ThrowError((Token) null, Messages.UnexpectedToken, (object) "ILLEGAL");
      }
      if (JavaScriptParser.IsIdentifierStart(this._source.CharCodeAt(this._index)))
        this.ThrowError((Token) null, Messages.UnexpectedToken, (object) "ILLEGAL");
      double num;
      try
      {
        num = double.Parse(s, NumberStyles.AllowDecimalPoint | NumberStyles.AllowExponent, (IFormatProvider) CultureInfo.InvariantCulture);
        if (num > double.MaxValue)
          num = double.PositiveInfinity;
        else if (num < double.MinValue)
          num = double.NegativeInfinity;
      }
      catch (OverflowException ex)
      {
        num = StringPrototype.TrimEx(s).StartsWith("-") ? double.NegativeInfinity : double.PositiveInfinity;
      }
      catch (Exception ex)
      {
        num = double.NaN;
      }
      return new Token()
      {
        Type = Tokens.NumericLiteral,
        Value = (object) num,
        LineNumber = new int?(this._lineNumber),
        LineStart = this._lineStart,
        Range = new int[2]{ index, this._index }
      };
    }

    private Token ScanStringLiteral()
    {
      StringBuilder stringBuilder = new StringBuilder();
      bool flag = false;
      int lineStart = this._lineStart;
      int lineNumber = this._lineNumber;
      char ch1 = this._source.CharCodeAt(this._index);
      int index1 = this._index;
      ++this._index;
      while (this._index < this._length)
      {
        char ch2 = this._source.CharCodeAt(this._index++);
        if ((int) ch2 == (int) ch1)
        {
          ch1 = char.MinValue;
          break;
        }
        if (ch2 == '\\')
        {
          char ch3 = this._source.CharCodeAt(this._index++);
          if (ch3 == char.MinValue || !JavaScriptParser.IsLineTerminator(ch3))
          {
            switch (ch3)
            {
              case 'b':
                stringBuilder.Append("\b");
                continue;
              case 'f':
                stringBuilder.Append("\f");
                continue;
              case 'n':
                stringBuilder.Append('\n');
                continue;
              case 'r':
                stringBuilder.Append('\r');
                continue;
              case 't':
                stringBuilder.Append('\t');
                continue;
              case 'u':
              case 'x':
                int index2 = this._index;
                char result;
                if (this.ScanHexEscape(ch3, out result))
                {
                  stringBuilder.Append(result);
                  continue;
                }
                this._index = index2;
                stringBuilder.Append(ch3);
                continue;
              case 'v':
                stringBuilder.Append("\v");
                continue;
              default:
                if (JavaScriptParser.IsOctalDigit(ch3))
                {
                  int num = "01234567".IndexOf(ch3);
                  if (num != 0)
                    flag = true;
                  if (this._index < this._length && JavaScriptParser.IsOctalDigit(this._source.CharCodeAt(this._index)))
                  {
                    flag = true;
                    num = num * 8 + "01234567".IndexOf(this._source.CharCodeAt(this._index++));
                    if ("0123".IndexOf(ch3) >= 0 && this._index < this._length && JavaScriptParser.IsOctalDigit(this._source.CharCodeAt(this._index)))
                      num = num * 8 + "01234567".IndexOf(this._source.CharCodeAt(this._index++));
                  }
                  stringBuilder.Append((char) num);
                  continue;
                }
                stringBuilder.Append(ch3);
                continue;
            }
          }
          else
          {
            ++this._lineNumber;
            if (ch3 == '\r' && this._source.CharCodeAt(this._index) == '\n')
              ++this._index;
            this._lineStart = this._index;
          }
        }
        else if (!JavaScriptParser.IsLineTerminator(ch2))
          stringBuilder.Append(ch2);
        else
          break;
      }
      if (ch1 != char.MinValue)
        this.ThrowError((Token) null, Messages.UnexpectedToken, (object) "ILLEGAL");
      return new Token()
      {
        Type = Tokens.StringLiteral,
        Value = (object) stringBuilder.ToString(),
        Octal = flag,
        LineNumber = new int?(this._lineNumber),
        LineStart = this._lineStart,
        Range = new int[2]{ index1, this._index }
      };
    }

    private Token ScanRegExp()
    {
      bool flag1 = false;
      bool flag2 = false;
      this.SkipComment();
      int index1 = this._index;
      StringBuilder stringBuilder = new StringBuilder(this._source.CharCodeAt(this._index++).ToString());
      while (this._index < this._length)
      {
        char ch1 = this._source.CharCodeAt(this._index++);
        stringBuilder.Append(ch1);
        if (ch1 == '\\')
        {
          char ch2 = this._source.CharCodeAt(this._index++);
          if (JavaScriptParser.IsLineTerminator(ch2))
            this.ThrowError((Token) null, Messages.UnterminatedRegExp);
          stringBuilder.Append(ch2);
        }
        else if (JavaScriptParser.IsLineTerminator(ch1))
          this.ThrowError((Token) null, Messages.UnterminatedRegExp);
        else if (flag1)
        {
          if (ch1 == ']')
            flag1 = false;
        }
        else
        {
          switch (ch1)
          {
            case '/':
              flag2 = true;
              goto label_14;
            case '[':
              flag1 = true;
              continue;
            default:
              continue;
          }
        }
      }
label_14:
      if (!flag2)
        this.ThrowError((Token) null, Messages.UnterminatedRegExp);
      string str1 = stringBuilder.ToString().Substring(1, stringBuilder.Length - 2);
      string str2 = "";
      while (this._index < this._length)
      {
        char result = this._source.CharCodeAt(this._index);
        if (JavaScriptParser.IsIdentifierPart(result))
        {
          ++this._index;
          if (result == '\\' && this._index < this._length)
          {
            result = this._source.CharCodeAt(this._index);
            if (result == 'u')
            {
              ++this._index;
              int index2 = this._index;
              if (this.ScanHexEscape('u', out result))
              {
                str2 += result.ToString();
                stringBuilder.Append("\\u");
                for (; index2 < this._index; ++index2)
                  stringBuilder.Append(this._source.CharCodeAt(index2).ToString());
              }
              else
              {
                this._index = index2;
                str2 += "u";
                stringBuilder.Append("\\u");
              }
            }
            else
              stringBuilder.Append("\\");
          }
          else
          {
            str2 += result.ToString();
            stringBuilder.Append(result.ToString());
          }
        }
        else
          break;
      }
      this.Peek();
      return new Token()
      {
        Type = Tokens.RegularExpression,
        Literal = stringBuilder.ToString(),
        Value = (object) (str1 + str2),
        Range = new int[2]{ index1, this._index }
      };
    }

    private Token CollectRegex()
    {
      this.SkipComment();
      int index = this._index;
      Location location = new Location()
      {
        Start = new Position()
        {
          Line = this._lineNumber,
          Column = this._index - this._lineStart
        }
      };
      Token token1 = this.ScanRegExp();
      location.End = new Position()
      {
        Line = this._lineNumber,
        Column = this._index - this._lineStart
      };
      if (this._extra.Tokens != null)
      {
        Token token2 = this._extra.Tokens[this._extra.Tokens.Count - 1];
        if (token2.Range[0] == index && token2.Type == Tokens.Punctuator && ("/".Equals(token2.Value) || "/=".Equals(token2.Value)))
          this._extra.Tokens.RemoveAt(this._extra.Tokens.Count - 1);
        this._extra.Tokens.Add(new Token()
        {
          Type = Tokens.RegularExpression,
          Value = (object) token1.Literal,
          Range = new int[2]{ index, this._index },
          Location = location
        });
      }
      return token1;
    }

    private bool IsIdentifierName(Token token)
    {
      return token.Type == Tokens.Identifier || token.Type == Tokens.Keyword || token.Type == Tokens.BooleanLiteral || token.Type == Tokens.NullLiteral;
    }

    private Token Advance()
    {
      this.SkipComment();
      if (this._index >= this._length)
        return new Token()
        {
          Type = Tokens.EOF,
          LineNumber = new int?(this._lineNumber),
          LineStart = this._lineStart,
          Range = new int[2]{ this._index, this._index }
        };
      char ch = this._source.CharCodeAt(this._index);
      switch (ch)
      {
        case '"':
        case '\'':
          return this.ScanStringLiteral();
        case '(':
        case ')':
        case ';':
          return this.ScanPunctuator();
        default:
          if (JavaScriptParser.IsIdentifierStart(ch))
            return this.ScanIdentifier();
          return ch == '.' ? (JavaScriptParser.IsDecimalDigit(this._source.CharCodeAt(this._index + 1)) ? this.ScanNumericLiteral() : this.ScanPunctuator()) : (JavaScriptParser.IsDecimalDigit(ch) ? this.ScanNumericLiteral() : this.ScanPunctuator());
      }
    }

    private Token CollectToken()
    {
      this.SkipComment();
      this._location = new Location()
      {
        Start = new Position()
        {
          Line = this._lineNumber,
          Column = this._index - this._lineStart
        }
      };
      Token token = this.Advance();
      this._location.End = new Position()
      {
        Line = this._lineNumber,
        Column = this._index - this._lineStart
      };
      if (token.Type != Tokens.EOF)
      {
        int[] numArray = new int[2]
        {
          token.Range[0],
          token.Range[1]
        };
        string str = this._source.Slice(token.Range[0], token.Range[1]);
        this._extra.Tokens.Add(new Token()
        {
          Type = token.Type,
          Value = (object) str,
          Range = numArray,
          Location = this._location
        });
      }
      return token;
    }

    private Token Lex()
    {
      Token lookahead = this._lookahead;
      this._index = lookahead.Range[1];
      this._lineNumber = lookahead.LineNumber.HasValue ? lookahead.LineNumber.Value : 0;
      this._lineStart = lookahead.LineStart;
      this._lookahead = this._extra.Tokens != null ? this.CollectToken() : this.Advance();
      this._index = lookahead.Range[1];
      this._lineNumber = lookahead.LineNumber.HasValue ? lookahead.LineNumber.Value : 0;
      this._lineStart = lookahead.LineStart;
      return lookahead;
    }

    private void Peek()
    {
      int index = this._index;
      int lineNumber = this._lineNumber;
      int lineStart = this._lineStart;
      this._lookahead = this._extra.Tokens != null ? this.CollectToken() : this.Advance();
      this._index = index;
      this._lineNumber = lineNumber;
      this._lineStart = lineStart;
    }

    private void MarkStart()
    {
      this.SkipComment();
      if (this._extra.Loc.HasValue)
      {
        this._state.MarkerStack.Push(this._index - this._lineStart);
        this._state.MarkerStack.Push(this._lineNumber);
      }
      if (this._extra.Range == null)
        return;
      this._state.MarkerStack.Push(this._index);
    }

    private T MarkEnd<T>(T node) where T : SyntaxNode
    {
      if (this._extra.Range != null)
        node.Range = new int[2]
        {
          this._state.MarkerStack.Pop(),
          this._index
        };
      if (this._extra.Loc.HasValue)
      {
        node.Location = new Location()
        {
          Start = new Position()
          {
            Line = this._state.MarkerStack.Pop(),
            Column = this._state.MarkerStack.Pop()
          },
          End = new Position()
          {
            Line = this._lineNumber,
            Column = this._index - this._lineStart
          }
        };
        this.PostProcess((SyntaxNode) node);
      }
      return node;
    }

    public T MarkEndIf<T>(T node) where T : SyntaxNode
    {
      if (node.Range != null || node.Location != null)
      {
        if (this._extra.Loc.HasValue)
        {
          this._state.MarkerStack.Pop();
          this._state.MarkerStack.Pop();
        }
        if (this._extra.Range != null)
          this._state.MarkerStack.Pop();
      }
      else
        this.MarkEnd<T>(node);
      return node;
    }

    public SyntaxNode PostProcess(SyntaxNode node)
    {
      if (this._extra.Source != null)
        node.Location.Source = this._extra.Source;
      return node;
    }

    public ArrayExpression CreateArrayExpression(IEnumerable<Expression> elements)
    {
      ArrayExpression arrayExpression = new ArrayExpression();
      arrayExpression.Type = SyntaxNodes.ArrayExpression;
      arrayExpression.Elements = elements;
      return arrayExpression;
    }

    public AssignmentExpression CreateAssignmentExpression(
      string op,
      Expression left,
      Expression right)
    {
      AssignmentExpression assignmentExpression = new AssignmentExpression();
      assignmentExpression.Type = SyntaxNodes.AssignmentExpression;
      assignmentExpression.Operator = AssignmentExpression.ParseAssignmentOperator(op);
      assignmentExpression.Left = left;
      assignmentExpression.Right = right;
      return assignmentExpression;
    }

    public Expression CreateBinaryExpression(string op, Expression left, Expression right)
    {
      if (!(op == "||") && !(op == "&&"))
      {
        BinaryExpression binaryExpression = new BinaryExpression();
        binaryExpression.Type = SyntaxNodes.BinaryExpression;
        binaryExpression.Operator = BinaryExpression.ParseBinaryOperator(op);
        binaryExpression.Left = left;
        binaryExpression.Right = right;
        return (Expression) binaryExpression;
      }
      LogicalExpression binaryExpression1 = new LogicalExpression();
      binaryExpression1.Type = SyntaxNodes.LogicalExpression;
      binaryExpression1.Operator = LogicalExpression.ParseLogicalOperator(op);
      binaryExpression1.Left = left;
      binaryExpression1.Right = right;
      return (Expression) binaryExpression1;
    }

    public BlockStatement CreateBlockStatement(IEnumerable<Statement> body)
    {
      BlockStatement blockStatement = new BlockStatement();
      blockStatement.Type = SyntaxNodes.BlockStatement;
      blockStatement.Body = body;
      return blockStatement;
    }

    public BreakStatement CreateBreakStatement(Identifier label)
    {
      BreakStatement breakStatement = new BreakStatement();
      breakStatement.Type = SyntaxNodes.BreakStatement;
      breakStatement.Label = label;
      return breakStatement;
    }

    public CallExpression CreateCallExpression(Expression callee, IList<Expression> args)
    {
      CallExpression callExpression = new CallExpression();
      callExpression.Type = SyntaxNodes.CallExpression;
      callExpression.Callee = callee;
      callExpression.Arguments = args;
      return callExpression;
    }

    public CatchClause CreateCatchClause(Identifier param, BlockStatement body)
    {
      CatchClause catchClause = new CatchClause();
      catchClause.Type = SyntaxNodes.CatchClause;
      catchClause.Param = param;
      catchClause.Body = body;
      return catchClause;
    }

    public ConditionalExpression CreateConditionalExpression(
      Expression test,
      Expression consequent,
      Expression alternate)
    {
      ConditionalExpression conditionalExpression = new ConditionalExpression();
      conditionalExpression.Type = SyntaxNodes.ConditionalExpression;
      conditionalExpression.Test = test;
      conditionalExpression.Consequent = consequent;
      conditionalExpression.Alternate = alternate;
      return conditionalExpression;
    }

    public ContinueStatement CreateContinueStatement(Identifier label)
    {
      ContinueStatement continueStatement = new ContinueStatement();
      continueStatement.Type = SyntaxNodes.ContinueStatement;
      continueStatement.Label = label;
      return continueStatement;
    }

    public DebuggerStatement CreateDebuggerStatement()
    {
      DebuggerStatement debuggerStatement = new DebuggerStatement();
      debuggerStatement.Type = SyntaxNodes.DebuggerStatement;
      return debuggerStatement;
    }

    public DoWhileStatement CreateDoWhileStatement(Statement body, Expression test)
    {
      DoWhileStatement doWhileStatement = new DoWhileStatement();
      doWhileStatement.Type = SyntaxNodes.DoWhileStatement;
      doWhileStatement.Body = body;
      doWhileStatement.Test = test;
      return doWhileStatement;
    }

    public EmptyStatement CreateEmptyStatement()
    {
      EmptyStatement emptyStatement = new EmptyStatement();
      emptyStatement.Type = SyntaxNodes.EmptyStatement;
      return emptyStatement;
    }

    public ExpressionStatement CreateExpressionStatement(Expression expression)
    {
      ExpressionStatement expressionStatement = new ExpressionStatement();
      expressionStatement.Type = SyntaxNodes.ExpressionStatement;
      expressionStatement.Expression = expression;
      return expressionStatement;
    }

    public ForStatement CreateForStatement(
      SyntaxNode init,
      Expression test,
      Expression update,
      Statement body)
    {
      ForStatement forStatement = new ForStatement();
      forStatement.Type = SyntaxNodes.ForStatement;
      forStatement.Init = init;
      forStatement.Test = test;
      forStatement.Update = update;
      forStatement.Body = body;
      return forStatement;
    }

    public ForInStatement CreateForInStatement(SyntaxNode left, Expression right, Statement body)
    {
      ForInStatement forInStatement = new ForInStatement();
      forInStatement.Type = SyntaxNodes.ForInStatement;
      forInStatement.Left = left;
      forInStatement.Right = right;
      forInStatement.Body = body;
      forInStatement.Each = false;
      return forInStatement;
    }

    public FunctionDeclaration CreateFunctionDeclaration(
      Identifier id,
      IEnumerable<Identifier> parameters,
      IEnumerable<Expression> defaults,
      Statement body,
      bool strict)
    {
      FunctionDeclaration functionDeclaration1 = new FunctionDeclaration();
      functionDeclaration1.Type = SyntaxNodes.FunctionDeclaration;
      functionDeclaration1.Id = id;
      functionDeclaration1.Parameters = parameters;
      functionDeclaration1.Defaults = defaults;
      functionDeclaration1.Body = body;
      functionDeclaration1.Strict = strict;
      functionDeclaration1.Rest = (SyntaxNode) null;
      functionDeclaration1.Generator = false;
      functionDeclaration1.Expression = false;
      functionDeclaration1.VariableDeclarations = this.LeaveVariableScope();
      functionDeclaration1.FunctionDeclarations = this.LeaveFunctionScope();
      FunctionDeclaration functionDeclaration2 = functionDeclaration1;
      this._functionScopes.Peek().FunctionDeclarations.Add(functionDeclaration2);
      return functionDeclaration2;
    }

    public FunctionExpression CreateFunctionExpression(
      Identifier id,
      IEnumerable<Identifier> parameters,
      IEnumerable<Expression> defaults,
      Statement body,
      bool strict)
    {
      FunctionExpression functionExpression = new FunctionExpression();
      functionExpression.Type = SyntaxNodes.FunctionExpression;
      functionExpression.Id = id;
      functionExpression.Parameters = parameters;
      functionExpression.Defaults = defaults;
      functionExpression.Body = body;
      functionExpression.Strict = strict;
      functionExpression.Rest = (SyntaxNode) null;
      functionExpression.Generator = false;
      functionExpression.Expression = false;
      functionExpression.VariableDeclarations = this.LeaveVariableScope();
      functionExpression.FunctionDeclarations = this.LeaveFunctionScope();
      return functionExpression;
    }

    public Identifier CreateIdentifier(string name)
    {
      Identifier identifier = new Identifier();
      identifier.Type = SyntaxNodes.Identifier;
      identifier.Name = name;
      return identifier;
    }

    public IfStatement CreateIfStatement(
      Expression test,
      Statement consequent,
      Statement alternate)
    {
      IfStatement ifStatement = new IfStatement();
      ifStatement.Type = SyntaxNodes.IfStatement;
      ifStatement.Test = test;
      ifStatement.Consequent = consequent;
      ifStatement.Alternate = alternate;
      return ifStatement;
    }

    public LabelledStatement CreateLabeledStatement(Identifier label, Statement body)
    {
      LabelledStatement labeledStatement = new LabelledStatement();
      labeledStatement.Type = SyntaxNodes.LabeledStatement;
      labeledStatement.Label = label;
      labeledStatement.Body = body;
      return labeledStatement;
    }

    public Literal CreateLiteral(Token token)
    {
      if (token.Type == Tokens.RegularExpression)
      {
        Literal literal = new Literal();
        literal.Type = SyntaxNodes.RegularExpressionLiteral;
        literal.Value = token.Value;
        literal.Raw = this._source.Slice(token.Range[0], token.Range[1]);
        return literal;
      }
      Literal literal1 = new Literal();
      literal1.Type = SyntaxNodes.Literal;
      literal1.Value = token.Value;
      literal1.Raw = this._source.Slice(token.Range[0], token.Range[1]);
      return literal1;
    }

    public MemberExpression CreateMemberExpression(
      char accessor,
      Expression obj,
      Expression property)
    {
      MemberExpression memberExpression = new MemberExpression();
      memberExpression.Type = SyntaxNodes.MemberExpression;
      memberExpression.Computed = accessor == '[';
      memberExpression.Object = obj;
      memberExpression.Property = property;
      return memberExpression;
    }

    public NewExpression CreateNewExpression(Expression callee, IEnumerable<Expression> args)
    {
      NewExpression newExpression = new NewExpression();
      newExpression.Type = SyntaxNodes.NewExpression;
      newExpression.Callee = callee;
      newExpression.Arguments = args;
      return newExpression;
    }

    public ObjectExpression CreateObjectExpression(IEnumerable<Property> properties)
    {
      ObjectExpression objectExpression = new ObjectExpression();
      objectExpression.Type = SyntaxNodes.ObjectExpression;
      objectExpression.Properties = properties;
      return objectExpression;
    }

    public UpdateExpression CreatePostfixExpression(string op, Expression argument)
    {
      UpdateExpression postfixExpression = new UpdateExpression();
      postfixExpression.Type = SyntaxNodes.UpdateExpression;
      postfixExpression.Operator = UnaryExpression.ParseUnaryOperator(op);
      postfixExpression.Argument = argument;
      postfixExpression.Prefix = false;
      return postfixExpression;
    }

    public Program CreateProgram(ICollection<Statement> body, bool strict)
    {
      Program program = new Program();
      program.Type = SyntaxNodes.Program;
      program.Body = body;
      program.Strict = strict;
      program.VariableDeclarations = this.LeaveVariableScope();
      program.FunctionDeclarations = this.LeaveFunctionScope();
      return program;
    }

    public Property CreateProperty(PropertyKind kind, IPropertyKeyExpression key, Expression value)
    {
      Property property = new Property();
      property.Type = SyntaxNodes.Property;
      property.Key = key;
      property.Value = value;
      property.Kind = kind;
      return property;
    }

    public ReturnStatement CreateReturnStatement(Expression argument)
    {
      ReturnStatement returnStatement = new ReturnStatement();
      returnStatement.Type = SyntaxNodes.ReturnStatement;
      returnStatement.Argument = argument;
      return returnStatement;
    }

    public SequenceExpression CreateSequenceExpression(IList<Expression> expressions)
    {
      SequenceExpression sequenceExpression = new SequenceExpression();
      sequenceExpression.Type = SyntaxNodes.SequenceExpression;
      sequenceExpression.Expressions = expressions;
      return sequenceExpression;
    }

    public SwitchCase CreateSwitchCase(Expression test, IEnumerable<Statement> consequent)
    {
      SwitchCase switchCase = new SwitchCase();
      switchCase.Type = SyntaxNodes.SwitchCase;
      switchCase.Test = test;
      switchCase.Consequent = consequent;
      return switchCase;
    }

    public SwitchStatement CreateSwitchStatement(
      Expression discriminant,
      IEnumerable<SwitchCase> cases)
    {
      SwitchStatement switchStatement = new SwitchStatement();
      switchStatement.Type = SyntaxNodes.SwitchStatement;
      switchStatement.Discriminant = discriminant;
      switchStatement.Cases = cases;
      return switchStatement;
    }

    public ThisExpression CreateThisExpression()
    {
      ThisExpression thisExpression = new ThisExpression();
      thisExpression.Type = SyntaxNodes.ThisExpression;
      return thisExpression;
    }

    public ThrowStatement CreateThrowStatement(Expression argument)
    {
      ThrowStatement throwStatement = new ThrowStatement();
      throwStatement.Type = SyntaxNodes.ThrowStatement;
      throwStatement.Argument = argument;
      return throwStatement;
    }

    public TryStatement CreateTryStatement(
      Statement block,
      IEnumerable<Statement> guardedHandlers,
      IEnumerable<CatchClause> handlers,
      Statement finalizer)
    {
      TryStatement tryStatement = new TryStatement();
      tryStatement.Type = SyntaxNodes.TryStatement;
      tryStatement.Block = block;
      tryStatement.GuardedHandlers = guardedHandlers;
      tryStatement.Handlers = handlers;
      tryStatement.Finalizer = finalizer;
      return tryStatement;
    }

    public UnaryExpression CreateUnaryExpression(string op, Expression argument)
    {
      if (op == "++" || op == "--")
      {
        UpdateExpression unaryExpression = new UpdateExpression();
        unaryExpression.Type = SyntaxNodes.UpdateExpression;
        unaryExpression.Operator = UnaryExpression.ParseUnaryOperator(op);
        unaryExpression.Argument = argument;
        unaryExpression.Prefix = true;
        return (UnaryExpression) unaryExpression;
      }
      UnaryExpression unaryExpression1 = new UnaryExpression();
      unaryExpression1.Type = SyntaxNodes.UnaryExpression;
      unaryExpression1.Operator = UnaryExpression.ParseUnaryOperator(op);
      unaryExpression1.Argument = argument;
      unaryExpression1.Prefix = true;
      return unaryExpression1;
    }

    public VariableDeclaration CreateVariableDeclaration(
      IEnumerable<VariableDeclarator> declarations,
      string kind)
    {
      VariableDeclaration variableDeclaration1 = new VariableDeclaration();
      variableDeclaration1.Type = SyntaxNodes.VariableDeclaration;
      variableDeclaration1.Declarations = declarations;
      variableDeclaration1.Kind = kind;
      VariableDeclaration variableDeclaration2 = variableDeclaration1;
      this._variableScopes.Peek().VariableDeclarations.Add(variableDeclaration2);
      return variableDeclaration2;
    }

    public VariableDeclarator CreateVariableDeclarator(Identifier id, Expression init)
    {
      VariableDeclarator variableDeclarator = new VariableDeclarator();
      variableDeclarator.Type = SyntaxNodes.VariableDeclarator;
      variableDeclarator.Id = id;
      variableDeclarator.Init = init;
      return variableDeclarator;
    }

    public WhileStatement CreateWhileStatement(Expression test, Statement body)
    {
      WhileStatement whileStatement = new WhileStatement();
      whileStatement.Type = SyntaxNodes.WhileStatement;
      whileStatement.Test = test;
      whileStatement.Body = body;
      return whileStatement;
    }

    public WithStatement CreateWithStatement(Expression obj, Statement body)
    {
      WithStatement withStatement = new WithStatement();
      withStatement.Type = SyntaxNodes.WithStatement;
      withStatement.Object = obj;
      withStatement.Body = body;
      return withStatement;
    }

    private bool PeekLineTerminator()
    {
      int index = this._index;
      int lineNumber = this._lineNumber;
      int lineStart = this._lineStart;
      this.SkipComment();
      int num = this._lineNumber != lineNumber ? 1 : 0;
      this._index = index;
      this._lineNumber = lineNumber;
      this._lineStart = lineStart;
      return num != 0;
    }

    private void ThrowError(Token token, string messageFormat, params object[] arguments)
    {
      string str = string.Format(messageFormat, arguments);
      ParserException parserException1;
      if (token != null && token.LineNumber.HasValue)
      {
        ParserException parserException2 = new ParserException("Line " + (object) token.LineNumber + ": " + str);
        parserException2.Index = token.Range[0];
        parserException2.LineNumber = token.LineNumber.Value;
        parserException2.Column = token.Range[0] - this._lineStart + 1;
        parserException2.Source = this._extra.Source;
        parserException1 = parserException2;
      }
      else
      {
        ParserException parserException3 = new ParserException("Line " + (object) this._lineNumber + ": " + str);
        parserException3.Index = this._index;
        parserException3.LineNumber = this._lineNumber;
        parserException3.Column = this._index - this._lineStart + 1;
        parserException3.Source = this._extra.Source;
        parserException1 = parserException3;
      }
      parserException1.Description = str;
      throw parserException1;
    }

    private void ThrowErrorTolerant(Token token, string messageFormat, params object[] arguments)
    {
      try
      {
        this.ThrowError(token, messageFormat, arguments);
      }
      catch (Exception ex)
      {
        if (this._extra.Errors != null)
        {
          List<ParserException> errors = this._extra.Errors;
          ParserException parserException = new ParserException(ex.Message);
          parserException.Source = this._extra.Source;
          errors.Add(parserException);
        }
        else
          throw;
      }
    }

    private void ThrowUnexpected(Token token)
    {
      if (token.Type == Tokens.EOF)
        this.ThrowError(token, Messages.UnexpectedEOS);
      if (token.Type == Tokens.NumericLiteral)
        this.ThrowError(token, Messages.UnexpectedNumber);
      if (token.Type == Tokens.StringLiteral)
        this.ThrowError(token, Messages.UnexpectedString);
      if (token.Type == Tokens.Identifier)
        this.ThrowError(token, Messages.UnexpectedIdentifier);
      if (token.Type == Tokens.Keyword)
      {
        if (JavaScriptParser.IsFutureReservedWord(token.Value as string))
          this.ThrowError(token, Messages.UnexpectedReserved);
        else if (this._strict && JavaScriptParser.IsStrictModeReservedWord(token.Value as string))
        {
          this.ThrowErrorTolerant(token, Messages.StrictReservedWord);
          return;
        }
        this.ThrowError(token, Messages.UnexpectedToken, (object) (token.Value as string));
      }
      this.ThrowError(token, Messages.UnexpectedToken, (object) (token.Value as string));
    }

    private void Expect(string value)
    {
      Token token = this.Lex();
      if (token.Type == Tokens.Punctuator && value.Equals(token.Value))
        return;
      this.ThrowUnexpected(token);
    }

    private void ExpectKeyword(string keyword)
    {
      Token token = this.Lex();
      if (token.Type == Tokens.Keyword && keyword.Equals(token.Value))
        return;
      this.ThrowUnexpected(token);
    }

    private bool Match(string value)
    {
      return this._lookahead.Type == Tokens.Punctuator && value.Equals(this._lookahead.Value);
    }

    private bool MatchKeyword(object keyword)
    {
      return this._lookahead.Type == Tokens.Keyword && keyword.Equals(this._lookahead.Value);
    }

    private bool MatchAssign()
    {
      if (this._lookahead.Type != Tokens.Punctuator)
        return false;
      string str = this._lookahead.Value as string;
      return str == "=" || str == "*=" || str == "/=" || str == "%=" || str == "+=" || str == "-=" || str == "<<=" || str == ">>=" || str == ">>>=" || str == "&=" || str == "^=" || str == "|=";
    }

    private void ConsumeSemicolon()
    {
      if (this._source.CharCodeAt(this._index) == ';')
      {
        this.Lex();
      }
      else
      {
        int lineNumber = this._lineNumber;
        this.SkipComment();
        if (this._lineNumber != lineNumber)
          return;
        if (this.Match(";"))
        {
          this.Lex();
        }
        else
        {
          if (this._lookahead.Type == Tokens.EOF || this.Match("}"))
            return;
          this.ThrowUnexpected(this._lookahead);
        }
      }
    }

    private bool isLeftHandSide(Expression expr)
    {
      return expr.Type == SyntaxNodes.Identifier || expr.Type == SyntaxNodes.MemberExpression;
    }

    private ArrayExpression ParseArrayInitialiser()
    {
      List<Expression> elements = new List<Expression>();
      this.Expect("[");
      while (!this.Match("]"))
      {
        if (this.Match(","))
        {
          this.Lex();
          elements.Add((Expression) null);
        }
        else
        {
          elements.Add(this.ParseAssignmentExpression());
          if (!this.Match("]"))
            this.Expect(",");
        }
      }
      this.Expect("]");
      return this.CreateArrayExpression((IEnumerable<Expression>) elements);
    }

    private FunctionExpression ParsePropertyFunction(Identifier[] parameters, Token first = null)
    {
      this.EnterVariableScope();
      this.EnterFunctionScope();
      bool strict1 = this._strict;
      this.MarkStart();
      Statement functionSourceElements = this.ParseFunctionSourceElements();
      if (first != null && this._strict && JavaScriptParser.IsRestrictedWord(parameters[0].Name))
        this.ThrowErrorTolerant(first, Messages.StrictParamName);
      bool strict2 = this._strict;
      this._strict = strict1;
      return this.MarkEnd<FunctionExpression>(this.CreateFunctionExpression((Identifier) null, (IEnumerable<Identifier>) parameters, (IEnumerable<Expression>) new Expression[0], functionSourceElements, strict2));
    }

    private IPropertyKeyExpression ParseObjectPropertyKey()
    {
      this.MarkStart();
      Token token = this.Lex();
      if (token.Type != Tokens.StringLiteral && token.Type != Tokens.NumericLiteral)
        return (IPropertyKeyExpression) this.MarkEnd<Identifier>(this.CreateIdentifier((string) token.Value));
      if (this._strict && token.Octal)
        this.ThrowErrorTolerant(token, Messages.StrictOctalLiteral);
      return (IPropertyKeyExpression) this.MarkEnd<Literal>(this.CreateLiteral(token));
    }

    private Property ParseObjectProperty()
    {
      Token lookahead1 = this._lookahead;
      this.MarkStart();
      if (lookahead1.Type == Tokens.Identifier)
      {
        IPropertyKeyExpression objectPropertyKey1 = this.ParseObjectPropertyKey();
        if ("get".Equals(lookahead1.Value) && !this.Match(":"))
        {
          IPropertyKeyExpression objectPropertyKey2 = this.ParseObjectPropertyKey();
          this.Expect("(");
          this.Expect(")");
          Expression propertyFunction = (Expression) this.ParsePropertyFunction(new Identifier[0]);
          return this.MarkEnd<Property>(this.CreateProperty(PropertyKind.Get, objectPropertyKey2, propertyFunction));
        }
        if ("set".Equals(lookahead1.Value) && !this.Match(":"))
        {
          IPropertyKeyExpression objectPropertyKey3 = this.ParseObjectPropertyKey();
          this.Expect("(");
          Token lookahead2 = this._lookahead;
          Expression propertyFunction;
          if (lookahead2.Type != Tokens.Identifier)
          {
            this.Expect(")");
            this.ThrowErrorTolerant(lookahead2, Messages.UnexpectedToken, (object) (string) lookahead2.Value);
            propertyFunction = (Expression) this.ParsePropertyFunction(new Identifier[0]);
          }
          else
          {
            Identifier[] parameters = new Identifier[1]
            {
              this.ParseVariableIdentifier()
            };
            this.Expect(")");
            propertyFunction = (Expression) this.ParsePropertyFunction(parameters, lookahead2);
          }
          return this.MarkEnd<Property>(this.CreateProperty(PropertyKind.Set, objectPropertyKey3, propertyFunction));
        }
        this.Expect(":");
        Expression assignmentExpression = this.ParseAssignmentExpression();
        return this.MarkEnd<Property>(this.CreateProperty(PropertyKind.Data, objectPropertyKey1, assignmentExpression));
      }
      if (lookahead1.Type == Tokens.EOF || lookahead1.Type == Tokens.Punctuator)
      {
        this.ThrowUnexpected(lookahead1);
        return (Property) null;
      }
      IPropertyKeyExpression objectPropertyKey = this.ParseObjectPropertyKey();
      this.Expect(":");
      Expression assignmentExpression1 = this.ParseAssignmentExpression();
      return this.MarkEnd<Property>(this.CreateProperty(PropertyKind.Data, objectPropertyKey, assignmentExpression1));
    }

    private ObjectExpression ParseObjectInitialiser()
    {
      List<Property> propertyList = new List<Property>();
      Dictionary<string, PropertyKind> dictionary = new Dictionary<string, PropertyKind>();
      this.Expect("{");
      while (!this.Match("}"))
      {
        Property objectProperty = this.ParseObjectProperty();
        string key1 = objectProperty.Key.GetKey();
        PropertyKind kind = objectProperty.Kind;
        string key2 = "$" + key1;
        if (dictionary.ContainsKey(key2))
        {
          if (dictionary[key2] == PropertyKind.Data)
          {
            if (this._strict && kind == PropertyKind.Data)
              this.ThrowErrorTolerant(Token.Empty, Messages.StrictDuplicateProperty);
            else if (kind != PropertyKind.Data)
              this.ThrowErrorTolerant(Token.Empty, Messages.AccessorDataProperty);
          }
          else if (kind == PropertyKind.Data)
            this.ThrowErrorTolerant(Token.Empty, Messages.AccessorDataProperty);
          else if ((dictionary[key2] & kind) == kind)
            this.ThrowErrorTolerant(Token.Empty, Messages.AccessorGetSet);
          dictionary[key2] |= kind;
        }
        else
          dictionary[key2] = kind;
        propertyList.Add(objectProperty);
        if (!this.Match("}"))
          this.Expect(",");
      }
      this.Expect("}");
      return this.CreateObjectExpression((IEnumerable<Property>) propertyList);
    }

    private Expression ParseGroupExpression()
    {
      this.Expect("(");
      Expression expression = this.ParseExpression();
      this.Expect(")");
      return expression;
    }

    private Expression ParsePrimaryExpression()
    {
      Expression node = (Expression) null;
      if (this.Match("("))
        return this.ParseGroupExpression();
      Tokens type = this._lookahead.Type;
      this.MarkStart();
      switch (type)
      {
        case Tokens.BooleanLiteral:
          Token token1 = this.Lex();
          token1.Value = (object) "true".Equals(token1.Value);
          node = (Expression) this.CreateLiteral(token1);
          break;
        case Tokens.Identifier:
          node = (Expression) this.CreateIdentifier((string) this.Lex().Value);
          break;
        case Tokens.Keyword:
          if (this.MatchKeyword((object) "this"))
          {
            this.Lex();
            node = (Expression) this.CreateThisExpression();
            break;
          }
          if (this.MatchKeyword((object) "function"))
          {
            node = (Expression) this.ParseFunctionExpression();
            break;
          }
          break;
        case Tokens.NullLiteral:
          Token token2 = this.Lex();
          token2.Value = (object) null;
          node = (Expression) this.CreateLiteral(token2);
          break;
        case Tokens.NumericLiteral:
        case Tokens.StringLiteral:
          if (this._strict && this._lookahead.Octal)
            this.ThrowErrorTolerant(this._lookahead, Messages.StrictOctalLiteral);
          node = (Expression) this.CreateLiteral(this.Lex());
          break;
        default:
          if (this.Match("["))
          {
            node = (Expression) this.ParseArrayInitialiser();
            break;
          }
          if (this.Match("{"))
          {
            node = (Expression) this.ParseObjectInitialiser();
            break;
          }
          if (this.Match("/") || this.Match("/="))
          {
            node = (Expression) this.CreateLiteral(this._extra.Tokens != null ? this.CollectRegex() : this.ScanRegExp());
            break;
          }
          break;
      }
      if (node != null)
        return this.MarkEnd<Expression>(node);
      this.ThrowUnexpected(this.Lex());
      return (Expression) null;
    }

    private IList<Expression> ParseArguments()
    {
      List<Expression> arguments = new List<Expression>();
      this.Expect("(");
      if (!this.Match(")"))
      {
        while (this._index < this._length)
        {
          arguments.Add(this.ParseAssignmentExpression());
          if (!this.Match(")"))
            this.Expect(",");
          else
            break;
        }
      }
      this.Expect(")");
      return (IList<Expression>) arguments;
    }

    private Identifier ParseNonComputedProperty()
    {
      this.MarkStart();
      Token token = this.Lex();
      if (!this.IsIdentifierName(token))
        this.ThrowUnexpected(token);
      return this.MarkEnd<Identifier>(this.CreateIdentifier((string) token.Value));
    }

    private Identifier ParseNonComputedMember()
    {
      this.Expect(".");
      return this.ParseNonComputedProperty();
    }

    private Expression ParseComputedMember()
    {
      this.Expect("[");
      Expression expression = this.ParseExpression();
      this.Expect("]");
      return expression;
    }

    private NewExpression ParseNewExpression()
    {
      this.MarkStart();
      this.ExpectKeyword("new");
      return this.MarkEnd<NewExpression>(this.CreateNewExpression(this.ParseLeftHandSideExpression(), this.Match("(") ? (IEnumerable<Expression>) this.ParseArguments() : (IEnumerable<Expression>) new AssignmentExpression[0]));
    }

    private Expression ParseLeftHandSideExpressionAllowCall()
    {
      JavaScriptParser.LocationMarker locationMarker = this.CreateLocationMarker();
      bool allowIn = this._state.AllowIn;
      this._state.AllowIn = true;
      Expression expressionAllowCall = this.MatchKeyword((object) "new") ? (Expression) this.ParseNewExpression() : this.ParsePrimaryExpression();
      this._state.AllowIn = allowIn;
      while (this.Match(".") || this.Match("[") || this.Match("("))
      {
        if (this.Match("("))
        {
          IList<Expression> arguments = this.ParseArguments();
          expressionAllowCall = (Expression) this.CreateCallExpression(expressionAllowCall, arguments);
        }
        else if (this.Match("["))
        {
          Expression computedMember = this.ParseComputedMember();
          expressionAllowCall = (Expression) this.CreateMemberExpression('[', expressionAllowCall, computedMember);
        }
        else
        {
          Identifier nonComputedMember = this.ParseNonComputedMember();
          expressionAllowCall = (Expression) this.CreateMemberExpression('.', expressionAllowCall, (Expression) nonComputedMember);
        }
        if (locationMarker != null)
        {
          locationMarker.End(this._index, this._lineNumber, this._lineStart);
          locationMarker.Apply((SyntaxNode) expressionAllowCall, this._extra, new Func<SyntaxNode, SyntaxNode>(this.PostProcess));
        }
      }
      return expressionAllowCall;
    }

    private Expression ParseLeftHandSideExpression()
    {
      JavaScriptParser.LocationMarker locationMarker = this.CreateLocationMarker();
      bool allowIn = this._state.AllowIn;
      Expression node = this.MatchKeyword((object) "new") ? (Expression) this.ParseNewExpression() : this.ParsePrimaryExpression();
      this._state.AllowIn = allowIn;
      while (this.Match(".") || this.Match("["))
      {
        if (this.Match("["))
        {
          Expression computedMember = this.ParseComputedMember();
          node = (Expression) this.CreateMemberExpression('[', node, computedMember);
        }
        else
        {
          Identifier nonComputedMember = this.ParseNonComputedMember();
          node = (Expression) this.CreateMemberExpression('.', node, (Expression) nonComputedMember);
        }
        if (locationMarker != null)
        {
          locationMarker.End(this._index, this._lineNumber, this._lineStart);
          locationMarker.Apply((SyntaxNode) node, this._extra, new Func<SyntaxNode, SyntaxNode>(this.PostProcess));
        }
      }
      return node;
    }

    private Expression ParsePostfixExpression()
    {
      this.MarkStart();
      Expression expression = this.ParseLeftHandSideExpressionAllowCall();
      if (this._lookahead.Type == Tokens.Punctuator && (this.Match("++") || this.Match("--")) && !this.PeekLineTerminator())
      {
        if (this._strict && expression.Type == SyntaxNodes.Identifier && JavaScriptParser.IsRestrictedWord(((Identifier) expression).Name))
          this.ThrowErrorTolerant(Token.Empty, Messages.StrictLHSPostfix);
        if (!this.isLeftHandSide(expression))
          this.ThrowErrorTolerant(Token.Empty, Messages.InvalidLHSInAssignment);
        expression = (Expression) this.CreatePostfixExpression((string) this.Lex().Value, expression);
      }
      return this.MarkEndIf<Expression>(expression);
    }

    private Expression ParseUnaryExpression()
    {
      this.MarkStart();
      Expression node;
      if (this._lookahead.Type != Tokens.Punctuator && this._lookahead.Type != Tokens.Keyword)
        node = this.ParsePostfixExpression();
      else if (this.Match("++") || this.Match("--"))
      {
        Token token = this.Lex();
        Expression unaryExpression = this.ParseUnaryExpression();
        if (this._strict && unaryExpression.Type == SyntaxNodes.Identifier && JavaScriptParser.IsRestrictedWord(((Identifier) unaryExpression).Name))
          this.ThrowErrorTolerant(Token.Empty, Messages.StrictLHSPrefix);
        if (!this.isLeftHandSide(unaryExpression))
          this.ThrowErrorTolerant(Token.Empty, Messages.InvalidLHSInAssignment);
        node = (Expression) this.CreateUnaryExpression((string) token.Value, unaryExpression);
      }
      else if (this.Match("+") || this.Match("-") || this.Match("~") || this.Match("!"))
        node = (Expression) this.CreateUnaryExpression((string) this.Lex().Value, this.ParseUnaryExpression());
      else if (this.MatchKeyword((object) "delete") || this.MatchKeyword((object) "void") || this.MatchKeyword((object) "typeof"))
      {
        UnaryExpression unaryExpression = this.CreateUnaryExpression((string) this.Lex().Value, this.ParseUnaryExpression());
        if (this._strict && unaryExpression.Operator == UnaryOperator.Delete && unaryExpression.Argument.Type == SyntaxNodes.Identifier)
          this.ThrowErrorTolerant(Token.Empty, Messages.StrictDelete);
        node = (Expression) unaryExpression;
      }
      else
        node = this.ParsePostfixExpression();
      return this.MarkEndIf<Expression>(node);
    }

    private int binaryPrecedence(Token token, bool allowIn)
    {
      int num = 0;
      if (token.Type != Tokens.Punctuator && token.Type != Tokens.Keyword)
        return 0;
      switch ((string) token.Value)
      {
        case "!=":
        case "!==":
        case "==":
        case "===":
          num = 6;
          break;
        case "%":
        case "*":
        case "/":
          num = 11;
          break;
        case "&":
          num = 5;
          break;
        case "&&":
          num = 2;
          break;
        case "+":
        case "-":
          num = 9;
          break;
        case "<":
        case "<=":
        case ">":
        case ">=":
        case "instanceof":
          num = 7;
          break;
        case "<<":
        case ">>":
        case ">>>":
          num = 8;
          break;
        case "^":
          num = 4;
          break;
        case "in":
          num = allowIn ? 7 : 0;
          break;
        case "|":
          num = 3;
          break;
        case "||":
          num = 1;
          break;
      }
      return num;
    }

    private Expression ParseBinaryExpression()
    {
      JavaScriptParser.LocationMarker locationMarker1 = this.CreateLocationMarker();
      Expression unaryExpression1 = this.ParseUnaryExpression();
      Token lookahead = this._lookahead;
      int num1 = this.binaryPrecedence(lookahead, this._state.AllowIn);
      if (num1 == 0)
        return unaryExpression1;
      lookahead.Precedence = num1;
      this.Lex();
      Stack<JavaScriptParser.LocationMarker> locationMarkerStack = new Stack<JavaScriptParser.LocationMarker>((IEnumerable<JavaScriptParser.LocationMarker>) new JavaScriptParser.LocationMarker[2]
      {
        locationMarker1,
        this.CreateLocationMarker()
      });
      Expression unaryExpression2 = this.ParseUnaryExpression();
      List<object> list = new List<object>((IEnumerable<object>) new object[3]
      {
        (object) unaryExpression1,
        (object) lookahead,
        (object) unaryExpression2
      });
      int num2;
      while ((num2 = this.binaryPrecedence(this._lookahead, this._state.AllowIn)) > 0)
      {
        while (list.Count > 2 && num2 <= ((Token) list[list.Count - 2]).Precedence)
        {
          Expression right = (Expression) list.Pop<object>();
          Expression binaryExpression = this.CreateBinaryExpression((string) ((Token) list.Pop<object>()).Value, (Expression) list.Pop<object>(), right);
          locationMarkerStack.Pop();
          JavaScriptParser.LocationMarker locationMarker2 = locationMarkerStack.Pop();
          if (locationMarker2 != null)
          {
            locationMarker2.End(this._index, this._lineNumber, this._lineStart);
            locationMarker2.Apply((SyntaxNode) binaryExpression, this._extra, new Func<SyntaxNode, SyntaxNode>(this.PostProcess));
          }
          list.Push<object>((object) binaryExpression);
          locationMarkerStack.Push(locationMarker2);
        }
        Token token = this.Lex();
        token.Precedence = num2;
        list.Push<object>((object) token);
        locationMarkerStack.Push(this.CreateLocationMarker());
        Expression unaryExpression3 = this.ParseUnaryExpression();
        list.Push<object>((object) unaryExpression3);
      }
      int index = list.Count - 1;
      Expression binaryExpression1 = (Expression) list[index];
      locationMarkerStack.Pop();
      while (index > 1)
      {
        binaryExpression1 = this.CreateBinaryExpression((string) ((Token) list[index - 1]).Value, (Expression) list[index - 2], binaryExpression1);
        index -= 2;
        JavaScriptParser.LocationMarker locationMarker3 = locationMarkerStack.Pop();
        if (locationMarker3 != null)
        {
          locationMarker3.End(this._index, this._lineNumber, this._lineStart);
          locationMarker3.Apply((SyntaxNode) binaryExpression1, this._extra, new Func<SyntaxNode, SyntaxNode>(this.PostProcess));
        }
      }
      return binaryExpression1;
    }

    private Expression ParseConditionalExpression()
    {
      this.MarkStart();
      Expression test = this.ParseBinaryExpression();
      if (this.Match("?"))
      {
        this.Lex();
        bool allowIn = this._state.AllowIn;
        this._state.AllowIn = true;
        Expression assignmentExpression1 = this.ParseAssignmentExpression();
        this._state.AllowIn = allowIn;
        this.Expect(":");
        Expression assignmentExpression2 = this.ParseAssignmentExpression();
        test = (Expression) this.MarkEnd<ConditionalExpression>(this.CreateConditionalExpression(test, assignmentExpression1, assignmentExpression2));
      }
      else
        this.MarkEnd<SyntaxNode>(new SyntaxNode());
      return test;
    }

    private Expression ParseAssignmentExpression()
    {
      Token lookahead = this._lookahead;
      this.MarkStart();
      Expression conditionalExpression;
      Expression node = conditionalExpression = this.ParseConditionalExpression();
      if (this.MatchAssign())
      {
        if (this._strict && conditionalExpression.Type == SyntaxNodes.Identifier && JavaScriptParser.IsRestrictedWord(((Identifier) conditionalExpression).Name))
          this.ThrowErrorTolerant(lookahead, Messages.StrictLHSAssignment);
        Token token = this.Lex();
        Expression assignmentExpression = this.ParseAssignmentExpression();
        node = (Expression) this.CreateAssignmentExpression((string) token.Value, conditionalExpression, assignmentExpression);
      }
      return this.MarkEndIf<Expression>(node);
    }

    private Expression ParseExpression()
    {
      this.MarkStart();
      Expression node = this.ParseAssignmentExpression();
      if (this.Match(","))
      {
        node = (Expression) this.CreateSequenceExpression((IList<Expression>) new List<Expression>()
        {
          node
        });
        while (this._index < this._length && this.Match(","))
        {
          this.Lex();
          ((SequenceExpression) node).Expressions.Add(this.ParseAssignmentExpression());
        }
      }
      return this.MarkEndIf<Expression>(node);
    }

    private IEnumerable<Statement> ParseStatementList()
    {
      List<Statement> statementList = new List<Statement>();
      while (this._index < this._length && !this.Match("}"))
      {
        Statement sourceElement = this.ParseSourceElement();
        if (sourceElement != null)
          statementList.Add(sourceElement);
        else
          break;
      }
      return (IEnumerable<Statement>) statementList;
    }

    private BlockStatement ParseBlock()
    {
      this.MarkStart();
      this.Expect("{");
      IEnumerable<Statement> statementList = this.ParseStatementList();
      this.Expect("}");
      return this.MarkEnd<BlockStatement>(this.CreateBlockStatement(statementList));
    }

    private Identifier ParseVariableIdentifier()
    {
      this.MarkStart();
      Token token = this.Lex();
      if (token.Type != Tokens.Identifier)
        this.ThrowUnexpected(token);
      return this.MarkEnd<Identifier>(this.CreateIdentifier((string) token.Value));
    }

    private VariableDeclarator ParseVariableDeclaration(string kind)
    {
      Expression init = (Expression) null;
      this.MarkStart();
      Identifier variableIdentifier = this.ParseVariableIdentifier();
      if (this._strict && JavaScriptParser.IsRestrictedWord(variableIdentifier.Name))
        this.ThrowErrorTolerant(Token.Empty, Messages.StrictVarName);
      if ("const".Equals(kind))
      {
        this.Expect("=");
        init = this.ParseAssignmentExpression();
      }
      else if (this.Match("="))
      {
        this.Lex();
        init = this.ParseAssignmentExpression();
      }
      return this.MarkEnd<VariableDeclarator>(this.CreateVariableDeclarator(variableIdentifier, init));
    }

    private IEnumerable<VariableDeclarator> ParseVariableDeclarationList(string kind)
    {
      List<VariableDeclarator> variableDeclarationList = new List<VariableDeclarator>();
      do
      {
        variableDeclarationList.Add(this.ParseVariableDeclaration(kind));
        if (this.Match(","))
          this.Lex();
        else
          break;
      }
      while (this._index < this._length);
      return (IEnumerable<VariableDeclarator>) variableDeclarationList;
    }

    private VariableDeclaration ParseVariableStatement()
    {
      this.ExpectKeyword("var");
      IEnumerable<VariableDeclarator> variableDeclarationList = this.ParseVariableDeclarationList((string) null);
      this.ConsumeSemicolon();
      return this.CreateVariableDeclaration(variableDeclarationList, "var");
    }

    private VariableDeclaration ParseConstLetDeclaration(string kind)
    {
      this.MarkStart();
      this.ExpectKeyword(kind);
      IEnumerable<VariableDeclarator> variableDeclarationList = this.ParseVariableDeclarationList(kind);
      this.ConsumeSemicolon();
      return this.MarkEnd<VariableDeclaration>(this.CreateVariableDeclaration(variableDeclarationList, kind));
    }

    private EmptyStatement ParseEmptyStatement()
    {
      this.Expect(";");
      return this.CreateEmptyStatement();
    }

    private ExpressionStatement ParseExpressionStatement()
    {
      Expression expression = this.ParseExpression();
      this.ConsumeSemicolon();
      return this.CreateExpressionStatement(expression);
    }

    private IfStatement ParseIfStatement()
    {
      this.ExpectKeyword("if");
      this.Expect("(");
      Expression expression = this.ParseExpression();
      this.Expect(")");
      Statement statement = this.ParseStatement();
      Statement alternate;
      if (this.MatchKeyword((object) "else"))
      {
        this.Lex();
        alternate = this.ParseStatement();
      }
      else
        alternate = (Statement) null;
      return this.CreateIfStatement(expression, statement, alternate);
    }

    private DoWhileStatement ParseDoWhileStatement()
    {
      this.ExpectKeyword("do");
      bool inIteration = this._state.InIteration;
      this._state.InIteration = true;
      Statement statement = this.ParseStatement();
      this._state.InIteration = inIteration;
      this.ExpectKeyword("while");
      this.Expect("(");
      Expression expression = this.ParseExpression();
      this.Expect(")");
      if (this.Match(";"))
        this.Lex();
      return this.CreateDoWhileStatement(statement, expression);
    }

    private WhileStatement ParseWhileStatement()
    {
      this.ExpectKeyword("while");
      this.Expect("(");
      Expression expression = this.ParseExpression();
      this.Expect(")");
      bool inIteration = this._state.InIteration;
      this._state.InIteration = true;
      Statement statement = this.ParseStatement();
      this._state.InIteration = inIteration;
      return this.CreateWhileStatement(expression, statement);
    }

    private VariableDeclaration ParseForVariableDeclaration()
    {
      this.MarkStart();
      Token token = this.Lex();
      return this.MarkEnd<VariableDeclaration>(this.CreateVariableDeclaration(this.ParseVariableDeclarationList((string) null), (string) token.Value));
    }

    private Statement ParseForStatement()
    {
      SyntaxNode syntaxNode = (SyntaxNode) null;
      SyntaxNode left = (SyntaxNode) null;
      Expression right = (Expression) null;
      Expression test = (Expression) null;
      Expression update = (Expression) null;
      this.ExpectKeyword("for");
      this.Expect("(");
      if (this.Match(";"))
      {
        this.Lex();
      }
      else
      {
        if (this.MatchKeyword((object) "var") || this.MatchKeyword((object) "let"))
        {
          this._state.AllowIn = false;
          syntaxNode = (SyntaxNode) this.ParseForVariableDeclaration();
          this._state.AllowIn = true;
          if (syntaxNode.As<VariableDeclaration>().Declarations.Count<VariableDeclarator>() == 1 && this.MatchKeyword((object) "in"))
          {
            this.Lex();
            left = syntaxNode;
            right = this.ParseExpression();
            syntaxNode = (SyntaxNode) null;
          }
        }
        else
        {
          this._state.AllowIn = false;
          syntaxNode = (SyntaxNode) this.ParseExpression();
          this._state.AllowIn = true;
          if (this.MatchKeyword((object) "in"))
          {
            if (!this.isLeftHandSide((Expression) syntaxNode))
              this.ThrowErrorTolerant(Token.Empty, Messages.InvalidLHSInForIn);
            this.Lex();
            left = syntaxNode;
            right = this.ParseExpression();
            syntaxNode = (SyntaxNode) null;
          }
        }
        if (left == null)
          this.Expect(";");
      }
      if (left == null)
      {
        if (!this.Match(";"))
          test = this.ParseExpression();
        this.Expect(";");
        if (!this.Match(")"))
          update = this.ParseExpression();
      }
      this.Expect(")");
      bool inIteration = this._state.InIteration;
      this._state.InIteration = true;
      Statement statement = this.ParseStatement();
      this._state.InIteration = inIteration;
      return left != null ? (Statement) this.CreateForInStatement(left, right, statement) : (Statement) this.CreateForStatement(syntaxNode, test, update, statement);
    }

    private Statement ParseContinueStatement()
    {
      Identifier label = (Identifier) null;
      this.ExpectKeyword("continue");
      if (this._source.CharCodeAt(this._index) == ';')
      {
        this.Lex();
        if (!this._state.InIteration)
          this.ThrowError(Token.Empty, Messages.IllegalContinue);
        return (Statement) this.CreateContinueStatement((Identifier) null);
      }
      if (this.PeekLineTerminator())
      {
        if (!this._state.InIteration)
          this.ThrowError(Token.Empty, Messages.IllegalContinue);
        return (Statement) this.CreateContinueStatement((Identifier) null);
      }
      if (this._lookahead.Type == Tokens.Identifier)
      {
        label = this.ParseVariableIdentifier();
        if (!this._state.LabelSet.Contains("$" + label.Name))
          this.ThrowError(Token.Empty, Messages.UnknownLabel, (object) label.Name);
      }
      this.ConsumeSemicolon();
      if (label == null && !this._state.InIteration)
        this.ThrowError(Token.Empty, Messages.IllegalContinue);
      return (Statement) this.CreateContinueStatement(label);
    }

    private BreakStatement ParseBreakStatement()
    {
      Identifier label = (Identifier) null;
      this.ExpectKeyword("break");
      if (this._source.CharCodeAt(this._index) == ';')
      {
        this.Lex();
        if (!this._state.InIteration && !this._state.InSwitch)
          this.ThrowError(Token.Empty, Messages.IllegalBreak);
        return this.CreateBreakStatement((Identifier) null);
      }
      if (this.PeekLineTerminator())
      {
        if (!this._state.InIteration && !this._state.InSwitch)
          this.ThrowError(Token.Empty, Messages.IllegalBreak);
        return this.CreateBreakStatement((Identifier) null);
      }
      if (this._lookahead.Type == Tokens.Identifier)
      {
        label = this.ParseVariableIdentifier();
        if (!this._state.LabelSet.Contains("$" + label.Name))
          this.ThrowError(Token.Empty, Messages.UnknownLabel, (object) label.Name);
      }
      this.ConsumeSemicolon();
      if (label == null && !this._state.InIteration && !this._state.InSwitch)
        this.ThrowError(Token.Empty, Messages.IllegalBreak);
      return this.CreateBreakStatement(label);
    }

    private ReturnStatement ParseReturnStatement()
    {
      Expression expression1 = (Expression) null;
      this.ExpectKeyword("return");
      if (!this._state.InFunctionBody)
        this.ThrowErrorTolerant(Token.Empty, Messages.IllegalReturn);
      if (this._source.CharCodeAt(this._index) == ' ' && JavaScriptParser.IsIdentifierStart(this._source.CharCodeAt(this._index + 1)))
      {
        Expression expression2 = this.ParseExpression();
        this.ConsumeSemicolon();
        return this.CreateReturnStatement(expression2);
      }
      if (this.PeekLineTerminator())
        return this.CreateReturnStatement((Expression) null);
      if (!this.Match(";") && !this.Match("}") && this._lookahead.Type != Tokens.EOF)
        expression1 = this.ParseExpression();
      this.ConsumeSemicolon();
      return this.CreateReturnStatement(expression1);
    }

    private WithStatement ParseWithStatement()
    {
      if (this._strict)
        this.ThrowErrorTolerant(Token.Empty, Messages.StrictModeWith);
      this.ExpectKeyword("with");
      this.Expect("(");
      Expression expression = this.ParseExpression();
      this.Expect(")");
      Statement statement = this.ParseStatement();
      return this.CreateWithStatement(expression, statement);
    }

    private SwitchCase ParseSwitchCase()
    {
      List<Statement> consequent = new List<Statement>();
      this.MarkStart();
      Expression test;
      if (this.MatchKeyword((object) "default"))
      {
        this.Lex();
        test = (Expression) null;
      }
      else
      {
        this.ExpectKeyword("case");
        test = this.ParseExpression();
      }
      this.Expect(":");
      while (this._index < this._length && !this.Match("}") && !this.MatchKeyword((object) "default") && !this.MatchKeyword((object) "case"))
      {
        Statement statement = this.ParseStatement();
        consequent.Add(statement);
      }
      return this.MarkEnd<SwitchCase>(this.CreateSwitchCase(test, (IEnumerable<Statement>) consequent));
    }

    private SwitchStatement ParseSwitchStatement()
    {
      this.ExpectKeyword("switch");
      this.Expect("(");
      Expression expression = this.ParseExpression();
      this.Expect(")");
      this.Expect("{");
      List<SwitchCase> cases = new List<SwitchCase>();
      if (this.Match("}"))
      {
        this.Lex();
        return this.CreateSwitchStatement(expression, (IEnumerable<SwitchCase>) cases);
      }
      bool inSwitch = this._state.InSwitch;
      this._state.InSwitch = true;
      bool flag = false;
      while (this._index < this._length && !this.Match("}"))
      {
        SwitchCase switchCase = this.ParseSwitchCase();
        if (switchCase.Test == null)
        {
          if (flag)
            this.ThrowError(Token.Empty, Messages.MultipleDefaultsInSwitch);
          flag = true;
        }
        cases.Add(switchCase);
      }
      this._state.InSwitch = inSwitch;
      this.Expect("}");
      return this.CreateSwitchStatement(expression, (IEnumerable<SwitchCase>) cases);
    }

    private ThrowStatement ParseThrowStatement()
    {
      this.ExpectKeyword("throw");
      if (this.PeekLineTerminator())
        this.ThrowError(Token.Empty, Messages.NewlineAfterThrow);
      Expression expression = this.ParseExpression();
      this.ConsumeSemicolon();
      return this.CreateThrowStatement(expression);
    }

    private CatchClause ParseCatchClause()
    {
      this.MarkStart();
      this.ExpectKeyword("catch");
      this.Expect("(");
      if (this.Match(")"))
        this.ThrowUnexpected(this._lookahead);
      Identifier variableIdentifier = this.ParseVariableIdentifier();
      if (this._strict && JavaScriptParser.IsRestrictedWord(variableIdentifier.Name))
        this.ThrowErrorTolerant(Token.Empty, Messages.StrictCatchVariable);
      this.Expect(")");
      BlockStatement block = this.ParseBlock();
      return this.MarkEnd<CatchClause>(this.CreateCatchClause(variableIdentifier, block));
    }

    private TryStatement ParseTryStatement()
    {
      List<CatchClause> handlers = new List<CatchClause>();
      Statement finalizer = (Statement) null;
      this.ExpectKeyword("try");
      BlockStatement block = this.ParseBlock();
      if (this.MatchKeyword((object) "catch"))
        handlers.Add(this.ParseCatchClause());
      if (this.MatchKeyword((object) "finally"))
      {
        this.Lex();
        finalizer = (Statement) this.ParseBlock();
      }
      if (handlers.Count == 0 && finalizer == null)
        this.ThrowError(Token.Empty, Messages.NoCatchOrFinally);
      return this.CreateTryStatement((Statement) block, (IEnumerable<Statement>) new Statement[0], (IEnumerable<CatchClause>) handlers, finalizer);
    }

    private DebuggerStatement ParseDebuggerStatement()
    {
      this.ExpectKeyword("debugger");
      this.ConsumeSemicolon();
      return this.CreateDebuggerStatement();
    }

    private Statement ParseStatement()
    {
      Tokens type = this._lookahead.Type;
      if (type == Tokens.EOF)
        this.ThrowUnexpected(this._lookahead);
      this.MarkStart();
      if (type == Tokens.Punctuator)
      {
        switch ((string) this._lookahead.Value)
        {
          case ";":
            return (Statement) this.MarkEnd<EmptyStatement>(this.ParseEmptyStatement());
          case "{":
            return (Statement) this.MarkEnd<BlockStatement>(this.ParseBlock());
          case "(":
            return (Statement) this.MarkEnd<ExpressionStatement>(this.ParseExpressionStatement());
        }
      }
      if (type == Tokens.Keyword)
      {
        switch ((string) this._lookahead.Value)
        {
          case "break":
            return (Statement) this.MarkEnd<BreakStatement>(this.ParseBreakStatement());
          case "continue":
            return this.MarkEnd<Statement>(this.ParseContinueStatement());
          case "debugger":
            return (Statement) this.MarkEnd<DebuggerStatement>(this.ParseDebuggerStatement());
          case "do":
            return (Statement) this.MarkEnd<DoWhileStatement>(this.ParseDoWhileStatement());
          case "for":
            return this.MarkEnd<Statement>(this.ParseForStatement());
          case "function":
            return this.MarkEnd<Statement>(this.ParseFunctionDeclaration());
          case "if":
            return (Statement) this.MarkEnd<IfStatement>(this.ParseIfStatement());
          case "return":
            return (Statement) this.MarkEnd<ReturnStatement>(this.ParseReturnStatement());
          case "switch":
            return (Statement) this.MarkEnd<SwitchStatement>(this.ParseSwitchStatement());
          case "throw":
            return (Statement) this.MarkEnd<ThrowStatement>(this.ParseThrowStatement());
          case "try":
            return (Statement) this.MarkEnd<TryStatement>(this.ParseTryStatement());
          case "var":
            return (Statement) this.MarkEnd<VariableDeclaration>(this.ParseVariableStatement());
          case "while":
            return (Statement) this.MarkEnd<WhileStatement>(this.ParseWhileStatement());
          case "with":
            return (Statement) this.MarkEnd<WithStatement>(this.ParseWithStatement());
        }
      }
      Expression expression = this.ParseExpression();
      if (expression.Type == SyntaxNodes.Identifier && this.Match(":"))
      {
        this.Lex();
        string str = "$" + ((Identifier) expression).Name;
        if (this._state.LabelSet.Contains(str))
          this.ThrowError(Token.Empty, Messages.Redeclaration, (object) "Label", (object) ((Identifier) expression).Name);
        this._state.LabelSet.Add(str);
        Statement statement = this.ParseStatement();
        this._state.LabelSet.Remove(str);
        return (Statement) this.MarkEnd<LabelledStatement>(this.CreateLabeledStatement((Identifier) expression, statement));
      }
      this.ConsumeSemicolon();
      return (Statement) this.MarkEnd<ExpressionStatement>(this.CreateExpressionStatement(expression));
    }

    private Statement ParseFunctionSourceElements()
    {
      Token token = Token.Empty;
      List<Statement> body = new List<Statement>();
      this.MarkStart();
      this.Expect("{");
      while (this._index < this._length && this._lookahead.Type == Tokens.StringLiteral)
      {
        Token lookahead = this._lookahead;
        Statement sourceElement = this.ParseSourceElement();
        body.Add(sourceElement);
        if (((ExpressionStatement) sourceElement).Expression.Type == SyntaxNodes.Literal)
        {
          if (this._source.Slice(lookahead.Range[0] + 1, lookahead.Range[1] - 1) == "use strict")
          {
            this._strict = true;
            if (token != Token.Empty)
              this.ThrowErrorTolerant(token, Messages.StrictOctalLiteral);
          }
          else if (token == Token.Empty && lookahead.Octal)
            token = lookahead;
        }
        else
          break;
      }
      HashSet<string> labelSet = this._state.LabelSet;
      bool inIteration = this._state.InIteration;
      bool inSwitch = this._state.InSwitch;
      bool inFunctionBody = this._state.InFunctionBody;
      this._state.LabelSet = new HashSet<string>();
      this._state.InIteration = false;
      this._state.InSwitch = false;
      this._state.InFunctionBody = true;
      while (this._index < this._length && !this.Match("}"))
      {
        Statement sourceElement = this.ParseSourceElement();
        if (sourceElement != null)
          body.Add(sourceElement);
        else
          break;
      }
      this.Expect("}");
      this._state.LabelSet = labelSet;
      this._state.InIteration = inIteration;
      this._state.InSwitch = inSwitch;
      this._state.InFunctionBody = inFunctionBody;
      return (Statement) this.MarkEnd<BlockStatement>(this.CreateBlockStatement((IEnumerable<Statement>) body));
    }

    private JavaScriptParser.ParsedParameters ParseParams(Token firstRestricted)
    {
      string str1 = (string) null;
      Token token = Token.Empty;
      List<Identifier> identifierList = new List<Identifier>();
      this.Expect("(");
      if (!this.Match(")"))
      {
        HashSet<string> stringSet = new HashSet<string>();
        while (this._index < this._length)
        {
          Token lookahead = this._lookahead;
          Identifier variableIdentifier = this.ParseVariableIdentifier();
          string str2 = "$" + (string) lookahead.Value;
          if (this._strict)
          {
            if (JavaScriptParser.IsRestrictedWord((string) lookahead.Value))
            {
              token = lookahead;
              str1 = Messages.StrictParamName;
            }
            if (stringSet.Contains(str2))
            {
              token = lookahead;
              str1 = Messages.StrictParamDupe;
            }
          }
          else if (firstRestricted == Token.Empty)
          {
            if (JavaScriptParser.IsRestrictedWord((string) lookahead.Value))
            {
              firstRestricted = lookahead;
              str1 = Messages.StrictParamName;
            }
            else if (JavaScriptParser.IsStrictModeReservedWord((string) lookahead.Value))
            {
              firstRestricted = lookahead;
              str1 = Messages.StrictReservedWord;
            }
            else if (stringSet.Contains(str2))
            {
              firstRestricted = lookahead;
              str1 = Messages.StrictParamDupe;
            }
          }
          identifierList.Add(variableIdentifier);
          stringSet.Add(str2);
          if (!this.Match(")"))
            this.Expect(",");
          else
            break;
        }
      }
      this.Expect(")");
      return new JavaScriptParser.ParsedParameters()
      {
        Parameters = (IEnumerable<Identifier>) identifierList,
        Stricted = token,
        FirstRestricted = firstRestricted,
        Message = str1
      };
    }

    private Statement ParseFunctionDeclaration()
    {
      this.EnterVariableScope();
      this.EnterFunctionScope();
      Token firstRestricted1 = Token.Empty;
      string messageFormat = (string) null;
      this.MarkStart();
      this.ExpectKeyword("function");
      Token lookahead = this._lookahead;
      Identifier variableIdentifier = this.ParseVariableIdentifier();
      if (this._strict)
      {
        if (JavaScriptParser.IsRestrictedWord((string) lookahead.Value))
          this.ThrowErrorTolerant(lookahead, Messages.StrictFunctionName);
      }
      else if (JavaScriptParser.IsRestrictedWord((string) lookahead.Value))
      {
        firstRestricted1 = lookahead;
        messageFormat = Messages.StrictFunctionName;
      }
      else if (JavaScriptParser.IsStrictModeReservedWord((string) lookahead.Value))
      {
        firstRestricted1 = lookahead;
        messageFormat = Messages.StrictReservedWord;
      }
      JavaScriptParser.ParsedParameters parsedParameters = this.ParseParams(firstRestricted1);
      IEnumerable<Identifier> parameters = parsedParameters.Parameters;
      Token stricted = parsedParameters.Stricted;
      Token firstRestricted2 = parsedParameters.FirstRestricted;
      if (parsedParameters.Message != null)
        messageFormat = parsedParameters.Message;
      bool strict1 = this._strict;
      Statement functionSourceElements = this.ParseFunctionSourceElements();
      if (this._strict && firstRestricted2 != Token.Empty)
        this.ThrowError(firstRestricted2, messageFormat);
      if (this._strict && stricted != Token.Empty)
        this.ThrowErrorTolerant(stricted, messageFormat);
      bool strict2 = this._strict;
      this._strict = strict1;
      return (Statement) this.MarkEnd<FunctionDeclaration>(this.CreateFunctionDeclaration(variableIdentifier, parameters, (IEnumerable<Expression>) new Expression[0], functionSourceElements, strict2));
    }

    private void EnterVariableScope()
    {
      this._variableScopes.Push((IVariableScope) new VariableScope());
    }

    private IList<VariableDeclaration> LeaveVariableScope()
    {
      return this._variableScopes.Pop().VariableDeclarations;
    }

    private void EnterFunctionScope()
    {
      this._functionScopes.Push((IFunctionScope) new FunctionScope());
    }

    private IList<FunctionDeclaration> LeaveFunctionScope()
    {
      return this._functionScopes.Pop().FunctionDeclarations;
    }

    private FunctionExpression ParseFunctionExpression()
    {
      this.EnterVariableScope();
      this.EnterFunctionScope();
      Token firstRestricted1 = Token.Empty;
      string messageFormat = (string) null;
      Identifier id = (Identifier) null;
      this.MarkStart();
      this.ExpectKeyword("function");
      if (!this.Match("("))
      {
        Token lookahead = this._lookahead;
        id = this.ParseVariableIdentifier();
        if (this._strict)
        {
          if (JavaScriptParser.IsRestrictedWord((string) lookahead.Value))
            this.ThrowErrorTolerant(lookahead, Messages.StrictFunctionName);
        }
        else if (JavaScriptParser.IsRestrictedWord((string) lookahead.Value))
        {
          firstRestricted1 = lookahead;
          messageFormat = Messages.StrictFunctionName;
        }
        else if (JavaScriptParser.IsStrictModeReservedWord((string) lookahead.Value))
        {
          firstRestricted1 = lookahead;
          messageFormat = Messages.StrictReservedWord;
        }
      }
      JavaScriptParser.ParsedParameters parsedParameters = this.ParseParams(firstRestricted1);
      IEnumerable<Identifier> parameters = parsedParameters.Parameters;
      Token stricted = parsedParameters.Stricted;
      Token firstRestricted2 = parsedParameters.FirstRestricted;
      if (parsedParameters.Message != null)
        messageFormat = parsedParameters.Message;
      bool strict1 = this._strict;
      Statement functionSourceElements = this.ParseFunctionSourceElements();
      if (this._strict && firstRestricted2 != Token.Empty)
        this.ThrowError(firstRestricted2, messageFormat);
      if (this._strict && stricted != Token.Empty)
        this.ThrowErrorTolerant(stricted, messageFormat);
      bool strict2 = this._strict;
      this._strict = strict1;
      return this.MarkEnd<FunctionExpression>(this.CreateFunctionExpression(id, parameters, (IEnumerable<Expression>) new Expression[0], functionSourceElements, strict2));
    }

    private Statement ParseSourceElement()
    {
      if (this._lookahead.Type == Tokens.Keyword)
      {
        switch ((string) this._lookahead.Value)
        {
          case "const":
          case "let":
            return (Statement) this.ParseConstLetDeclaration((string) this._lookahead.Value);
          case "function":
            return this.ParseFunctionDeclaration();
          default:
            return this.ParseStatement();
        }
      }
      else
        return this._lookahead.Type != Tokens.EOF ? this.ParseStatement() : (Statement) null;
    }

    private ICollection<Statement> ParseSourceElements()
    {
      List<Statement> sourceElements = new List<Statement>();
      Token token = Token.Empty;
      while (this._index < this._length)
      {
        Token lookahead = this._lookahead;
        if (lookahead.Type == Tokens.StringLiteral)
        {
          Statement sourceElement = this.ParseSourceElement();
          sourceElements.Add(sourceElement);
          if (((ExpressionStatement) sourceElement).Expression.Type == SyntaxNodes.Literal)
          {
            if (this._source.Slice(lookahead.Range[0] + 1, lookahead.Range[1] - 1) == "use strict")
            {
              this._strict = true;
              if (token != Token.Empty)
                this.ThrowErrorTolerant(token, Messages.StrictOctalLiteral);
            }
            else if (token == Token.Empty && lookahead.Octal)
              token = lookahead;
          }
          else
            break;
        }
        else
          break;
      }
      while (this._index < this._length)
      {
        Statement sourceElement = this.ParseSourceElement();
        if (sourceElement != null)
          sourceElements.Add(sourceElement);
        else
          break;
      }
      return (ICollection<Statement>) sourceElements;
    }

    private Program ParseProgram()
    {
      this.EnterVariableScope();
      this.EnterFunctionScope();
      this.MarkStart();
      this.Peek();
      return this.MarkEnd<Program>(this.CreateProgram(this.ParseSourceElements(), this._strict));
    }

    private JavaScriptParser.LocationMarker CreateLocationMarker()
    {
      if (!this._extra.Loc.HasValue && this._extra.Range.Length == 0)
        return (JavaScriptParser.LocationMarker) null;
      this.SkipComment();
      return new JavaScriptParser.LocationMarker(this._index, this._lineNumber, this._lineStart);
    }

    public Program Parse(string code) => this.Parse(code, (ParserOptions) null);

    public Program Parse(string code, ParserOptions options)
    {
      this._source = code;
      this._index = 0;
      this._lineNumber = this._source.Length > 0 ? 1 : 0;
      this._lineStart = 0;
      this._length = this._source.Length;
      this._lookahead = (Token) null;
      this._state = new State()
      {
        AllowIn = true,
        LabelSet = new HashSet<string>(),
        InFunctionBody = false,
        InIteration = false,
        InSwitch = false,
        LastCommentStart = -1,
        MarkerStack = new Stack<int>()
      };
      this._extra = new JavaScriptParser.Extra()
      {
        Range = new int[0],
        Loc = new int?(0)
      };
      if (options != null)
      {
        if (!string.IsNullOrEmpty(options.Source))
          this._extra.Source = options.Source;
        if (options.Tokens)
          this._extra.Tokens = new List<Token>();
        if (options.Comment)
          this._extra.Comments = new List<Comment>();
        if (options.Tolerant)
          this._extra.Errors = new List<ParserException>();
      }
      Program program;
      try
      {
        program = this.ParseProgram();
        if (this._extra.Comments != null)
          program.Comments = this._extra.Comments;
        if (this._extra.Tokens != null)
          program.Tokens = this._extra.Tokens;
        if (this._extra.Errors != null)
          program.Errors = this._extra.Errors;
      }
      finally
      {
        this._extra = new JavaScriptParser.Extra();
      }
      return program;
    }

    public FunctionExpression ParseFunctionExpression(string functionExpression)
    {
      this._source = functionExpression;
      this._index = 0;
      this._lineNumber = this._source.Length > 0 ? 1 : 0;
      this._lineStart = 0;
      this._length = this._source.Length;
      this._lookahead = (Token) null;
      this._state = new State()
      {
        AllowIn = true,
        LabelSet = new HashSet<string>(),
        InFunctionBody = true,
        InIteration = false,
        InSwitch = false,
        LastCommentStart = -1,
        MarkerStack = new Stack<int>()
      };
      this._extra = new JavaScriptParser.Extra()
      {
        Range = new int[0],
        Loc = new int?(0)
      };
      this._strict = false;
      this.Peek();
      return this.ParseFunctionExpression();
    }

    private class Extra
    {
      public int? Loc;
      public int[] Range;
      public string Source;
      public List<Comment> Comments;
      public List<Token> Tokens;
      public List<ParserException> Errors;
    }

    private class LocationMarker
    {
      private readonly int[] _marker;

      public LocationMarker(int index, int lineNumber, int lineStart)
      {
        this._marker = new int[6]
        {
          index,
          lineNumber,
          index - lineStart,
          0,
          0,
          0
        };
      }

      public void End(int index, int lineNumber, int lineStart)
      {
        this._marker[3] = index;
        this._marker[4] = lineNumber;
        this._marker[5] = index - lineStart;
      }

      public void Apply(
        SyntaxNode node,
        JavaScriptParser.Extra extra,
        Func<SyntaxNode, SyntaxNode> postProcess)
      {
        if (extra.Range.Length != 0)
          node.Range = new int[2]
          {
            this._marker[0],
            this._marker[3]
          };
        if (extra.Loc.HasValue)
        {
          SyntaxNode syntaxNode = node;
          Location location = new Location();
          Position position = new Position();
          position.Line = this._marker[1];
          position.Column = this._marker[2];
          location.Start = position;
          position = new Position();
          position.Line = this._marker[4];
          position.Column = this._marker[5];
          location.End = position;
          syntaxNode.Location = location;
        }
        node = postProcess(node);
      }
    }

    private struct ParsedParameters
    {
      public Token FirstRestricted;
      public string Message;
      public IEnumerable<Identifier> Parameters;
      public Token Stricted;
    }

    private static class Regexes
    {
      public static readonly Regex NonAsciiIdentifierStart = new Regex("[ªµºÀ-ÖØ-öø-ˁˆ-ˑˠ-ˤˬˮͰ-ʹͶͷͺ-ͽΆΈ-ΊΌΎ-ΡΣ-ϵϷ-ҁҊ-ԧԱ-Ֆՙա-ևא-תװ-ײؠ-يٮٯٱ-ۓەۥۦۮۯۺ-ۼۿܐܒ-ܯݍ-ޥޱߊ-ߪߴߵߺࠀ-ࠕࠚࠤࠨࡀ-ࡘࢠࢢ-ࢬऄ-हऽॐक़-ॡॱ-ॷॹ-ॿঅ-ঌএঐও-নপ-রলশ-হঽৎড়ঢ়য়-ৡৰৱਅ-ਊਏਐਓ-ਨਪ-ਰਲਲ਼ਵਸ਼ਸਹਖ਼-ੜਫ਼ੲ-ੴઅ-ઍએ-ઑઓ-નપ-રલળવ-હઽૐૠૡଅ-ଌଏଐଓ-ନପ-ରଲଳଵ-ହଽଡ଼ଢ଼ୟ-ୡୱஃஅ-ஊஎ-ஐஒ-கஙசஜஞடணதந-பம-ஹௐఅ-ఌఎ-ఐఒ-నప-ళవ-హఽౘౙౠౡಅ-ಌಎ-ಐಒ-ನಪ-ಳವ-ಹಽೞೠೡೱೲഅ-ഌഎ-ഐഒ-ഺഽൎൠൡൺ-ൿඅ-ඖක-නඳ-රලව-ෆก-ะาำเ-ๆກຂຄງຈຊຍດ-ທນ-ຟມ-ຣລວສຫອ-ະາຳຽເ-ໄໆໜ-ໟༀཀ-ཇཉ-ཬྈ-ྌက-ဪဿၐ-ၕၚ-ၝၡၥၦၮ-ၰၵ-ႁႎႠ-ჅჇჍა-ჺჼ-ቈቊ-ቍቐ-ቖቘቚ-ቝበ-ኈኊ-ኍነ-ኰኲ-ኵኸ-ኾዀዂ-ዅወ-ዖዘ-ጐጒ-ጕጘ-ፚᎀ-ᎏᎠ-Ᏼᐁ-ᙬᙯ-ᙿᚁ-ᚚᚠ-ᛪᛮ-ᛰᜀ-ᜌᜎ-ᜑᜠ-ᜱᝀ-ᝑᝠ-ᝬᝮ-ᝰក-ឳៗៜᠠ-ᡷᢀ-ᢨᢪᢰ-ᣵᤀ-ᤜᥐ-ᥭᥰ-ᥴᦀ-ᦫᧁ-ᧇᨀ-ᨖᨠ-ᩔᪧᬅ-ᬳᭅ-ᭋᮃ-ᮠᮮᮯᮺ-ᯥᰀ-ᰣᱍ-ᱏᱚ-ᱽᳩ-ᳬᳮ-ᳱᳵᳶᴀ-ᶿḀ-ἕἘ-Ἕἠ-ὅὈ-Ὅὐ-ὗὙὛὝὟ-ώᾀ-ᾴᾶ-ᾼιῂ-ῄῆ-ῌῐ-ΐῖ-Ίῠ-Ῥῲ-ῴῶ-ῼⁱⁿₐ-ₜℂℇℊ-ℓℕℙ-ℝℤΩℨK-ℭℯ-ℹℼ-ℿⅅ-ⅉⅎⅠ-ↈⰀ-Ⱞⰰ-ⱞⱠ-ⳤⳫ-ⳮⳲⳳⴀ-ⴥⴧⴭⴰ-ⵧⵯⶀ-ⶖⶠ-ⶦⶨ-ⶮⶰ-ⶶⶸ-ⶾⷀ-ⷆⷈ-ⷎⷐ-ⷖⷘ-ⷞⸯ々-〇〡-〩〱-〵〸-〼ぁ-ゖゝ-ゟァ-ヺー-ヿㄅ-ㄭㄱ-ㆎㆠ-ㆺㇰ-ㇿ㐀-䶵一-鿌ꀀ-ꒌꓐ-ꓽꔀ-ꘌꘐ-ꘟꘪꘫꙀ-ꙮꙿ-ꚗꚠ-ꛯꜗ-ꜟꜢ-ꞈꞋ-ꞎꞐ-ꞓꞠ-Ɦꟸ-ꠁꠃ-ꠅꠇ-ꠊꠌ-ꠢꡀ-ꡳꢂ-ꢳꣲ-ꣷꣻꤊ-ꤥꤰ-ꥆꥠ-ꥼꦄ-ꦲꧏꨀ-ꨨꩀ-ꩂꩄ-ꩋꩠ-ꩶꩺꪀ-ꪯꪱꪵꪶꪹ-ꪽꫀꫂꫛ-ꫝꫠ-ꫪꫲ-ꫴꬁ-ꬆꬉ-ꬎꬑ-ꬖꬠ-ꬦꬨ-ꬮꯀ-ꯢ가-힣ힰ-ퟆퟋ-ퟻ豈-舘並-龎ﬀ-ﬆﬓ-ﬗיִײַ-ﬨשׁ-זּטּ-לּמּנּסּףּפּצּ-ﮱﯓ-ﴽﵐ-ﶏﶒ-ﷇﷰ-ﷻﹰ-ﹴﹶ-ﻼＡ-Ｚａ-ｚｦ-ﾾￂ-ￇￊ-ￏￒ-ￗￚ-ￜ]");
      public static readonly Regex NonAsciiIdentifierPart = new Regex("[ªµºÀ-ÖØ-öø-ˁˆ-ˑˠ-ˤˬˮ̀-ʹͶͷͺ-ͽΆΈ-ΊΌΎ-ΡΣ-ϵϷ-ҁ҃-҇Ҋ-ԧԱ-Ֆՙա-և֑-ׇֽֿׁׂׅׄא-תװ-ײؐ-ؚؠ-٩ٮ-ۓە-ۜ۟-۪ۨ-ۼۿܐ-݊ݍ-ޱ߀-ߵߺࠀ-࠭ࡀ-࡛ࢠࢢ-ࢬࣤ-ࣾऀ-ॣ०-९ॱ-ॷॹ-ॿঁ-ঃঅ-ঌএঐও-নপ-রলশ-হ়-ৄেৈো-ৎৗড়ঢ়য়-ৣ০-ৱਁ-ਃਅ-ਊਏਐਓ-ਨਪ-ਰਲਲ਼ਵਸ਼ਸਹ਼ਾ-ੂੇੈੋ-੍ੑਖ਼-ੜਫ਼੦-ੵઁ-ઃઅ-ઍએ-ઑઓ-નપ-રલળવ-હ઼-ૅે-ૉો-્ૐૠ-ૣ૦-૯ଁ-ଃଅ-ଌଏଐଓ-ନପ-ରଲଳଵ-ହ଼-ୄେୈୋ-୍ୖୗଡ଼ଢ଼ୟ-ୣ୦-୯ୱஂஃஅ-ஊஎ-ஐஒ-கஙசஜஞடணதந-பம-ஹா-ூெ-ைொ-்ௐௗ௦-௯ఁ-ఃఅ-ఌఎ-ఐఒ-నప-ళవ-హఽ-ౄె-ైొ-్ౕౖౘౙౠ-ౣ౦-౯ಂಃಅ-ಌಎ-ಐಒ-ನಪ-ಳವ-ಹ಼-ೄೆ-ೈೊ-್ೕೖೞೠ-ೣ೦-೯ೱೲംഃഅ-ഌഎ-ഐഒ-ഺഽ-ൄെ-ൈൊ-ൎൗൠ-ൣ൦-൯ൺ-ൿංඃඅ-ඖක-නඳ-රලව-ෆ්ා-ුූෘ-ෟෲෳก-ฺเ-๎๐-๙ກຂຄງຈຊຍດ-ທນ-ຟມ-ຣລວສຫອ-ູົ-ຽເ-ໄໆ່-ໍ໐-໙ໜ-ໟༀ༘༙༠-༩༹༵༷༾-ཇཉ-ཬཱ-྄྆-ྗྙ-ྼ࿆က-၉ၐ-ႝႠ-ჅჇჍა-ჺჼ-ቈቊ-ቍቐ-ቖቘቚ-ቝበ-ኈኊ-ኍነ-ኰኲ-ኵኸ-ኾዀዂ-ዅወ-ዖዘ-ጐጒ-ጕጘ-ፚ፝-፟ᎀ-ᎏᎠ-Ᏼᐁ-ᙬᙯ-ᙿᚁ-ᚚᚠ-ᛪᛮ-ᛰᜀ-ᜌᜎ-᜔ᜠ-᜴ᝀ-ᝓᝠ-ᝬᝮ-ᝰᝲᝳក-៓ៗៜ៝០-៩᠋-᠍᠐-᠙ᠠ-ᡷᢀ-ᢪᢰ-ᣵᤀ-ᤜᤠ-ᤫᤰ-᤻᥆-ᥭᥰ-ᥴᦀ-ᦫᦰ-ᧉ᧐-᧙ᨀ-ᨛᨠ-ᩞ᩠-᩿᩼-᪉᪐-᪙ᪧᬀ-ᭋ᭐-᭙᭫-᭳ᮀ-᯳ᰀ-᰷᱀-᱉ᱍ-ᱽ᳐-᳔᳒-ᳶᴀ-ᷦ᷼-ἕἘ-Ἕἠ-ὅὈ-Ὅὐ-ὗὙὛὝὟ-ώᾀ-ᾴᾶ-ᾼιῂ-ῄῆ-ῌῐ-ΐῖ-Ίῠ-Ῥῲ-ῴῶ-ῼ\u200C\u200D‿⁀⁔ⁱⁿₐ-ₜ⃐-⃥⃜⃡-⃰ℂℇℊ-ℓℕℙ-ℝℤΩℨK-ℭℯ-ℹℼ-ℿⅅ-ⅉⅎⅠ-ↈⰀ-Ⱞⰰ-ⱞⱠ-ⳤⳫ-ⳳⴀ-ⴥⴧⴭⴰ-ⵧⵯ⵿-ⶖⶠ-ⶦⶨ-ⶮⶰ-ⶶⶸ-ⶾⷀ-ⷆⷈ-ⷎⷐ-ⷖⷘ-ⷞⷠ-ⷿⸯ々-〇〡-〯〱-〵〸-〼ぁ-ゖ゙゚ゝ-ゟァ-ヺー-ヿㄅ-ㄭㄱ-ㆎㆠ-ㆺㇰ-ㇿ㐀-䶵一-鿌ꀀ-ꒌꓐ-ꓽꔀ-ꘌꘐ-ꘫꙀ-꙯ꙴ-꙽ꙿ-ꚗꚟ-꛱ꜗ-ꜟꜢ-ꞈꞋ-ꞎꞐ-ꞓꞠ-Ɦꟸ-ꠧꡀ-ꡳꢀ-꣄꣐-꣙꣠-ꣷꣻ꤀-꤭ꤰ-꥓ꥠ-ꥼꦀ-꧀ꧏ-꧙ꨀ-ꨶꩀ-ꩍ꩐-꩙ꩠ-ꩶꩺꩻꪀ-ꫂꫛ-ꫝꫠ-ꫯꫲ-꫶ꬁ-ꬆꬉ-ꬎꬑ-ꬖꬠ-ꬦꬨ-ꬮꯀ-ꯪ꯬꯭꯰-꯹가-힣ힰ-ퟆퟋ-ퟻ豈-舘並-龎ﬀ-ﬆﬓ-ﬗיִ-ﬨשׁ-זּטּ-לּמּנּסּףּפּצּ-ﮱﯓ-ﴽﵐ-ﶏﶒ-ﷇﷰ-ﷻ︀-️︠-︦︳︴﹍-﹏ﹰ-ﹴﹶ-ﻼ０-９Ａ-Ｚ＿ａ-ｚｦ-ﾾￂ-ￇￊ-ￏￒ-ￗￚ-ￜ]");
    }
  }
}
