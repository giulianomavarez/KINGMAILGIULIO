﻿using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;

[assembly: Extension]
[assembly: AssemblyFileVersion("2.11.58.0")]
[assembly: AssemblyInformationalVersion("2.11.58")]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: AssemblyVersion("0.0.0.0")]
