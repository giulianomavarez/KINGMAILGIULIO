﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.References.Reference
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Runtime.Environments;

#nullable disable
namespace Jint.Runtime.References
{
  public class Reference
  {
    private readonly JsValue _baseValue;
    private readonly string _name;
    private readonly bool _strict;

    public Reference(JsValue baseValue, string name, bool strict)
    {
      this._baseValue = baseValue;
      this._name = name;
      this._strict = strict;
    }

    public JsValue GetBase() => this._baseValue;

    public string GetReferencedName() => this._name;

    public bool IsStrict() => this._strict;

    public bool HasPrimitiveBase() => this._baseValue.IsPrimitive();

    public bool IsUnresolvableReference() => this._baseValue.IsUndefined();

    public bool IsPropertyReference()
    {
      return this._baseValue.IsObject() && !this._baseValue.Is<EnvironmentRecord>() || this.HasPrimitiveBase();
    }
  }
}
