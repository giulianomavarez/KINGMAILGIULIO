﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.CallStack.JintCallStack
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace Jint.Runtime.CallStack
{
  public class JintCallStack : IEnumerable<CallStackElement>, IEnumerable
  {
    private Stack<CallStackElement> _stack = new Stack<CallStackElement>();
    private Dictionary<CallStackElement, int> _statistics = new Dictionary<CallStackElement, int>((IEqualityComparer<CallStackElement>) new CallStackElementComparer());

    public int Push(CallStackElement item)
    {
      this._stack.Push(item);
      if (this._statistics.ContainsKey(item))
        return ++this._statistics[item];
      this._statistics.Add(item, 0);
      return 0;
    }

    public CallStackElement Pop()
    {
      CallStackElement key = this._stack.Pop();
      if (this._statistics[key] == 0)
        this._statistics.Remove(key);
      else
        this._statistics[key]--;
      return key;
    }

    public void Clear()
    {
      this._stack.Clear();
      this._statistics.Clear();
    }

    public IEnumerator<CallStackElement> GetEnumerator()
    {
      return (IEnumerator<CallStackElement>) this._stack.GetEnumerator();
    }

    public override string ToString()
    {
      return string.Join("->", this._stack.Select<CallStackElement, string>((Func<CallStackElement, string>) (cse => cse.ToString())).Reverse<string>());
    }

    IEnumerator IEnumerable.GetEnumerator() => (IEnumerator) this.GetEnumerator();
  }
}
