﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.TypeConverter
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Native.Number;
using Jint.Native.Object;
using Jint.Native.String;
using Jint.Parser.Ast;
using Jint.Runtime.References;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;

#nullable disable
namespace Jint.Runtime
{
  public class TypeConverter
  {
    public static JsValue ToPrimitive(JsValue input, Types preferredType = Types.None)
    {
      return input == Null.Instance || input == Undefined.Instance || input.IsPrimitive() ? input : input.AsObject().DefaultValue(preferredType);
    }

    public static bool ToBoolean(JsValue o)
    {
      if (o.IsObject())
        return true;
      if (o == Undefined.Instance || o == Null.Instance)
        return false;
      if (o.IsBoolean())
        return o.AsBoolean();
      if (o.IsNumber())
      {
        double d = o.AsNumber();
        return !d.Equals(0.0) && !double.IsNaN(d);
      }
      return !o.IsString() || !string.IsNullOrEmpty(o.AsString());
    }

    public static double ToNumber(JsValue o)
    {
      if (o.IsNumber())
        return o.AsNumber();
      if (o.IsObject() && o.AsObject() is IPrimitiveInstance primitiveInstance)
        o = primitiveInstance.PrimitiveValue;
      if (o == Undefined.Instance)
        return double.NaN;
      if (o == Null.Instance)
        return 0.0;
      if (o.IsBoolean())
        return o.AsBoolean() ? 1.0 : 0.0;
      if (!o.IsString())
        return TypeConverter.ToNumber(TypeConverter.ToPrimitive(o, Types.Number));
      string s = StringPrototype.TrimEx(o.AsString());
      if (string.IsNullOrEmpty(s))
        return 0.0;
      if ("+Infinity".Equals(s) || "Infinity".Equals(s))
        return double.PositiveInfinity;
      if ("-Infinity".Equals(s))
        return double.NegativeInfinity;
      try
      {
        if (s.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
          return (double) int.Parse(s.Substring(2), NumberStyles.HexNumber, (IFormatProvider) CultureInfo.InvariantCulture);
        char c = s[0];
        switch (c)
        {
          case '+':
          case '-':
          case '.':
            double num = double.Parse(s, NumberStyles.Float, (IFormatProvider) CultureInfo.InvariantCulture);
            return s.StartsWith("-") && num.Equals(0.0) ? -0.0 : num;
          default:
            if (!char.IsDigit(c))
              return double.NaN;
            goto case '+';
        }
      }
      catch (OverflowException ex)
      {
        return s.StartsWith("-") ? double.NegativeInfinity : double.PositiveInfinity;
      }
      catch
      {
        return double.NaN;
      }
    }

    public static double ToInteger(JsValue o)
    {
      double number = TypeConverter.ToNumber(o);
      if (double.IsNaN(number))
        return 0.0;
      return number.Equals(0.0) || double.IsInfinity(number) ? number : (double) (long) number;
    }

    public static int ToInt32(JsValue o) => (int) (uint) TypeConverter.ToNumber(o);

    public static uint ToUint32(JsValue o) => (uint) TypeConverter.ToNumber(o);

    public static ushort ToUint16(JsValue o) => (ushort) (uint) TypeConverter.ToNumber(o);

    public static string ToString(JsValue o)
    {
      if (o.IsObject() && o.AsObject() is IPrimitiveInstance primitiveInstance)
        o = primitiveInstance.PrimitiveValue;
      if (o.IsString())
        return o.AsString();
      if (o == Undefined.Instance)
        return Undefined.Text;
      if (o == Null.Instance)
        return Null.Text;
      return o.IsBoolean() ? (!o.AsBoolean() ? "false" : "true") : (o.IsNumber() ? NumberPrototype.ToNumberString(o.AsNumber()) : TypeConverter.ToString(TypeConverter.ToPrimitive(o, Types.String)));
    }

    public static ObjectInstance ToObject(Engine engine, JsValue value)
    {
      if (value.IsObject())
        return value.AsObject();
      if (value == Undefined.Instance)
        throw new JavaScriptException(engine.TypeError);
      if (value == Null.Instance)
        throw new JavaScriptException(engine.TypeError);
      if (value.IsBoolean())
        return (ObjectInstance) engine.Boolean.Construct(value.AsBoolean());
      if (value.IsNumber())
        return (ObjectInstance) engine.Number.Construct(value.AsNumber());
      if (value.IsString())
        return (ObjectInstance) engine.String.Construct(value.AsString());
      throw new JavaScriptException(engine.TypeError);
    }

    public static Types GetPrimitiveType(JsValue value)
    {
      if (!value.IsObject())
        return value.Type;
      IPrimitiveInstance primitiveInstance = value.TryCast<IPrimitiveInstance>();
      return primitiveInstance != null ? primitiveInstance.Type : Types.Object;
    }

    public static void CheckObjectCoercible(
      Engine engine,
      JsValue o,
      MemberExpression expression,
      object baseReference)
    {
      if ((!(o != Undefined.Instance) || !(o != Null.Instance)) && (engine.Options._ReferenceResolver == null || !engine.Options._ReferenceResolver.CheckCoercible(o)))
      {
        string message = string.Empty;
        message = baseReference is Reference reference ? string.Format("{0} is {1}", (object) reference.GetReferencedName(), (object) o) : throw new JavaScriptException(engine.TypeError, message).SetCallstack(engine, expression.Location);
      }
    }

    public static void CheckObjectCoercible(Engine engine, JsValue o)
    {
      if (o == Undefined.Instance || o == Null.Instance)
        throw new JavaScriptException(engine.TypeError);
    }

    public static IEnumerable<MethodBase> FindBestMatch(
      Engine engine,
      MethodBase[] methods,
      JsValue[] arguments)
    {
      methods = ((IEnumerable<MethodBase>) methods).Where<MethodBase>((Func<MethodBase, bool>) (m => ((IEnumerable<ParameterInfo>) m.GetParameters()).Count<ParameterInfo>() == arguments.Length)).ToArray<MethodBase>();
      if (methods.Length == 1 && !((IEnumerable<ParameterInfo>) methods[0].GetParameters()).Any<ParameterInfo>())
      {
        yield return methods[0];
      }
      else
      {
        object[] objectArguments = ((IEnumerable<JsValue>) arguments).Select<JsValue, object>((Func<JsValue, object>) (x => x.ToObject())).ToArray<object>();
        MethodBase[] methodBaseArray = methods;
        int index;
        for (index = 0; index < methodBaseArray.Length; ++index)
        {
          MethodBase methodBase = methodBaseArray[index];
          bool flag = true;
          ParameterInfo[] parameters = methodBase.GetParameters();
          for (int index1 = 0; index1 < arguments.Length; ++index1)
          {
            object obj = objectArguments[index1];
            Type parameterType = parameters[index1].ParameterType;
            if (obj == null)
            {
              if (!TypeConverter.TypeIsNullable(parameterType))
              {
                flag = false;
                break;
              }
            }
            else if (obj.GetType() != parameterType)
            {
              flag = false;
              break;
            }
          }
          if (flag)
          {
            yield return methodBase;
            yield break;
          }
        }
        methodBaseArray = (MethodBase[]) null;
        methodBaseArray = methods;
        for (index = 0; index < methodBaseArray.Length; ++index)
          yield return methodBaseArray[index];
        methodBaseArray = (MethodBase[]) null;
      }
    }

    public static bool TypeIsNullable(Type type)
    {
      return !type.IsValueType() || Nullable.GetUnderlyingType(type) != (Type) null;
    }
  }
}
