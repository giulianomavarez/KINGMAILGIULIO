﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Descriptors.PropertyDescriptor
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Native.Object;

#nullable disable
namespace Jint.Runtime.Descriptors
{
  public class PropertyDescriptor
  {
    public static PropertyDescriptor Undefined = new PropertyDescriptor();

    public PropertyDescriptor()
    {
    }

    public PropertyDescriptor(JsValue value, bool? writable, bool? enumerable, bool? configurable)
    {
      this.Value = value;
      if (writable.HasValue)
        this.Writable = new bool?(writable.Value);
      if (enumerable.HasValue)
        this.Enumerable = new bool?(enumerable.Value);
      if (!configurable.HasValue)
        return;
      this.Configurable = new bool?(configurable.Value);
    }

    public PropertyDescriptor(JsValue get, JsValue set, bool? enumerable = null, bool? configurable = null)
    {
      this.Get = get;
      this.Set = set;
      if (enumerable.HasValue)
        this.Enumerable = new bool?(enumerable.Value);
      if (!configurable.HasValue)
        return;
      this.Configurable = new bool?(configurable.Value);
    }

    public PropertyDescriptor(PropertyDescriptor descriptor)
    {
      this.Get = descriptor.Get;
      this.Set = descriptor.Set;
      this.Value = descriptor.Value;
      this.Enumerable = descriptor.Enumerable;
      this.Configurable = descriptor.Configurable;
      this.Writable = descriptor.Writable;
    }

    public JsValue Get { get; set; }

    public JsValue Set { get; set; }

    public bool? Enumerable { get; set; }

    public bool? Writable { get; set; }

    public bool? Configurable { get; set; }

    public virtual JsValue Value { get; set; }

    public bool IsAccessorDescriptor()
    {
      return !(this.Get == (JsValue) null) || !(this.Set == (JsValue) null);
    }

    public bool IsDataDescriptor() => this.Writable.HasValue || !(this.Value == (JsValue) null);

    public bool IsGenericDescriptor() => !this.IsDataDescriptor() && !this.IsAccessorDescriptor();

    public static PropertyDescriptor ToPropertyDescriptor(Engine engine, JsValue o)
    {
      ObjectInstance objectInstance = o.TryCast<ObjectInstance>();
      if (objectInstance == null)
        throw new JavaScriptException(engine.TypeError);
      if ((objectInstance.HasProperty("value") || objectInstance.HasProperty("writable")) && (objectInstance.HasProperty("get") || objectInstance.HasProperty("set")))
        throw new JavaScriptException(engine.TypeError);
      PropertyDescriptor propertyDescriptor = new PropertyDescriptor();
      if (objectInstance.HasProperty("enumerable"))
        propertyDescriptor.Enumerable = new bool?(TypeConverter.ToBoolean(objectInstance.Get("enumerable")));
      if (objectInstance.HasProperty("configurable"))
        propertyDescriptor.Configurable = new bool?(TypeConverter.ToBoolean(objectInstance.Get("configurable")));
      if (objectInstance.HasProperty("value"))
      {
        JsValue jsValue = objectInstance.Get("value");
        propertyDescriptor.Value = jsValue;
      }
      if (objectInstance.HasProperty("writable"))
        propertyDescriptor.Writable = new bool?(TypeConverter.ToBoolean(objectInstance.Get("writable")));
      if (objectInstance.HasProperty("get"))
      {
        JsValue jsValue = objectInstance.Get("get");
        propertyDescriptor.Get = !(jsValue != JsValue.Undefined) || jsValue.TryCast<ICallable>() != null ? jsValue : throw new JavaScriptException(engine.TypeError);
      }
      if (objectInstance.HasProperty("set"))
      {
        JsValue jsValue = objectInstance.Get("set");
        propertyDescriptor.Set = !(jsValue != Jint.Native.Undefined.Instance) || jsValue.TryCast<ICallable>() != null ? jsValue : throw new JavaScriptException(engine.TypeError);
      }
      if ((propertyDescriptor.Get != (JsValue) null || propertyDescriptor.Get != (JsValue) null) && (propertyDescriptor.Value != (JsValue) null || propertyDescriptor.Writable.HasValue))
        throw new JavaScriptException(engine.TypeError);
      return propertyDescriptor;
    }

    public static JsValue FromPropertyDescriptor(Engine engine, PropertyDescriptor desc)
    {
      if (desc == PropertyDescriptor.Undefined)
        return Jint.Native.Undefined.Instance;
      ObjectInstance objectInstance1 = engine.Object.Construct(Arguments.Empty);
      bool? nullable;
      if (desc.IsDataDescriptor())
      {
        objectInstance1.DefineOwnProperty("value", new PropertyDescriptor(desc.Value != (JsValue) null ? desc.Value : Jint.Native.Undefined.Instance, new bool?(true), new bool?(true), new bool?(true)), false);
        ObjectInstance objectInstance2 = objectInstance1;
        nullable = desc.Writable;
        int num;
        if (nullable.HasValue)
        {
          nullable = desc.Writable;
          num = nullable.Value ? 1 : 0;
        }
        else
          num = 0;
        PropertyDescriptor desc1 = new PropertyDescriptor((JsValue) (num != 0), new bool?(true), new bool?(true), new bool?(true));
        objectInstance2.DefineOwnProperty("writable", desc1, false);
      }
      else
      {
        ObjectInstance objectInstance3 = objectInstance1;
        JsValue jsValue1 = desc.Get;
        if ((object) jsValue1 == null)
          jsValue1 = Jint.Native.Undefined.Instance;
        PropertyDescriptor desc2 = new PropertyDescriptor(jsValue1, new bool?(true), new bool?(true), new bool?(true));
        objectInstance3.DefineOwnProperty("get", desc2, false);
        ObjectInstance objectInstance4 = objectInstance1;
        JsValue jsValue2 = desc.Set;
        if ((object) jsValue2 == null)
          jsValue2 = Jint.Native.Undefined.Instance;
        PropertyDescriptor desc3 = new PropertyDescriptor(jsValue2, new bool?(true), new bool?(true), new bool?(true));
        objectInstance4.DefineOwnProperty("set", desc3, false);
      }
      ObjectInstance objectInstance5 = objectInstance1;
      nullable = desc.Enumerable;
      int num1;
      if (nullable.HasValue)
      {
        nullable = desc.Enumerable;
        num1 = nullable.Value ? 1 : 0;
      }
      else
        num1 = 0;
      PropertyDescriptor desc4 = new PropertyDescriptor((JsValue) (num1 != 0), new bool?(true), new bool?(true), new bool?(true));
      objectInstance5.DefineOwnProperty("enumerable", desc4, false);
      ObjectInstance objectInstance6 = objectInstance1;
      nullable = desc.Configurable;
      int num2;
      if (nullable.HasValue)
      {
        nullable = desc.Configurable;
        num2 = nullable.Value ? 1 : 0;
      }
      else
        num2 = 0;
      PropertyDescriptor desc5 = new PropertyDescriptor((JsValue) (num2 != 0), new bool?(true), new bool?(true), new bool?(true));
      objectInstance6.DefineOwnProperty("configurable", desc5, false);
      return (JsValue) objectInstance1;
    }
  }
}
