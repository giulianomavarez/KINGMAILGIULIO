﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Descriptors.Specialized.FieldInfoDescriptor
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using System;
using System.Globalization;
using System.Reflection;

#nullable disable
namespace Jint.Runtime.Descriptors.Specialized
{
  public sealed class FieldInfoDescriptor : PropertyDescriptor
  {
    private readonly Engine _engine;
    private readonly FieldInfo _fieldInfo;
    private readonly object _item;

    public FieldInfoDescriptor(Engine engine, FieldInfo fieldInfo, object item)
    {
      this._engine = engine;
      this._fieldInfo = fieldInfo;
      this._item = item;
      this.Writable = new bool?(!fieldInfo.Attributes.HasFlag((Enum) FieldAttributes.InitOnly));
    }

    public override JsValue Value
    {
      get => JsValue.FromObject(this._engine, this._fieldInfo.GetValue(this._item));
      set
      {
        JsValue jsValue = value;
        object obj;
        if (this._fieldInfo.FieldType == typeof (JsValue))
        {
          obj = (object) jsValue;
        }
        else
        {
          obj = jsValue.ToObject();
          if (obj.GetType() != this._fieldInfo.FieldType)
            obj = this._engine.ClrTypeConverter.Convert(obj, this._fieldInfo.FieldType, (IFormatProvider) CultureInfo.InvariantCulture);
        }
        this._fieldInfo.SetValue(this._item, obj);
      }
    }
  }
}
