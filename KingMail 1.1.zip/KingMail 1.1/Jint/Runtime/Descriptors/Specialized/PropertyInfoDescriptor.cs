﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Descriptors.Specialized.PropertyInfoDescriptor
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using System;
using System.Globalization;
using System.Reflection;

#nullable disable
namespace Jint.Runtime.Descriptors.Specialized
{
  public sealed class PropertyInfoDescriptor : PropertyDescriptor
  {
    private readonly Engine _engine;
    private readonly PropertyInfo _propertyInfo;
    private readonly object _item;

    public PropertyInfoDescriptor(Engine engine, PropertyInfo propertyInfo, object item)
    {
      this._engine = engine;
      this._propertyInfo = propertyInfo;
      this._item = item;
      this.Writable = new bool?(propertyInfo.CanWrite);
    }

    public override JsValue Value
    {
      get
      {
        return JsValue.FromObject(this._engine, this._propertyInfo.GetValue(this._item, (object[]) null));
      }
      set
      {
        JsValue jsValue = value;
        object obj;
        if (this._propertyInfo.PropertyType == typeof (JsValue))
        {
          obj = (object) jsValue;
        }
        else
        {
          obj = jsValue.ToObject();
          if (obj != null && obj.GetType() != this._propertyInfo.PropertyType)
            obj = this._engine.ClrTypeConverter.Convert(obj, this._propertyInfo.PropertyType, (IFormatProvider) CultureInfo.InvariantCulture);
        }
        this._propertyInfo.SetValue(this._item, obj, (object[]) null);
      }
    }
  }
}
