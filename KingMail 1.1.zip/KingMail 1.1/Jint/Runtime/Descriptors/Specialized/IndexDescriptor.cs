﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Descriptors.Specialized.IndexDescriptor
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using System;
using System.Globalization;
using System.Reflection;

#nullable disable
namespace Jint.Runtime.Descriptors.Specialized
{
  public sealed class IndexDescriptor : PropertyDescriptor
  {
    private readonly Engine _engine;
    private readonly object _key;
    private readonly object _item;
    private readonly PropertyInfo _indexer;
    private readonly MethodInfo _containsKey;

    public IndexDescriptor(Engine engine, Type targetType, string key, object item)
    {
      this._engine = engine;
      this._item = item;
      foreach (PropertyInfo property in targetType.GetProperties())
      {
        if (property.GetIndexParameters().Length == 1 && (property.GetGetMethod() != (MethodInfo) null || property.GetSetMethod() != (MethodInfo) null))
        {
          Type parameterType = property.GetIndexParameters()[0].ParameterType;
          if (this._engine.ClrTypeConverter.TryConvert((object) key, parameterType, (IFormatProvider) CultureInfo.InvariantCulture, out this._key))
          {
            this._indexer = property;
            this._containsKey = targetType.GetMethod("ContainsKey", new Type[1]
            {
              parameterType
            });
            break;
          }
        }
      }
      if (this._indexer == (PropertyInfo) null)
        throw new InvalidOperationException("No matching indexer found.");
      this.Writable = new bool?(true);
    }

    public IndexDescriptor(Engine engine, string key, object item)
      : this(engine, item.GetType(), key, item)
    {
    }

    public override JsValue Value
    {
      get
      {
        MethodInfo getMethod = this._indexer.GetGetMethod();
        if (getMethod == (MethodInfo) null)
          throw new InvalidOperationException("Indexer has no public getter.");
        object[] parameters = new object[1]{ this._key };
        if (this._containsKey != (MethodInfo) null)
        {
          bool? nullable = this._containsKey.Invoke(this._item, parameters) as bool?;
          bool flag = true;
          if ((nullable.GetValueOrDefault() == flag ? (!nullable.HasValue ? 1 : 0) : 1) != 0)
            return JsValue.Undefined;
        }
        try
        {
          return JsValue.FromObject(this._engine, getMethod.Invoke(this._item, parameters));
        }
        catch
        {
          return JsValue.Undefined;
        }
      }
      set
      {
        MethodInfo setMethod = this._indexer.GetSetMethod();
        if (setMethod == (MethodInfo) null)
          throw new InvalidOperationException("Indexer has no public setter.");
        object[] parameters = new object[2]
        {
          this._key,
          value != (JsValue) null ? value.ToObject() : (object) null
        };
        setMethod.Invoke(this._item, parameters);
      }
    }
  }
}
