﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Descriptors.Specialized.ClrAccessDescriptor
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Native.Object;
using Jint.Runtime.Interop;
using System;

#nullable disable
namespace Jint.Runtime.Descriptors.Specialized
{
  public sealed class ClrAccessDescriptor(
    Engine engine,
    Func<JsValue, JsValue> get,
    Action<JsValue, JsValue> set) : PropertyDescriptor((JsValue) (ObjectInstance) new GetterFunctionInstance(engine, get), set == null ? Jint.Native.Undefined.Instance : (JsValue) (ObjectInstance) new SetterFunctionInstance(engine, set))
  {
    public ClrAccessDescriptor(Engine engine, Func<JsValue, JsValue> get)
      : this(engine, get, (Action<JsValue, JsValue>) null)
    {
    }
  }
}
