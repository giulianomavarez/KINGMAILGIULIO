﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.ExpressionInterpreter
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Native.Function;
using Jint.Native.Number;
using Jint.Native.Object;
using Jint.Native.RegExp;
using Jint.Parser;
using Jint.Parser.Ast;
using Jint.Runtime.Descriptors;
using Jint.Runtime.Environments;
using Jint.Runtime.Interop;
using Jint.Runtime.References;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace Jint.Runtime
{
  public class ExpressionInterpreter
  {
    private readonly Engine _engine;

    public ExpressionInterpreter(Engine engine) => this._engine = engine;

    private object EvaluateExpression(Expression expression)
    {
      return this._engine.EvaluateExpression(expression);
    }

    public JsValue EvaluateConditionalExpression(ConditionalExpression conditionalExpression)
    {
      return TypeConverter.ToBoolean(this._engine.GetValue(this._engine.EvaluateExpression(conditionalExpression.Test))) ? this._engine.GetValue(this._engine.EvaluateExpression(conditionalExpression.Consequent)) : this._engine.GetValue(this._engine.EvaluateExpression(conditionalExpression.Alternate));
    }

    public JsValue EvaluateAssignmentExpression(AssignmentExpression assignmentExpression)
    {
      Reference expression = this.EvaluateExpression(assignmentExpression.Left) as Reference;
      JsValue assignmentExpression1 = this._engine.GetValue(this.EvaluateExpression(assignmentExpression.Right));
      if (expression == null)
        throw new JavaScriptException(this._engine.ReferenceError);
      if (assignmentExpression.Operator == AssignmentOperator.Assign)
      {
        if (expression.IsStrict() && expression.GetBase().TryCast<EnvironmentRecord>() != null && (expression.GetReferencedName() == "eval" || expression.GetReferencedName() == "arguments"))
          throw new JavaScriptException(this._engine.SyntaxError);
        this._engine.PutValue(expression, assignmentExpression1);
        return assignmentExpression1;
      }
      JsValue jsValue = this._engine.GetValue((object) expression);
      JsValue assignmentExpression2;
      switch (assignmentExpression.Operator)
      {
        case AssignmentOperator.PlusAssign:
          JsValue primitive1 = TypeConverter.ToPrimitive(jsValue);
          JsValue primitive2 = TypeConverter.ToPrimitive(assignmentExpression1);
          assignmentExpression2 = primitive1.IsString() || primitive2.IsString() ? (JsValue) (TypeConverter.ToString(primitive1) + TypeConverter.ToString(primitive2)) : (JsValue) (TypeConverter.ToNumber(primitive1) + TypeConverter.ToNumber(primitive2));
          break;
        case AssignmentOperator.MinusAssign:
          assignmentExpression2 = (JsValue) (TypeConverter.ToNumber(jsValue) - TypeConverter.ToNumber(assignmentExpression1));
          break;
        case AssignmentOperator.TimesAssign:
          assignmentExpression2 = jsValue == Undefined.Instance || assignmentExpression1 == Undefined.Instance ? Undefined.Instance : (JsValue) (TypeConverter.ToNumber(jsValue) * TypeConverter.ToNumber(assignmentExpression1));
          break;
        case AssignmentOperator.DivideAssign:
          assignmentExpression2 = this.Divide(jsValue, assignmentExpression1);
          break;
        case AssignmentOperator.ModuloAssign:
          assignmentExpression2 = jsValue == Undefined.Instance || assignmentExpression1 == Undefined.Instance ? Undefined.Instance : (JsValue) (TypeConverter.ToNumber(jsValue) % TypeConverter.ToNumber(assignmentExpression1));
          break;
        case AssignmentOperator.BitwiseAndAssign:
          assignmentExpression2 = (JsValue) (double) (TypeConverter.ToInt32(jsValue) & TypeConverter.ToInt32(assignmentExpression1));
          break;
        case AssignmentOperator.BitwiseOrAssign:
          assignmentExpression2 = (JsValue) (double) (TypeConverter.ToInt32(jsValue) | TypeConverter.ToInt32(assignmentExpression1));
          break;
        case AssignmentOperator.BitwiseXOrAssign:
          assignmentExpression2 = (JsValue) (double) (TypeConverter.ToInt32(jsValue) ^ TypeConverter.ToInt32(assignmentExpression1));
          break;
        case AssignmentOperator.LeftShiftAssign:
          assignmentExpression2 = (JsValue) (double) (TypeConverter.ToInt32(jsValue) << (int) TypeConverter.ToUint32(assignmentExpression1));
          break;
        case AssignmentOperator.RightShiftAssign:
          assignmentExpression2 = (JsValue) (double) (TypeConverter.ToInt32(jsValue) >> (int) TypeConverter.ToUint32(assignmentExpression1));
          break;
        case AssignmentOperator.UnsignedRightShiftAssign:
          assignmentExpression2 = (JsValue) (double) (uint) (TypeConverter.ToInt32(jsValue) >>> ((int) TypeConverter.ToUint32(assignmentExpression1) & 31));
          break;
        default:
          throw new NotImplementedException();
      }
      this._engine.PutValue(expression, assignmentExpression2);
      return assignmentExpression2;
    }

    private JsValue Divide(JsValue lval, JsValue rval)
    {
      if (lval == Undefined.Instance || rval == Undefined.Instance)
        return Undefined.Instance;
      double number1 = TypeConverter.ToNumber(lval);
      double number2 = TypeConverter.ToNumber(rval);
      if (double.IsNaN(number2) || double.IsNaN(number1))
        return (JsValue) double.NaN;
      if (double.IsInfinity(number1) && double.IsInfinity(number2))
        return (JsValue) double.NaN;
      if (double.IsInfinity(number1) && number2.Equals(0.0))
        return NumberInstance.IsNegativeZero(number2) ? (JsValue) -number1 : (JsValue) number1;
      if (number1.Equals(0.0) && number2.Equals(0.0))
        return (JsValue) double.NaN;
      if (!number2.Equals(0.0))
        return (JsValue) (number1 / number2);
      return NumberInstance.IsNegativeZero(number2) ? (JsValue) (number1 > 0.0 ? double.NegativeInfinity : double.PositiveInfinity) : (JsValue) (number1 > 0.0 ? double.PositiveInfinity : double.NegativeInfinity);
    }

    public JsValue EvaluateBinaryExpression(BinaryExpression expression)
    {
      JsValue jsValue1 = this._engine.GetValue(this.EvaluateExpression(expression.Left));
      JsValue jsValue2 = this._engine.GetValue(this.EvaluateExpression(expression.Right));
      JsValue binaryExpression;
      switch (expression.Operator)
      {
        case BinaryOperator.Plus:
          JsValue primitive1 = TypeConverter.ToPrimitive(jsValue1);
          JsValue primitive2 = TypeConverter.ToPrimitive(jsValue2);
          binaryExpression = primitive1.IsString() || primitive2.IsString() ? (JsValue) (TypeConverter.ToString(primitive1) + TypeConverter.ToString(primitive2)) : (JsValue) (TypeConverter.ToNumber(primitive1) + TypeConverter.ToNumber(primitive2));
          break;
        case BinaryOperator.Minus:
          binaryExpression = (JsValue) (TypeConverter.ToNumber(jsValue1) - TypeConverter.ToNumber(jsValue2));
          break;
        case BinaryOperator.Times:
          binaryExpression = jsValue1 == Undefined.Instance || jsValue2 == Undefined.Instance ? Undefined.Instance : (JsValue) (TypeConverter.ToNumber(jsValue1) * TypeConverter.ToNumber(jsValue2));
          break;
        case BinaryOperator.Divide:
          binaryExpression = this.Divide(jsValue1, jsValue2);
          break;
        case BinaryOperator.Modulo:
          binaryExpression = jsValue1 == Undefined.Instance || jsValue2 == Undefined.Instance ? Undefined.Instance : (JsValue) (TypeConverter.ToNumber(jsValue1) % TypeConverter.ToNumber(jsValue2));
          break;
        case BinaryOperator.Equal:
          binaryExpression = (JsValue) ExpressionInterpreter.Equal(jsValue1, jsValue2);
          break;
        case BinaryOperator.NotEqual:
          binaryExpression = (JsValue) !ExpressionInterpreter.Equal(jsValue1, jsValue2);
          break;
        case BinaryOperator.Greater:
          binaryExpression = ExpressionInterpreter.Compare(jsValue2, jsValue1, false);
          if (binaryExpression == Undefined.Instance)
          {
            binaryExpression = (JsValue) false;
            break;
          }
          break;
        case BinaryOperator.GreaterOrEqual:
          JsValue jsValue3 = ExpressionInterpreter.Compare(jsValue1, jsValue2);
          binaryExpression = jsValue3 == Undefined.Instance || jsValue3.AsBoolean() ? (JsValue) false : (JsValue) true;
          break;
        case BinaryOperator.Less:
          binaryExpression = ExpressionInterpreter.Compare(jsValue1, jsValue2);
          if (binaryExpression == Undefined.Instance)
          {
            binaryExpression = (JsValue) false;
            break;
          }
          break;
        case BinaryOperator.LessOrEqual:
          JsValue jsValue4 = ExpressionInterpreter.Compare(jsValue2, jsValue1, false);
          binaryExpression = jsValue4 == Undefined.Instance || jsValue4.AsBoolean() ? (JsValue) false : (JsValue) true;
          break;
        case BinaryOperator.StrictlyEqual:
          return (JsValue) ExpressionInterpreter.StrictlyEqual(jsValue1, jsValue2);
        case BinaryOperator.StricltyNotEqual:
          return (JsValue) !ExpressionInterpreter.StrictlyEqual(jsValue1, jsValue2);
        case BinaryOperator.BitwiseAnd:
          return (JsValue) (double) (TypeConverter.ToInt32(jsValue1) & TypeConverter.ToInt32(jsValue2));
        case BinaryOperator.BitwiseOr:
          return (JsValue) (double) (TypeConverter.ToInt32(jsValue1) | TypeConverter.ToInt32(jsValue2));
        case BinaryOperator.BitwiseXOr:
          return (JsValue) (double) (TypeConverter.ToInt32(jsValue1) ^ TypeConverter.ToInt32(jsValue2));
        case BinaryOperator.LeftShift:
          return (JsValue) (double) (TypeConverter.ToInt32(jsValue1) << (int) TypeConverter.ToUint32(jsValue2));
        case BinaryOperator.RightShift:
          return (JsValue) (double) (TypeConverter.ToInt32(jsValue1) >> (int) TypeConverter.ToUint32(jsValue2));
        case BinaryOperator.UnsignedRightShift:
          return (JsValue) (double) (uint) (TypeConverter.ToInt32(jsValue1) >>> ((int) TypeConverter.ToUint32(jsValue2) & 31));
        case BinaryOperator.InstanceOf:
          binaryExpression = (JsValue) (jsValue2.TryCast<FunctionInstance>() ?? throw new JavaScriptException(this._engine.TypeError, "instanceof can only be used with a function object")).HasInstance(jsValue1);
          break;
        case BinaryOperator.In:
          binaryExpression = jsValue2.IsObject() ? (JsValue) jsValue2.AsObject().HasProperty(TypeConverter.ToString(jsValue1)) : throw new JavaScriptException(this._engine.TypeError, "in can only be used with an object");
          break;
        default:
          throw new NotImplementedException();
      }
      return binaryExpression;
    }

    public JsValue EvaluateLogicalExpression(LogicalExpression logicalExpression)
    {
      JsValue o = this._engine.GetValue(this.EvaluateExpression(logicalExpression.Left));
      switch (logicalExpression.Operator)
      {
        case LogicalOperator.LogicalAnd:
          return !TypeConverter.ToBoolean(o) ? o : this._engine.GetValue(this.EvaluateExpression(logicalExpression.Right));
        case LogicalOperator.LogicalOr:
          return TypeConverter.ToBoolean(o) ? o : this._engine.GetValue(this.EvaluateExpression(logicalExpression.Right));
        default:
          throw new NotImplementedException();
      }
    }

    public static bool Equal(JsValue x, JsValue y)
    {
      Types type1 = x.Type;
      Types type2 = y.Type;
      if (type1 == type2)
        return ExpressionInterpreter.StrictlyEqual(x, y);
      if (x == Null.Instance && y == Undefined.Instance || x == Undefined.Instance && y == Null.Instance)
        return true;
      if (type1 == Types.Number && type2 == Types.String)
        return ExpressionInterpreter.Equal(x, (JsValue) TypeConverter.ToNumber(y));
      if (type1 == Types.String && type2 == Types.Number)
        return ExpressionInterpreter.Equal((JsValue) TypeConverter.ToNumber(x), y);
      if (type1 == Types.Boolean)
        return ExpressionInterpreter.Equal((JsValue) TypeConverter.ToNumber(x), y);
      switch (type2)
      {
        case Types.Boolean:
          return ExpressionInterpreter.Equal(x, (JsValue) TypeConverter.ToNumber(y));
        case Types.Object:
          if (type1 == Types.String || type1 == Types.Number)
            return ExpressionInterpreter.Equal(x, TypeConverter.ToPrimitive(y));
          break;
      }
      return type1 == Types.Object && (type2 == Types.String || type2 == Types.Number) && ExpressionInterpreter.Equal(TypeConverter.ToPrimitive(x), y);
    }

    public static bool StrictlyEqual(JsValue x, JsValue y)
    {
      Types type1 = x.Type;
      Types type2 = y.Type;
      if (type1 != type2)
        return false;
      switch (type1)
      {
        case Types.None:
          return true;
        case Types.Undefined:
        case Types.Null:
          return true;
        case Types.Boolean:
          return x.AsBoolean() == y.AsBoolean();
        case Types.String:
          return x.AsString() == y.AsString();
        case Types.Number:
          double d1 = x.AsNumber();
          double d2 = y.AsNumber();
          return !double.IsNaN(d1) && !double.IsNaN(d2) && d1.Equals(d2);
        case Types.Object:
          if (x.AsObject() is IObjectWrapper objectWrapper1)
          {
            IObjectWrapper objectWrapper = y.AsObject() as IObjectWrapper;
            return object.Equals(objectWrapper1.Target, objectWrapper.Target);
          }
          break;
      }
      return x == y;
    }

    public static bool SameValue(JsValue x, JsValue y)
    {
      Types primitiveType1 = TypeConverter.GetPrimitiveType(x);
      Types primitiveType2 = TypeConverter.GetPrimitiveType(y);
      if (primitiveType1 != primitiveType2)
        return false;
      switch (primitiveType1)
      {
        case Types.None:
          return true;
        case Types.Boolean:
          return TypeConverter.ToBoolean(x) == TypeConverter.ToBoolean(y);
        case Types.String:
          return TypeConverter.ToString(x) == TypeConverter.ToString(y);
        case Types.Number:
          double number1 = TypeConverter.ToNumber(x);
          double number2 = TypeConverter.ToNumber(y);
          if (double.IsNaN(number1) && double.IsNaN(number2))
            return true;
          if (!number1.Equals(number2))
            return false;
          return !number1.Equals(0.0) || NumberInstance.IsNegativeZero(number1) == NumberInstance.IsNegativeZero(number2);
        default:
          return x == y;
      }
    }

    public static JsValue Compare(JsValue x, JsValue y, bool leftFirst = true)
    {
      JsValue primitive1;
      JsValue primitive2;
      if (leftFirst)
      {
        primitive1 = TypeConverter.ToPrimitive(x, Types.Number);
        primitive2 = TypeConverter.ToPrimitive(y, Types.Number);
      }
      else
      {
        primitive2 = TypeConverter.ToPrimitive(y, Types.Number);
        primitive1 = TypeConverter.ToPrimitive(x, Types.Number);
      }
      int type1 = (int) primitive1.Type;
      Types type2 = primitive2.Type;
      if (type1 == 4 && type2 == Types.String)
        return (JsValue) (string.CompareOrdinal(TypeConverter.ToString(x), TypeConverter.ToString(y)) < 0);
      double number1 = TypeConverter.ToNumber(primitive1);
      double number2 = TypeConverter.ToNumber(primitive2);
      if (double.IsNaN(number1) || double.IsNaN(number2))
        return Undefined.Instance;
      if (number1.Equals(number2))
        return (JsValue) false;
      if (double.IsPositiveInfinity(number1))
        return (JsValue) false;
      if (double.IsPositiveInfinity(number2))
        return (JsValue) true;
      if (double.IsNegativeInfinity(number2))
        return (JsValue) false;
      return double.IsNegativeInfinity(number1) ? (JsValue) true : (JsValue) (number1 < number2);
    }

    public Reference EvaluateIdentifier(Identifier identifier)
    {
      LexicalEnvironment lexicalEnvironment = this._engine.ExecutionContext.LexicalEnvironment;
      bool isStrictModeCode = StrictModeScope.IsStrictModeCode;
      string name = identifier.Name;
      int num = isStrictModeCode ? 1 : 0;
      return LexicalEnvironment.GetIdentifierReference(lexicalEnvironment, name, num != 0);
    }

    public JsValue EvaluateLiteral(Literal literal)
    {
      if (literal.Cached)
        return literal.CachedValue;
      if (literal.Type == SyntaxNodes.RegularExpressionLiteral)
      {
        RegExpInstance literal1 = this._engine.RegExp.Construct(literal.Raw);
        if (literal1.Global)
          return (JsValue) (ObjectInstance) literal1;
        literal.CachedValue = (JsValue) (ObjectInstance) literal1;
      }
      else
        literal.CachedValue = JsValue.FromObject(this._engine, literal.Value);
      literal.Cached = true;
      return literal.CachedValue;
    }

    public JsValue EvaluateObjectExpression(ObjectExpression objectExpression)
    {
      ObjectInstance objectExpression1 = this._engine.Object.Construct(Arguments.Empty);
      foreach (Property property in objectExpression.Properties)
      {
        string key = property.Key.GetKey();
        PropertyDescriptor ownProperty = objectExpression1.GetOwnProperty(key);
        PropertyDescriptor desc;
        switch (property.Kind)
        {
          case PropertyKind.Data:
            desc = new PropertyDescriptor(this._engine.GetValue(this._engine.EvaluateExpression(property.Value)), new bool?(true), new bool?(true), new bool?(true));
            break;
          case PropertyKind.Get:
            if (!(property.Value is FunctionExpression functionExpression1))
              throw new JavaScriptException(this._engine.SyntaxError);
            ScriptFunctionInstance get;
            using (new StrictModeScope(functionExpression1.Strict))
              get = new ScriptFunctionInstance(this._engine, (IFunctionDeclaration) functionExpression1, this._engine.ExecutionContext.LexicalEnvironment, StrictModeScope.IsStrictModeCode);
            desc = new PropertyDescriptor((JsValue) (ObjectInstance) get, (JsValue) null, new bool?(true), new bool?(true));
            break;
          case PropertyKind.Set:
            if (!(property.Value is FunctionExpression functionExpression2))
              throw new JavaScriptException(this._engine.SyntaxError);
            ScriptFunctionInstance set;
            using (new StrictModeScope(functionExpression2.Strict))
              set = new ScriptFunctionInstance(this._engine, (IFunctionDeclaration) functionExpression2, this._engine.ExecutionContext.LexicalEnvironment, StrictModeScope.IsStrictModeCode);
            desc = new PropertyDescriptor((JsValue) null, (JsValue) (ObjectInstance) set, new bool?(true), new bool?(true));
            break;
          default:
            throw new ArgumentOutOfRangeException();
        }
        if (ownProperty != PropertyDescriptor.Undefined)
        {
          if (StrictModeScope.IsStrictModeCode && ownProperty.IsDataDescriptor() && desc.IsDataDescriptor())
            throw new JavaScriptException(this._engine.SyntaxError);
          if (ownProperty.IsDataDescriptor() && desc.IsAccessorDescriptor())
            throw new JavaScriptException(this._engine.SyntaxError);
          if (ownProperty.IsAccessorDescriptor() && desc.IsDataDescriptor())
            throw new JavaScriptException(this._engine.SyntaxError);
          if (ownProperty.IsAccessorDescriptor() && desc.IsAccessorDescriptor())
          {
            if (desc.Set != (JsValue) null && ownProperty.Set != (JsValue) null)
              throw new JavaScriptException(this._engine.SyntaxError);
            if (desc.Get != (JsValue) null && ownProperty.Get != (JsValue) null)
              throw new JavaScriptException(this._engine.SyntaxError);
          }
        }
        objectExpression1.DefineOwnProperty(key, desc, false);
      }
      return (JsValue) objectExpression1;
    }

    public Reference EvaluateMemberExpression(MemberExpression memberExpression)
    {
      object expression1 = this.EvaluateExpression(memberExpression.Object);
      JsValue jsValue = this._engine.GetValue(expression1);
      Expression expression2 = memberExpression.Property;
      if (!memberExpression.Computed)
      {
        Literal literal = new Literal();
        literal.Type = SyntaxNodes.Literal;
        literal.Value = (object) memberExpression.Property.As<Identifier>().Name;
        expression2 = (Expression) literal;
      }
      JsValue o = this._engine.GetValue(this.EvaluateExpression(expression2));
      TypeConverter.CheckObjectCoercible(this._engine, jsValue, memberExpression, expression1);
      string name = TypeConverter.ToString(o);
      return new Reference(jsValue, name, StrictModeScope.IsStrictModeCode);
    }

    public JsValue EvaluateFunctionExpression(FunctionExpression functionExpression)
    {
      LexicalEnvironment scope = LexicalEnvironment.NewDeclarativeEnvironment(this._engine, this._engine.ExecutionContext.LexicalEnvironment);
      DeclarativeEnvironmentRecord record = (DeclarativeEnvironmentRecord) scope.Record;
      if (functionExpression.Id != null && !string.IsNullOrEmpty(functionExpression.Id.Name))
        record.CreateMutableBinding(functionExpression.Id.Name, false);
      ScriptFunctionInstance functionExpression1 = new ScriptFunctionInstance(this._engine, (IFunctionDeclaration) functionExpression, scope, functionExpression.Strict);
      if (functionExpression.Id != null && !string.IsNullOrEmpty(functionExpression.Id.Name))
        record.InitializeImmutableBinding(functionExpression.Id.Name, (JsValue) (ObjectInstance) functionExpression1);
      return (JsValue) (ObjectInstance) functionExpression1;
    }

    public JsValue EvaluateCallExpression(CallExpression callExpression)
    {
      object expression = this.EvaluateExpression(callExpression.Callee);
      if (this._engine.Options._IsDebugMode)
        this._engine.DebugHandler.AddToDebugCallStack(callExpression);
      JsValue[] arguments;
      if (callExpression.Cached)
      {
        arguments = callExpression.CachedArguments;
      }
      else
      {
        arguments = callExpression.Arguments.Select<Expression, object>(new Func<Expression, object>(this.EvaluateExpression)).Select<object, JsValue>(new Func<object, JsValue>(this._engine.GetValue)).ToArray<JsValue>();
        if (callExpression.CanBeCached)
        {
          if (callExpression.Arguments.All<Expression>((Func<Expression, bool>) (x => x is Literal)))
          {
            callExpression.CachedArguments = arguments;
            callExpression.Cached = true;
          }
          else
            callExpression.CanBeCached = false;
        }
      }
      JsValue function = this._engine.GetValue(expression);
      Reference reference = expression as Reference;
      if (this._engine.Options._MaxRecursionDepth >= 0)
      {
        CallStackElement callStackElement = new CallStackElement(callExpression, function, reference != null ? reference.GetReferencedName() : "anonymous function");
        if (this._engine.CallStack.Push(callStackElement) > this._engine.Options._MaxRecursionDepth)
        {
          this._engine.CallStack.Pop();
          throw new RecursionDepthOverflowException(this._engine.CallStack, callStackElement.ToString());
        }
      }
      if (function == Undefined.Instance)
        throw new JavaScriptException(this._engine.TypeError, reference == null ? "" : string.Format("Object has no method '{0}'", (object) reference.GetReferencedName()));
      if (!function.IsObject() && (this._engine.Options._ReferenceResolver == null || !this._engine.Options._ReferenceResolver.TryGetCallable(this._engine, expression, out function)))
        throw new JavaScriptException(this._engine.TypeError, reference == null ? "" : string.Format("Property '{0}' of object is not a function", (object) reference.GetReferencedName()));
      ICallable callable = function.TryCast<ICallable>();
      if (callable == null)
        throw new JavaScriptException(this._engine.TypeError);
      JsValue thisObject = reference == null ? Undefined.Instance : (!reference.IsPropertyReference() ? reference.GetBase().TryCast<EnvironmentRecord>().ImplicitThisValue() : reference.GetBase());
      if (reference != null && reference.GetReferencedName() == "eval" && callable is EvalFunctionInstance)
        return ((EvalFunctionInstance) callable).Call(thisObject, arguments, true);
      JsValue callExpression1 = callable.Call(thisObject, arguments);
      if (this._engine.Options._IsDebugMode)
        this._engine.DebugHandler.PopDebugCallStack();
      if (this._engine.Options._MaxRecursionDepth < 0)
        return callExpression1;
      this._engine.CallStack.Pop();
      return callExpression1;
    }

    public JsValue EvaluateSequenceExpression(SequenceExpression sequenceExpression)
    {
      JsValue instance = Undefined.Instance;
      foreach (Expression expression in (IEnumerable<Expression>) sequenceExpression.Expressions)
        instance = this._engine.GetValue(this._engine.EvaluateExpression(expression));
      return instance;
    }

    public JsValue EvaluateUpdateExpression(UpdateExpression updateExpression)
    {
      object expression = this._engine.EvaluateExpression(updateExpression.Argument);
      switch (updateExpression.Operator)
      {
        case UnaryOperator.Increment:
          if (expression is Reference reference1 && reference1.IsStrict() && reference1.GetBase().TryCast<EnvironmentRecord>() != null)
          {
            if (Array.IndexOf<string>(new string[2]
            {
              "eval",
              "arguments"
            }, reference1.GetReferencedName()) != -1)
              throw new JavaScriptException(this._engine.SyntaxError);
          }
          double number1 = TypeConverter.ToNumber(this._engine.GetValue(expression));
          double num1 = number1 + 1.0;
          this._engine.PutValue(reference1, (JsValue) num1);
          return (JsValue) (updateExpression.Prefix ? num1 : number1);
        case UnaryOperator.Decrement:
          if (expression is Reference reference2 && reference2.IsStrict() && reference2.GetBase().TryCast<EnvironmentRecord>() != null)
          {
            if (Array.IndexOf<string>(new string[2]
            {
              "eval",
              "arguments"
            }, reference2.GetReferencedName()) != -1)
              throw new JavaScriptException(this._engine.SyntaxError);
          }
          double number2 = TypeConverter.ToNumber(this._engine.GetValue(expression));
          double num2 = number2 - 1.0;
          this._engine.PutValue(reference2, (JsValue) num2);
          return (JsValue) (updateExpression.Prefix ? num2 : number2);
        default:
          throw new ArgumentException();
      }
    }

    public JsValue EvaluateThisExpression(ThisExpression thisExpression)
    {
      return this._engine.ExecutionContext.ThisBinding;
    }

    public JsValue EvaluateNewExpression(NewExpression newExpression)
    {
      JsValue[] array = newExpression.Arguments.Select<Expression, object>(new Func<Expression, object>(this.EvaluateExpression)).Select<object, JsValue>(new Func<object, JsValue>(this._engine.GetValue)).ToArray<JsValue>();
      return (JsValue) (this._engine.GetValue(this.EvaluateExpression(newExpression.Callee)).TryCast<IConstructor>() ?? throw new JavaScriptException(this._engine.TypeError, "The object can't be used as constructor.")).Construct(array);
    }

    public JsValue EvaluateArrayExpression(ArrayExpression arrayExpression)
    {
      ObjectInstance arrayExpression1 = this._engine.Array.Construct(new JsValue[1]
      {
        (JsValue) (double) arrayExpression.Elements.Count<Expression>()
      });
      int num = 0;
      foreach (Expression element in arrayExpression.Elements)
      {
        if (element != null)
        {
          JsValue jsValue = this._engine.GetValue(this.EvaluateExpression(element));
          arrayExpression1.DefineOwnProperty(num.ToString(), new PropertyDescriptor(jsValue, new bool?(true), new bool?(true), new bool?(true)), false);
        }
        ++num;
      }
      return (JsValue) arrayExpression1;
    }

    public JsValue EvaluateUnaryExpression(UnaryExpression unaryExpression)
    {
      object expression = this._engine.EvaluateExpression(unaryExpression.Argument);
      switch (unaryExpression.Operator)
      {
        case UnaryOperator.Plus:
          return (JsValue) TypeConverter.ToNumber(this._engine.GetValue(expression));
        case UnaryOperator.Minus:
          double number = TypeConverter.ToNumber(this._engine.GetValue(expression));
          return (JsValue) (double.IsNaN(number) ? double.NaN : number * -1.0);
        case UnaryOperator.BitwiseNot:
          return (JsValue) (double) ~TypeConverter.ToInt32(this._engine.GetValue(expression));
        case UnaryOperator.LogicalNot:
          return (JsValue) !TypeConverter.ToBoolean(this._engine.GetValue(expression));
        case UnaryOperator.Delete:
          if (!(expression is Reference reference1))
            return (JsValue) true;
          if (reference1.IsUnresolvableReference())
          {
            if (reference1.IsStrict())
              throw new JavaScriptException(this._engine.SyntaxError);
            return (JsValue) true;
          }
          if (reference1.IsPropertyReference())
            return (JsValue) TypeConverter.ToObject(this._engine, reference1.GetBase()).Delete(reference1.GetReferencedName(), reference1.IsStrict());
          return !reference1.IsStrict() ? (JsValue) reference1.GetBase().TryCast<EnvironmentRecord>().DeleteBinding(reference1.GetReferencedName()) : throw new JavaScriptException(this._engine.SyntaxError);
        case UnaryOperator.Void:
          this._engine.GetValue(expression);
          return Undefined.Instance;
        case UnaryOperator.TypeOf:
          if (expression is Reference reference2 && reference2.IsUnresolvableReference())
            return (JsValue) "undefined";
          JsValue jsValue = this._engine.GetValue(expression);
          if (jsValue == Undefined.Instance)
            return (JsValue) "undefined";
          if (jsValue == Null.Instance)
            return (JsValue) "object";
          switch (jsValue.Type)
          {
            case Types.Boolean:
              return (JsValue) "boolean";
            case Types.String:
              return (JsValue) "string";
            case Types.Number:
              return (JsValue) "number";
            default:
              return jsValue.TryCast<ICallable>() != null ? (JsValue) "function" : (JsValue) "object";
          }
        default:
          throw new ArgumentException();
      }
    }
  }
}
