﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Completion
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Parser;

#nullable disable
namespace Jint.Runtime
{
  public class Completion
  {
    public static string Normal = "normal";
    public static string Break = "break";
    public static string Continue = "continue";
    public static string Return = "return";
    public static string Throw = "throw";

    public Completion(string type, JsValue value, string identifier)
    {
      this.Type = type;
      this.Value = value;
      this.Identifier = identifier;
    }

    public string Type { get; private set; }

    public JsValue Value { get; private set; }

    public string Identifier { get; private set; }

    public JsValue GetValueOrDefault()
    {
      return !(this.Value != (JsValue) null) ? Undefined.Instance : this.Value;
    }

    public Location Location { get; set; }
  }
}
