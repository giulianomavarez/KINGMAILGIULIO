﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.StatementInterpreter
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Native.Array;
using Jint.Native.Object;
using Jint.Parser.Ast;
using Jint.Runtime.Descriptors;
using Jint.Runtime.Environments;
using Jint.Runtime.References;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

#nullable disable
namespace Jint.Runtime
{
  public class StatementInterpreter
  {
    private readonly Engine _engine;

    public StatementInterpreter(Engine engine) => this._engine = engine;

    private Completion ExecuteStatement(Statement statement)
    {
      return this._engine.ExecuteStatement(statement);
    }

    public Completion ExecuteEmptyStatement(EmptyStatement emptyStatement)
    {
      return new Completion(Completion.Normal, (JsValue) null, (string) null);
    }

    public Completion ExecuteExpressionStatement(ExpressionStatement expressionStatement)
    {
      object expression = this._engine.EvaluateExpression(expressionStatement.Expression);
      return new Completion(Completion.Normal, this._engine.GetValue(expression), (string) null);
    }

    public Completion ExecuteIfStatement(IfStatement ifStatement)
    {
      if (TypeConverter.ToBoolean(this._engine.GetValue(this._engine.EvaluateExpression(ifStatement.Test))))
        return this.ExecuteStatement(ifStatement.Consequent);
      return ifStatement.Alternate != null ? this.ExecuteStatement(ifStatement.Alternate) : new Completion(Completion.Normal, (JsValue) null, (string) null);
    }

    public Completion ExecuteLabelledStatement(LabelledStatement labelledStatement)
    {
      labelledStatement.Body.LabelSet = labelledStatement.Label.Name;
      Completion completion = this.ExecuteStatement(labelledStatement.Body);
      return completion.Type == Completion.Break && completion.Identifier == labelledStatement.Label.Name ? new Completion(Completion.Normal, completion.Value, (string) null) : completion;
    }

    public Completion ExecuteDoWhileStatement(DoWhileStatement doWhileStatement)
    {
      JsValue instance = Undefined.Instance;
      do
      {
        Completion completion = this.ExecuteStatement(doWhileStatement.Body);
        if (completion.Value != (JsValue) null)
          instance = completion.Value;
        if (completion.Type != Completion.Continue || completion.Identifier != doWhileStatement.LabelSet)
        {
          if (completion.Type == Completion.Break && (completion.Identifier == null || completion.Identifier == doWhileStatement.LabelSet))
            return new Completion(Completion.Normal, instance, (string) null);
          if (completion.Type != Completion.Normal)
            return completion;
        }
      }
      while (TypeConverter.ToBoolean(this._engine.GetValue(this._engine.EvaluateExpression(doWhileStatement.Test))));
      return new Completion(Completion.Normal, instance, (string) null);
    }

    public Completion ExecuteWhileStatement(WhileStatement whileStatement)
    {
      JsValue instance = Undefined.Instance;
      while (TypeConverter.ToBoolean(this._engine.GetValue(this._engine.EvaluateExpression(whileStatement.Test))))
      {
        Completion completion = this.ExecuteStatement(whileStatement.Body);
        if (completion.Value != (JsValue) null)
          instance = completion.Value;
        if (completion.Type != Completion.Continue || completion.Identifier != whileStatement.LabelSet)
        {
          if (completion.Type == Completion.Break && (completion.Identifier == null || completion.Identifier == whileStatement.LabelSet))
            return new Completion(Completion.Normal, instance, (string) null);
          if (completion.Type != Completion.Normal)
            return completion;
        }
      }
      return new Completion(Completion.Normal, instance, (string) null);
    }

    public Completion ExecuteForStatement(ForStatement forStatement)
    {
      if (forStatement.Init != null)
      {
        if (forStatement.Init.Type == SyntaxNodes.VariableDeclaration)
          this.ExecuteStatement(forStatement.Init.As<Statement>());
        else
          this._engine.GetValue(this._engine.EvaluateExpression(forStatement.Init.As<Expression>()));
      }
      JsValue instance = Undefined.Instance;
      while (forStatement.Test == null || TypeConverter.ToBoolean(this._engine.GetValue(this._engine.EvaluateExpression(forStatement.Test))))
      {
        Completion completion = this.ExecuteStatement(forStatement.Body);
        if (completion.Value != (JsValue) null)
          instance = completion.Value;
        if (completion.Type == Completion.Break && (completion.Identifier == null || completion.Identifier == forStatement.LabelSet))
          return new Completion(Completion.Normal, instance, (string) null);
        if ((completion.Type != Completion.Continue || completion.Identifier != null && completion.Identifier != forStatement.LabelSet) && completion.Type != Completion.Normal)
          return completion;
        if (forStatement.Update != null)
          this._engine.GetValue(this._engine.EvaluateExpression(forStatement.Update));
      }
      return new Completion(Completion.Normal, instance, (string) null);
    }

    public Completion ExecuteForInStatement(ForInStatement forInStatement)
    {
      Reference expression = this._engine.EvaluateExpression(forInStatement.Left.Type == SyntaxNodes.VariableDeclaration ? (Expression) forInStatement.Left.As<VariableDeclaration>().Declarations.First<VariableDeclarator>().Id : (Expression) forInStatement.Left.As<Identifier>()) as Reference;
      JsValue jsValue = this._engine.GetValue(this._engine.EvaluateExpression(forInStatement.Right));
      if (jsValue == Undefined.Instance || jsValue == Null.Instance)
        return new Completion(Completion.Normal, (JsValue) null, (string) null);
      ObjectInstance objectInstance1 = TypeConverter.ToObject(this._engine, jsValue);
      JsValue instance = Null.Instance;
      ObjectInstance objectInstance2 = objectInstance1;
      HashSet<string> stringSet = new HashSet<string>();
      for (; objectInstance2 != null; objectInstance2 = objectInstance2.Prototype)
      {
        ArrayInstance arrayInstance = this._engine.Object.GetOwnPropertyNames(Undefined.Instance, Arguments.From((JsValue) objectInstance2)).AsArray();
        for (int index = 0; (long) index < (long) arrayInstance.GetLength(); ++index)
        {
          string propertyName = arrayInstance.GetOwnProperty(index.ToString()).Value.AsString();
          if (!stringSet.Contains(propertyName))
          {
            stringSet.Add(propertyName);
            if (objectInstance2.GetOwnProperty(propertyName) != PropertyDescriptor.Undefined)
            {
              PropertyDescriptor ownProperty = objectInstance2.GetOwnProperty(propertyName);
              bool? enumerable = ownProperty.Enumerable;
              if (enumerable.HasValue)
              {
                enumerable = ownProperty.Enumerable;
                if (enumerable.Value)
                {
                  this._engine.PutValue(expression, (JsValue) propertyName);
                  Completion completion = this.ExecuteStatement(forInStatement.Body);
                  if (completion.Value != (JsValue) null)
                    instance = completion.Value;
                  if (completion.Type == Completion.Break)
                    return new Completion(Completion.Normal, instance, (string) null);
                  if (completion.Type != Completion.Continue && completion.Type != Completion.Normal)
                    return completion;
                }
              }
            }
          }
        }
      }
      return new Completion(Completion.Normal, instance, (string) null);
    }

    public Completion ExecuteContinueStatement(ContinueStatement continueStatement)
    {
      return new Completion(Completion.Continue, (JsValue) null, continueStatement.Label != null ? continueStatement.Label.Name : (string) null);
    }

    public Completion ExecuteBreakStatement(BreakStatement breakStatement)
    {
      return new Completion(Completion.Break, (JsValue) null, breakStatement.Label != null ? breakStatement.Label.Name : (string) null);
    }

    public Completion ExecuteReturnStatement(ReturnStatement statement)
    {
      if (statement.Argument == null)
        return new Completion(Completion.Return, Undefined.Instance, (string) null);
      object expression = this._engine.EvaluateExpression(statement.Argument);
      return new Completion(Completion.Return, this._engine.GetValue(expression), (string) null);
    }

    public Completion ExecuteWithStatement(WithStatement withStatement)
    {
      ObjectInstance objectInstance = TypeConverter.ToObject(this._engine, this._engine.GetValue(this._engine.EvaluateExpression(withStatement.Object)));
      LexicalEnvironment lexicalEnvironment = this._engine.ExecutionContext.LexicalEnvironment;
      this._engine.ExecutionContext.LexicalEnvironment = LexicalEnvironment.NewObjectEnvironment(this._engine, objectInstance, lexicalEnvironment, true);
      Completion completion;
      try
      {
        completion = this.ExecuteStatement(withStatement.Body);
      }
      catch (JavaScriptException ex)
      {
        completion = new Completion(Completion.Throw, ex.Error, (string) null);
        completion.Location = withStatement.Location;
      }
      finally
      {
        this._engine.ExecutionContext.LexicalEnvironment = lexicalEnvironment;
      }
      return completion;
    }

    public Completion ExecuteSwitchStatement(SwitchStatement switchStatement)
    {
      object expression = this._engine.EvaluateExpression(switchStatement.Discriminant);
      Completion completion = this.ExecuteSwitchBlock(switchStatement.Cases, this._engine.GetValue(expression));
      return completion.Type == Completion.Break && completion.Identifier == switchStatement.LabelSet ? new Completion(Completion.Normal, completion.Value, (string) null) : completion;
    }

    public Completion ExecuteSwitchBlock(IEnumerable<SwitchCase> switchBlock, JsValue input)
    {
      JsValue jsValue = Undefined.Instance;
      SwitchCase switchCase1 = (SwitchCase) null;
      bool flag = false;
      foreach (SwitchCase switchCase2 in switchBlock)
      {
        if (switchCase2.Test == null)
          switchCase1 = switchCase2;
        else if (ExpressionInterpreter.StrictlyEqual(this._engine.GetValue(this._engine.EvaluateExpression(switchCase2.Test)), input))
          flag = true;
        if (flag && switchCase2.Consequent != null)
        {
          Completion completion = this.ExecuteStatementList(switchCase2.Consequent);
          if (completion.Type != Completion.Normal)
            return completion;
          jsValue = completion.Value != (JsValue) null ? completion.Value : Undefined.Instance;
        }
      }
      if (!flag && switchCase1 != null)
      {
        Completion completion = this.ExecuteStatementList(switchCase1.Consequent);
        if (completion.Type != Completion.Normal)
          return completion;
        jsValue = completion.Value != (JsValue) null ? completion.Value : Undefined.Instance;
      }
      return new Completion(Completion.Normal, jsValue, (string) null);
    }

    public Completion ExecuteStatementList(IEnumerable<Statement> statementList)
    {
      Completion completion1 = new Completion(Completion.Normal, (JsValue) null, (string) null);
      Completion completion2 = completion1;
      Statement statement1 = (Statement) null;
      try
      {
        foreach (Statement statement2 in statementList)
        {
          statement1 = statement2;
          completion1 = this.ExecuteStatement(statement2);
          if (completion1.Type != Completion.Normal)
            return new Completion(completion1.Type, completion1.Value != (JsValue) null ? completion1.Value : completion2.Value, completion1.Identifier)
            {
              Location = completion1.Location
            };
          completion2 = completion1;
        }
      }
      catch (JavaScriptException ex)
      {
        return new Completion(Completion.Throw, ex.Error, (string) null)
        {
          Location = ex.Location ?? statement1.Location
        };
      }
      return new Completion(completion1.Type, completion1.GetValueOrDefault(), completion1.Identifier);
    }

    public Completion ExecuteThrowStatement(ThrowStatement throwStatement)
    {
      object expression = this._engine.EvaluateExpression(throwStatement.Argument);
      return new Completion(Completion.Throw, this._engine.GetValue(expression), (string) null)
      {
        Location = throwStatement.Location
      };
    }

    public Completion ExecuteTryStatement(TryStatement tryStatement)
    {
      Completion completion1 = this.ExecuteStatement(tryStatement.Block);
      if (completion1.Type == Completion.Throw && tryStatement.Handlers.Any<CatchClause>())
      {
        foreach (CatchClause handler in tryStatement.Handlers)
        {
          JsValue jsValue = this._engine.GetValue((object) completion1);
          LexicalEnvironment lexicalEnvironment1 = this._engine.ExecutionContext.LexicalEnvironment;
          LexicalEnvironment lexicalEnvironment2 = LexicalEnvironment.NewDeclarativeEnvironment(this._engine, lexicalEnvironment1);
          lexicalEnvironment2.Record.CreateMutableBinding(handler.Param.Name);
          lexicalEnvironment2.Record.SetMutableBinding(handler.Param.Name, jsValue, false);
          this._engine.ExecutionContext.LexicalEnvironment = lexicalEnvironment2;
          completion1 = this.ExecuteStatement((Statement) handler.Body);
          this._engine.ExecutionContext.LexicalEnvironment = lexicalEnvironment1;
        }
      }
      if (tryStatement.Finalizer == null)
        return completion1;
      Completion completion2 = this.ExecuteStatement(tryStatement.Finalizer);
      return completion2.Type == Completion.Normal ? completion1 : completion2;
    }

    public Completion ExecuteProgram(Program program)
    {
      return this.ExecuteStatementList((IEnumerable<Statement>) program.Body);
    }

    public Completion ExecuteVariableDeclaration(VariableDeclaration statement)
    {
      foreach (VariableDeclarator declaration in statement.Declarations)
      {
        if (declaration.Init != null)
        {
          if (!(this._engine.EvaluateExpression((Expression) declaration.Id) is Reference expression))
            throw new ArgumentException();
          if (expression.IsStrict() && expression.GetBase().TryCast<EnvironmentRecord>() != null && (expression.GetReferencedName() == "eval" || expression.GetReferencedName() == "arguments"))
            throw new JavaScriptException(this._engine.SyntaxError);
          expression.GetReferencedName();
          JsValue jsValue = this._engine.GetValue(this._engine.EvaluateExpression(declaration.Init));
          this._engine.PutValue(expression, jsValue);
        }
      }
      return new Completion(Completion.Normal, Undefined.Instance, (string) null);
    }

    public Completion ExecuteBlockStatement(BlockStatement blockStatement)
    {
      return this.ExecuteStatementList(blockStatement.Body);
    }

    public Completion ExecuteDebuggerStatement(DebuggerStatement debuggerStatement)
    {
      if (this._engine.Options._IsDebuggerStatementAllowed)
      {
        if (!Debugger.IsAttached)
          Debugger.Launch();
        Debugger.Break();
      }
      return new Completion(Completion.Normal, (JsValue) null, (string) null);
    }
  }
}
