﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.JavaScriptException
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Native.Error;
using Jint.Parser;
using Jint.Parser.Ast;
using System;
using System.Text;

#nullable disable
namespace Jint.Runtime
{
  public class JavaScriptException : Exception
  {
    private readonly JsValue _errorObject;
    private string _callStack;

    public JavaScriptException(ErrorConstructor errorConstructor)
      : base("")
    {
      this._errorObject = (JsValue) errorConstructor.Construct(Arguments.Empty);
    }

    public JavaScriptException(ErrorConstructor errorConstructor, string message)
      : base(message)
    {
      this._errorObject = (JsValue) errorConstructor.Construct(new JsValue[1]
      {
        (JsValue) message
      });
    }

    public JavaScriptException(JsValue error)
      : base(JavaScriptException.GetErrorMessage(error))
    {
      this._errorObject = error;
    }

    public JavaScriptException SetCallstack(Engine engine, Location location = null)
    {
      this.Location = location;
      StringBuilder stringBuilder = new StringBuilder();
      foreach (CallStackElement call in engine.CallStack)
      {
        stringBuilder.Append(" at ").Append((object) call).Append("(");
        for (int index = 0; index < call.CallExpression.Arguments.Count; ++index)
        {
          if (index != 0)
            stringBuilder.Append(", ");
          Expression expression = call.CallExpression.Arguments[index];
          if (expression is IPropertyKeyExpression propertyKeyExpression)
            stringBuilder.Append(propertyKeyExpression.GetKey());
          else
            stringBuilder.Append((object) expression);
        }
        stringBuilder.Append(") @ ").Append(call.CallExpression.Location.Source).Append(" ").Append(call.CallExpression.Location.Start.Column).Append(":").Append(call.CallExpression.Location.Start.Line).AppendLine();
      }
      this.CallStack = stringBuilder.ToString();
      return this;
    }

    private static string GetErrorMessage(JsValue error)
    {
      if (error.IsObject())
        return error.AsObject().Get("message").AsString();
      return error.IsString() ? error.AsString() : error.ToString();
    }

    public JsValue Error => this._errorObject;

    public override string ToString() => this._errorObject.ToString();

    public string CallStack
    {
      get
      {
        if (this._callStack != null)
          return this._callStack;
        if (this._errorObject == (JsValue) null)
          return (string) null;
        if (!this._errorObject.IsObject())
          return (string) null;
        JsValue jsValue = this._errorObject.AsObject().Get("callstack");
        return jsValue == JsValue.Undefined ? (string) null : jsValue.AsString();
      }
      set
      {
        this._callStack = value;
        if (value == null || !this._errorObject.IsObject())
          return;
        this._errorObject.AsObject().FastAddProperty("callstack", new JsValue(value), false, false, false);
      }
    }

    public Location Location { get; set; }

    public int LineNumber => this.Location != null ? this.Location.Start.Line : 0;

    public int Column => this.Location != null ? this.Location.Start.Column : 0;
  }
}
