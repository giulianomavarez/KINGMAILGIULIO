﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Interop.DelegateWrapper
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Native.Function;
using Jint.Native.Object;
using Jint.Runtime.Environments;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;

#nullable disable
namespace Jint.Runtime.Interop
{
  public sealed class DelegateWrapper : FunctionInstance
  {
    private readonly Delegate _d;

    public DelegateWrapper(Engine engine, Delegate d)
      : base(engine, (string[]) null, (LexicalEnvironment) null, false)
    {
      this._d = d;
      this.Prototype = (ObjectInstance) engine.Function.PrototypeObject;
    }

    public override JsValue Call(JsValue thisObject, JsValue[] jsArguments)
    {
      ParameterInfo[] parameters = this._d.GetMethodInfo().GetParameters();
      bool flag = ((IEnumerable<ParameterInfo>) parameters).Any<ParameterInfo>((Func<ParameterInfo, bool>) (p => p.HasAttribute<ParamArrayAttribute>()));
      int length1 = parameters.Length;
      int val2 = flag ? length1 - 1 : length1;
      int length2 = jsArguments.Length;
      int num = Math.Min(length2, val2);
      object[] objArray1 = new object[length1];
      for (int index = 0; index < num; ++index)
      {
        Type parameterType = parameters[index].ParameterType;
        objArray1[index] = !(parameterType == typeof (JsValue)) ? this.Engine.ClrTypeConverter.Convert(jsArguments[index].ToObject(), parameterType, (IFormatProvider) CultureInfo.InvariantCulture) : (object) jsArguments[index];
      }
      for (int index = num; index < val2; ++index)
        objArray1[index] = !parameters[index].ParameterType.IsValueType() ? (object) null : Activator.CreateInstance(parameters[index].ParameterType);
      if (flag)
      {
        int index1 = length1 - 1;
        object[] objArray2 = new object[Math.Max(0, length2 - val2)];
        Type elementType = parameters[index1].ParameterType.GetElementType();
        for (int index2 = index1; index2 < length2; ++index2)
        {
          int index3 = index2 - index1;
          objArray2[index3] = !(elementType == typeof (JsValue)) ? this.Engine.ClrTypeConverter.Convert(jsArguments[index2].ToObject(), elementType, (IFormatProvider) CultureInfo.InvariantCulture) : (object) jsArguments[index2];
        }
        objArray1[index1] = (object) objArray2;
      }
      try
      {
        return JsValue.FromObject(this.Engine, this._d.DynamicInvoke(objArray1));
      }
      catch (TargetInvocationException ex)
      {
        Exception exception = ex.InnerException ?? (Exception) ex;
        Predicate<Exception> exceptionsHandler = this.Engine.Options._ClrExceptionsHandler;
        if (exceptionsHandler != null && exceptionsHandler(exception))
          throw new JavaScriptException(this.Engine.Error, exception.Message);
        throw exception;
      }
    }
  }
}
