﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Interop.NamespaceReference
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Native.Object;
using Jint.Runtime.Descriptors;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;

#nullable disable
namespace Jint.Runtime.Interop
{
  public class NamespaceReference : ObjectInstance, ICallable
  {
    private readonly string _path;

    public NamespaceReference(Engine engine, string path)
      : base(engine)
    {
      this._path = path;
    }

    public override bool DefineOwnProperty(
      string propertyName,
      PropertyDescriptor desc,
      bool throwOnError)
    {
      if (throwOnError)
        throw new JavaScriptException(this.Engine.TypeError, "Can't define a property of a NamespaceReference");
      return false;
    }

    public override bool Delete(string propertyName, bool throwOnError)
    {
      if (throwOnError)
        throw new JavaScriptException(this.Engine.TypeError, "Can't delete a property of a NamespaceReference");
      return false;
    }

    public JsValue Call(JsValue thisObject, JsValue[] arguments)
    {
      Type[] typeArray = new Type[arguments.Length];
      for (int index = 0; index < arguments.Length; ++index)
      {
        JsValue jsValue = arguments.At(index);
        if (jsValue == Undefined.Instance || !jsValue.IsObject() || jsValue.AsObject().Class != "TypeReference")
          throw new JavaScriptException(this.Engine.TypeError, "Invalid generic type parameter");
        typeArray[index] = arguments.At(index).As<TypeReference>().Type;
      }
      TypeReference typeReference = this.GetPath(this._path + "`" + arguments.Length.ToString((IFormatProvider) CultureInfo.InvariantCulture)).As<TypeReference>();
      return typeReference == null ? Undefined.Instance : (JsValue) (ObjectInstance) TypeReference.CreateTypeReference(this.Engine, typeReference.Type.MakeGenericType(typeArray));
    }

    public override JsValue Get(string propertyName)
    {
      return this.GetPath(this._path + "." + propertyName);
    }

    public JsValue GetPath(string path)
    {
      Type type1;
      if (this.Engine.TypeCache.TryGetValue(path, out type1))
        return type1 == (Type) null ? (JsValue) (ObjectInstance) new NamespaceReference(this.Engine, path) : (JsValue) (ObjectInstance) TypeReference.CreateTypeReference(this.Engine, type1);
      Type type2 = Type.GetType(path);
      if (type2 != (Type) null)
      {
        this.Engine.TypeCache.Add(path, type2);
        return (JsValue) (ObjectInstance) TypeReference.CreateTypeReference(this.Engine, type2);
      }
      Assembly[] assemblyArray = new Assembly[2]
      {
        Assembly.GetCallingAssembly(),
        Assembly.GetExecutingAssembly()
      };
      foreach (Assembly assembly in assemblyArray)
      {
        Type type3 = assembly.GetType(path);
        if (type3 != (Type) null)
        {
          this.Engine.TypeCache.Add(path, type3);
          return (JsValue) (ObjectInstance) TypeReference.CreateTypeReference(this.Engine, type3);
        }
      }
      foreach (Assembly lookupAssembly in (IEnumerable<Assembly>) this.Engine.Options._LookupAssemblies)
      {
        Type type4 = lookupAssembly.GetType(path);
        if (type4 != (Type) null)
        {
          this.Engine.TypeCache.Add(path, type4);
          return (JsValue) (ObjectInstance) TypeReference.CreateTypeReference(this.Engine, type4);
        }
        int length = path.LastIndexOf(".", StringComparison.Ordinal);
        string typeName = path.Substring(0, length);
        Type type5 = NamespaceReference.GetType(lookupAssembly, typeName);
        if (type5 != (Type) null)
        {
          foreach (Type allNestedType in NamespaceReference.GetAllNestedTypes(type5))
          {
            if (allNestedType.FullName.Replace("+", ".").Equals(path.Replace("+", ".")))
            {
              this.Engine.TypeCache.Add(path.Replace("+", "."), allNestedType);
              return (JsValue) (ObjectInstance) TypeReference.CreateTypeReference(this.Engine, allNestedType);
            }
          }
        }
      }
      this.Engine.TypeCache.Add(path, (Type) null);
      return (JsValue) (ObjectInstance) new NamespaceReference(this.Engine, path);
    }

    private static Type GetType(Assembly assembly, string typeName)
    {
      foreach (Type type in assembly.GetTypes())
      {
        if (type.FullName.Replace("+", ".") == typeName.Replace("+", "."))
          return type;
      }
      return (Type) null;
    }

    private static IEnumerable<Type> GetAllNestedTypes(Type type)
    {
      List<Type> types = new List<Type>();
      NamespaceReference.AddNestedTypesRecursively(types, type);
      return (IEnumerable<Type>) types.ToArray();
    }

    private static void AddNestedTypesRecursively(List<Type> types, Type type)
    {
      foreach (Type nestedType in type.GetNestedTypes(BindingFlags.Public))
      {
        types.Add(nestedType);
        NamespaceReference.AddNestedTypesRecursively(types, nestedType);
      }
    }

    public override PropertyDescriptor GetOwnProperty(string propertyName)
    {
      return PropertyDescriptor.Undefined;
    }

    public override string ToString() => "[Namespace: " + this._path + "]";
  }
}
