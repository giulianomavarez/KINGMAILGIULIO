﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Interop.ObjectWrapper
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Native.Object;
using Jint.Runtime.Descriptors;
using Jint.Runtime.Descriptors.Specialized;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

#nullable disable
namespace Jint.Runtime.Interop
{
  public sealed class ObjectWrapper : ObjectInstance, IObjectWrapper
  {
    public object Target { get; set; }

    public ObjectWrapper(Engine engine, object obj)
      : base(engine)
    {
      this.Target = obj;
    }

    public override void Put(string propertyName, JsValue value, bool throwOnError)
    {
      if (!this.CanPut(propertyName))
      {
        if (throwOnError)
          throw new JavaScriptException(this.Engine.TypeError);
      }
      else
      {
        PropertyDescriptor ownProperty = this.GetOwnProperty(propertyName);
        if (ownProperty == null)
        {
          if (throwOnError)
            throw new JavaScriptException(this.Engine.TypeError, "Unknown member: " + propertyName);
        }
        else
          ownProperty.Value = value;
      }
    }

    public override PropertyDescriptor GetOwnProperty(string propertyName)
    {
      PropertyDescriptor ownProperty1;
      if (this.Properties.TryGetValue(propertyName, out ownProperty1))
        return ownProperty1;
      Type type = this.Target.GetType();
      PropertyInfo propertyInfo = ((IEnumerable<PropertyInfo>) type.GetProperties(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public)).Where<PropertyInfo>((Func<PropertyInfo, bool>) (p => this.EqualsIgnoreCasing(p.Name, propertyName))).FirstOrDefault<PropertyInfo>();
      if (propertyInfo != (PropertyInfo) null)
      {
        PropertyInfoDescriptor ownProperty2 = new PropertyInfoDescriptor(this.Engine, propertyInfo, this.Target);
        this.Properties.Add(propertyName, (PropertyDescriptor) ownProperty2);
        return (PropertyDescriptor) ownProperty2;
      }
      FieldInfo fieldInfo = ((IEnumerable<FieldInfo>) type.GetFields(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public)).Where<FieldInfo>((Func<FieldInfo, bool>) (f => this.EqualsIgnoreCasing(f.Name, propertyName))).FirstOrDefault<FieldInfo>();
      if (fieldInfo != (FieldInfo) null)
      {
        FieldInfoDescriptor ownProperty3 = new FieldInfoDescriptor(this.Engine, fieldInfo, this.Target);
        this.Properties.Add(propertyName, (PropertyDescriptor) ownProperty3);
        return (PropertyDescriptor) ownProperty3;
      }
      MethodInfo[] array1 = ((IEnumerable<MethodInfo>) type.GetMethods(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public)).Where<MethodInfo>((Func<MethodInfo, bool>) (m => this.EqualsIgnoreCasing(m.Name, propertyName))).ToArray<MethodInfo>();
      if (((IEnumerable<MethodInfo>) array1).Any<MethodInfo>())
      {
        PropertyDescriptor ownProperty4 = new PropertyDescriptor((JsValue) (ObjectInstance) new MethodInfoFunctionInstance(this.Engine, array1), new bool?(false), new bool?(true), new bool?(false));
        this.Properties.Add(propertyName, ownProperty4);
        return ownProperty4;
      }
      if (((IEnumerable<PropertyInfo>) type.GetProperties()).Where<PropertyInfo>((Func<PropertyInfo, bool>) (p => p.GetIndexParameters().Length != 0)).FirstOrDefault<PropertyInfo>() != (PropertyInfo) null)
        return (PropertyDescriptor) new IndexDescriptor(this.Engine, propertyName, this.Target);
      Type[] interfaces = type.GetInterfaces();
      PropertyInfo[] array2 = ((IEnumerable<Type>) interfaces).SelectMany((Func<Type, IEnumerable<PropertyInfo>>) (iface => (IEnumerable<PropertyInfo>) iface.GetProperties()), (iface, iprop) => new
      {
        iface = iface,
        iprop = iprop
      }).Where(_param1 => this.EqualsIgnoreCasing(_param1.iprop.Name, propertyName)).Select(_param1 => _param1.iprop).ToArray<PropertyInfo>();
      if (array2.Length == 1)
      {
        PropertyInfoDescriptor ownProperty5 = new PropertyInfoDescriptor(this.Engine, array2[0], this.Target);
        this.Properties.Add(propertyName, (PropertyDescriptor) ownProperty5);
        return (PropertyDescriptor) ownProperty5;
      }
      MethodInfo[] array3 = ((IEnumerable<Type>) interfaces).SelectMany((Func<Type, IEnumerable<MethodInfo>>) (iface => (IEnumerable<MethodInfo>) iface.GetMethods()), (iface, imethod) => new
      {
        iface = iface,
        imethod = imethod
      }).Where(_param1 => this.EqualsIgnoreCasing(_param1.imethod.Name, propertyName)).Select(_param1 => _param1.imethod).ToArray<MethodInfo>();
      if (array3.Length != 0)
      {
        PropertyDescriptor ownProperty6 = new PropertyDescriptor((JsValue) (ObjectInstance) new MethodInfoFunctionInstance(this.Engine, array3), new bool?(false), new bool?(true), new bool?(false));
        this.Properties.Add(propertyName, ownProperty6);
        return ownProperty6;
      }
      PropertyInfo[] array4 = ((IEnumerable<Type>) interfaces).SelectMany((Func<Type, IEnumerable<PropertyInfo>>) (iface => (IEnumerable<PropertyInfo>) iface.GetProperties()), (iface, iprop) => new
      {
        iface = iface,
        iprop = iprop
      }).Where(_param1 => _param1.iprop.GetIndexParameters().Length != 0).Select(_param1 => _param1.iprop).ToArray<PropertyInfo>();
      return array4.Length == 1 ? (PropertyDescriptor) new IndexDescriptor(this.Engine, array4[0].DeclaringType, propertyName, this.Target) : PropertyDescriptor.Undefined;
    }

    private bool EqualsIgnoreCasing(string s1, string s2)
    {
      bool flag = false;
      if (s1.Length == s2.Length)
      {
        if (s1.Length > 0 && s2.Length > 0)
          flag = (int) s1.ToLower()[0] == (int) s2.ToLower()[0];
        if (s1.Length > 1 && s2.Length > 1)
          flag = flag && s1.Substring(1) == s2.Substring(1);
      }
      return flag;
    }
  }
}
