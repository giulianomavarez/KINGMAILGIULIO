﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Interop.TypeReference
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Native.Function;
using Jint.Native.Object;
using Jint.Runtime.Descriptors;
using Jint.Runtime.Descriptors.Specialized;
using Jint.Runtime.Environments;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;

#nullable disable
namespace Jint.Runtime.Interop
{
  public class TypeReference : FunctionInstance, IConstructor, IObjectWrapper
  {
    private TypeReference(Engine engine)
      : base(engine, (string[]) null, (LexicalEnvironment) null, false)
    {
    }

    public Type Type { get; set; }

    public static TypeReference CreateTypeReference(Engine engine, Type type)
    {
      TypeReference typeReference = new TypeReference(engine);
      typeReference.Extensible = false;
      typeReference.Type = type;
      typeReference.Prototype = (ObjectInstance) engine.Function.PrototypeObject;
      typeReference.FastAddProperty("length", (JsValue) 0.0, false, false, false);
      typeReference.FastAddProperty("prototype", (JsValue) (ObjectInstance) engine.Object.PrototypeObject, false, false, false);
      return typeReference;
    }

    public override JsValue Call(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) this.Construct(arguments);
    }

    public ObjectInstance Construct(JsValue[] arguments)
    {
      if (arguments.Length == 0 && this.Type.IsValueType())
        return TypeConverter.ToObject(this.Engine, JsValue.FromObject(this.Engine, Activator.CreateInstance(this.Type)));
      foreach (MethodBase methodBase in TypeConverter.FindBestMatch(this.Engine, (MethodBase[]) this.Type.GetConstructors(BindingFlags.Instance | BindingFlags.Public), arguments).ToList<MethodBase>())
      {
        object[] source = new object[arguments.Length];
        try
        {
          for (int index = 0; index < arguments.Length; ++index)
          {
            Type parameterType = methodBase.GetParameters()[index].ParameterType;
            source[index] = !(parameterType == typeof (JsValue)) ? this.Engine.ClrTypeConverter.Convert(arguments[index].ToObject(), parameterType, (IFormatProvider) CultureInfo.InvariantCulture) : (object) arguments[index];
          }
          return TypeConverter.ToObject(this.Engine, JsValue.FromObject(this.Engine, ((ConstructorInfo) methodBase).Invoke(((IEnumerable<object>) source).ToArray<object>())));
        }
        catch
        {
        }
      }
      throw new JavaScriptException(this.Engine.TypeError, "No public methods with the specified arguments were found.");
    }

    public override bool HasInstance(JsValue v)
    {
      ObjectWrapper objectWrapper = v.As<ObjectWrapper>();
      return objectWrapper == null ? base.HasInstance(v) : objectWrapper.Target.GetType() == this.Type;
    }

    public override bool DefineOwnProperty(
      string propertyName,
      PropertyDescriptor desc,
      bool throwOnError)
    {
      if (throwOnError)
        throw new JavaScriptException(this.Engine.TypeError, "Can't define a property of a TypeReference");
      return false;
    }

    public override bool Delete(string propertyName, bool throwOnError)
    {
      if (throwOnError)
        throw new JavaScriptException(this.Engine.TypeError, "Can't delete a property of a TypeReference");
      return false;
    }

    public override void Put(string propertyName, JsValue value, bool throwOnError)
    {
      if (!this.CanPut(propertyName))
      {
        if (throwOnError)
          throw new JavaScriptException(this.Engine.TypeError);
      }
      else
      {
        PropertyDescriptor ownProperty = this.GetOwnProperty(propertyName);
        if (ownProperty == null)
        {
          if (throwOnError)
            throw new JavaScriptException(this.Engine.TypeError, "Unknown member: " + propertyName);
        }
        else
          ownProperty.Value = value;
      }
    }

    public override PropertyDescriptor GetOwnProperty(string propertyName)
    {
      if (this.Type.IsEnum())
      {
        Array values = Enum.GetValues(this.Type);
        Array names = (Array) Enum.GetNames(this.Type);
        for (int index = 0; index < values.Length; ++index)
        {
          if (names.GetValue(index) as string == propertyName)
            return new PropertyDescriptor((JsValue) (double) (int) values.GetValue(index), new bool?(false), new bool?(false), new bool?(false));
        }
        return PropertyDescriptor.Undefined;
      }
      PropertyInfo property = this.Type.GetProperty(propertyName, BindingFlags.Static | BindingFlags.Public);
      if (property != (PropertyInfo) null)
        return (PropertyDescriptor) new PropertyInfoDescriptor(this.Engine, property, (object) this.Type);
      FieldInfo field = this.Type.GetField(propertyName, BindingFlags.Static | BindingFlags.Public);
      if (field != (FieldInfo) null)
        return (PropertyDescriptor) new FieldInfoDescriptor(this.Engine, field, (object) this.Type);
      MethodInfo[] array = ((IEnumerable<MethodInfo>) this.Type.GetMethods(BindingFlags.Static | BindingFlags.Public)).Where<MethodInfo>((Func<MethodInfo, bool>) (mi => mi.Name == propertyName)).ToArray<MethodInfo>();
      return array.Length == 0 ? PropertyDescriptor.Undefined : new PropertyDescriptor((JsValue) (ObjectInstance) new MethodInfoFunctionInstance(this.Engine, array), new bool?(false), new bool?(false), new bool?(false));
    }

    public object Target => (object) this.Type;

    public override string Class => nameof (TypeReference);
  }
}
