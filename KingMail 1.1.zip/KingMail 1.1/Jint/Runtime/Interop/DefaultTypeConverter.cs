﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Interop.DefaultTypeConverter
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

#nullable disable
namespace Jint.Runtime.Interop
{
  public class DefaultTypeConverter : ITypeConverter
  {
    private readonly Engine _engine;
    private static readonly Dictionary<string, bool> _knownConversions = new Dictionary<string, bool>();
    private static readonly object _lockObject = new object();
    private static MethodInfo convertChangeType = typeof (System.Convert).GetMethod("ChangeType", new Type[3]
    {
      typeof (object),
      typeof (Type),
      typeof (IFormatProvider)
    });
    private static MethodInfo jsValueFromObject = typeof (JsValue).GetMethod("FromObject");
    private static MethodInfo jsValueToObject = typeof (JsValue).GetMethod("ToObject");

    public DefaultTypeConverter(Engine engine) => this._engine = engine;

    public virtual object Convert(object value, Type type, IFormatProvider formatProvider)
    {
      if (value == null)
      {
        if (TypeConverter.TypeIsNullable(type))
          return (object) null;
        throw new NotSupportedException(string.Format("Unable to convert null to '{0}'", (object) type.FullName));
      }
      if (type.IsInstanceOfType(value))
        return value;
      if (type.IsEnum())
        return Enum.ToObject(type, System.Convert.ChangeType(value, typeof (int), formatProvider) ?? throw new ArgumentOutOfRangeException());
      if (value.GetType() == typeof (Func<JsValue, JsValue[], JsValue>))
      {
        Func<JsValue, JsValue[], JsValue> function = (Func<JsValue, JsValue[], JsValue>) value;
        if (type.IsGenericType())
        {
          Type genericTypeDefinition = type.GetGenericTypeDefinition();
          if (genericTypeDefinition.Name.StartsWith("Action"))
          {
            Type[] genericArguments = type.GetGenericArguments();
            ParameterExpression[] parameterExpressionArray = new ParameterExpression[((IEnumerable<Type>) genericArguments).Count<Type>()];
            for (int index = 0; index < ((IEnumerable<ParameterExpression>) parameterExpressionArray).Count<ParameterExpression>(); ++index)
              parameterExpressionArray[index] = Expression.Parameter(genericArguments[index], genericArguments[index].Name + (object) index);
            Expression[] expressionArray = new Expression[parameterExpressionArray.Length];
            for (int index = 0; index < ((IEnumerable<ParameterExpression>) parameterExpressionArray).Count<ParameterExpression>(); ++index)
            {
              ParameterExpression parameterExpression = parameterExpressionArray[index];
              if (parameterExpression.Type.IsValueType())
              {
                UnaryExpression unaryExpression = Expression.Convert((Expression) parameterExpression, typeof (object));
                expressionArray[index] = (Expression) Expression.Call((Expression) null, DefaultTypeConverter.jsValueFromObject, (Expression) Expression.Constant((object) this._engine, typeof (Engine)), (Expression) unaryExpression);
              }
              else
                expressionArray[index] = (Expression) Expression.Call((Expression) null, DefaultTypeConverter.jsValueFromObject, (Expression) Expression.Constant((object) this._engine, typeof (Engine)), (Expression) parameterExpression);
            }
            NewArrayExpression newArrayExpression = Expression.NewArrayInit(typeof (JsValue), expressionArray);
            return (object) Expression.Lambda((Expression) Expression.Block((Expression) Expression.Call((Expression) Expression.Call((Expression) Expression.Constant(function.Target), function.GetMethodInfo(), (Expression) Expression.Constant((object) JsValue.Undefined, typeof (JsValue)), (Expression) newArrayExpression), DefaultTypeConverter.jsValueToObject), (Expression) Expression.Empty()), (IEnumerable<ParameterExpression>) new ReadOnlyCollection<ParameterExpression>((IList<ParameterExpression>) parameterExpressionArray)).Compile();
          }
          if (genericTypeDefinition.Name.StartsWith("Func"))
          {
            Type[] genericArguments = type.GetGenericArguments();
            Type type1 = ((IEnumerable<Type>) genericArguments).Last<Type>();
            ParameterExpression[] parameterExpressionArray = new ParameterExpression[((IEnumerable<Type>) genericArguments).Count<Type>() - 1];
            for (int index = 0; index < ((IEnumerable<ParameterExpression>) parameterExpressionArray).Count<ParameterExpression>(); ++index)
              parameterExpressionArray[index] = Expression.Parameter(genericArguments[index], genericArguments[index].Name + (object) index);
            NewArrayExpression newArrayExpression = Expression.NewArrayInit(typeof (JsValue), (IEnumerable<Expression>) ((IEnumerable<ParameterExpression>) parameterExpressionArray).Select<ParameterExpression, MethodCallExpression>((Func<ParameterExpression, MethodCallExpression>) (p =>
            {
              UnaryExpression unaryExpression = Expression.Convert((Expression) p, typeof (object));
              return Expression.Call((Expression) null, DefaultTypeConverter.jsValueFromObject, (Expression) Expression.Constant((object) this._engine, typeof (Engine)), (Expression) unaryExpression);
            })));
            return (object) Expression.Lambda((Expression) Expression.Convert((Expression) Expression.Call((Expression) null, DefaultTypeConverter.convertChangeType, (Expression) Expression.Call((Expression) Expression.Call((Expression) Expression.Constant(function.Target), function.GetMethodInfo(), (Expression) Expression.Constant((object) JsValue.Undefined, typeof (JsValue)), (Expression) newArrayExpression), DefaultTypeConverter.jsValueToObject), (Expression) Expression.Constant((object) type1, typeof (Type)), (Expression) Expression.Constant((object) CultureInfo.InvariantCulture, typeof (IFormatProvider))), type1), (IEnumerable<ParameterExpression>) new ReadOnlyCollection<ParameterExpression>((IList<ParameterExpression>) parameterExpressionArray)).Compile();
          }
        }
        else
        {
          if (type == typeof (Action))
          {
            JsValue jsValue;
            return (object) (Action) (() => jsValue = function(JsValue.Undefined, new JsValue[0]));
          }
          if (typeof (MulticastDelegate).IsAssignableFrom(type))
          {
            ParameterInfo[] parameters = type.GetMethod("Invoke").GetParameters();
            ParameterExpression[] parameterExpressionArray = new ParameterExpression[((IEnumerable<ParameterInfo>) parameters).Count<ParameterInfo>()];
            for (int index = 0; index < ((IEnumerable<ParameterExpression>) parameterExpressionArray).Count<ParameterExpression>(); ++index)
              parameterExpressionArray[index] = Expression.Parameter(typeof (object), parameters[index].Name);
            NewArrayExpression newArrayExpression = Expression.NewArrayInit(typeof (JsValue), (IEnumerable<Expression>) ((IEnumerable<ParameterExpression>) parameterExpressionArray).Select<ParameterExpression, MethodCallExpression>((Func<ParameterExpression, MethodCallExpression>) (p => Expression.Call((Expression) null, typeof (JsValue).GetMethod("FromObject"), (Expression) Expression.Constant((object) this._engine, typeof (Engine)), (Expression) p))));
            InvocationExpression body = Expression.Invoke((Expression) Expression.Lambda((Expression) Expression.Block((Expression) Expression.Call((Expression) Expression.Call((Expression) Expression.Constant(function.Target), function.GetMethodInfo(), (Expression) Expression.Constant((object) JsValue.Undefined, typeof (JsValue)), (Expression) newArrayExpression), typeof (JsValue).GetMethod("ToObject")), (Expression) Expression.Empty()), (IEnumerable<ParameterExpression>) new ReadOnlyCollection<ParameterExpression>((IList<ParameterExpression>) parameterExpressionArray)), (IEnumerable<Expression>) new ReadOnlyCollection<ParameterExpression>((IList<ParameterExpression>) parameterExpressionArray));
            return (object) Expression.Lambda(type, (Expression) body, (IEnumerable<ParameterExpression>) new ReadOnlyCollection<ParameterExpression>((IList<ParameterExpression>) parameterExpressionArray)).Compile();
          }
        }
      }
      if (type.IsArray)
      {
        if (!(value is object[] source))
          throw new ArgumentException(string.Format("Value of object[] type is expected, but actual type is {0}.", (object) value.GetType()));
        Type targetElementType = type.GetElementType();
        object[] array1 = ((IEnumerable<object>) source).Select<object, object>((Func<object, object>) (o => this.Convert(o, targetElementType, formatProvider))).ToArray<object>();
        Array instance = Array.CreateInstance(targetElementType, source.Length);
        Array array2 = instance;
        array1.CopyTo(array2, 0);
        return (object) instance;
      }
      if (type.IsGenericType() && type.GetGenericTypeDefinition() == typeof (Nullable<>))
        type = Nullable.GetUnderlyingType(type);
      return System.Convert.ChangeType(value, type, formatProvider);
    }

    public virtual bool TryConvert(
      object value,
      Type type,
      IFormatProvider formatProvider,
      out object converted)
    {
      string key = value == null ? string.Format("Null->{0}", (object) type) : string.Format("{0}->{1}", (object) value.GetType(), (object) type);
      bool flag;
      if (!DefaultTypeConverter._knownConversions.TryGetValue(key, out flag))
      {
        lock (DefaultTypeConverter._lockObject)
        {
          if (!DefaultTypeConverter._knownConversions.TryGetValue(key, out flag))
          {
            try
            {
              converted = this.Convert(value, type, formatProvider);
              DefaultTypeConverter._knownConversions.Add(key, true);
              return true;
            }
            catch
            {
              converted = (object) null;
              DefaultTypeConverter._knownConversions.Add(key, false);
              return false;
            }
          }
        }
      }
      if (flag)
      {
        try
        {
          converted = this.Convert(value, type, formatProvider);
          return true;
        }
        catch
        {
          converted = (object) null;
          return false;
        }
      }
      else
      {
        converted = (object) null;
        return false;
      }
    }
  }
}
