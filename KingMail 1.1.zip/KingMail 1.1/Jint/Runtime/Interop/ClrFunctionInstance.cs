﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Interop.ClrFunctionInstance
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Native.Function;
using Jint.Native.Object;
using Jint.Runtime.Environments;
using System;

#nullable disable
namespace Jint.Runtime.Interop
{
  public sealed class ClrFunctionInstance : FunctionInstance
  {
    private readonly Func<JsValue, JsValue[], JsValue> _func;

    public ClrFunctionInstance(Engine engine, Func<JsValue, JsValue[], JsValue> func, int length)
      : base(engine, (string[]) null, (LexicalEnvironment) null, false)
    {
      this._func = func;
      this.Prototype = (ObjectInstance) engine.Function.PrototypeObject;
      this.FastAddProperty(nameof (length), (JsValue) (double) length, false, false, false);
      this.Extensible = true;
    }

    public ClrFunctionInstance(Engine engine, Func<JsValue, JsValue[], JsValue> func)
      : this(engine, func, 0)
    {
    }

    public override JsValue Call(JsValue thisObject, JsValue[] arguments)
    {
      try
      {
        return this._func(thisObject, arguments);
      }
      catch (InvalidCastException ex)
      {
        throw new JavaScriptException(this.Engine.TypeError);
      }
    }
  }
}
