﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Interop.MethodInfoFunctionInstance
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Native.Array;
using Jint.Native.Function;
using Jint.Native.Object;
using Jint.Runtime.Environments;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

#nullable disable
namespace Jint.Runtime.Interop
{
  public sealed class MethodInfoFunctionInstance : FunctionInstance
  {
    private readonly MethodInfo[] _methods;

    public MethodInfoFunctionInstance(Engine engine, MethodInfo[] methods)
      : base(engine, (string[]) null, (LexicalEnvironment) null, false)
    {
      this._methods = methods;
      this.Prototype = (ObjectInstance) engine.Function.PrototypeObject;
    }

    public override JsValue Call(JsValue thisObject, JsValue[] arguments)
    {
      return this.Invoke(this._methods, thisObject, arguments);
    }

    public JsValue Invoke(MethodInfo[] methodInfos, JsValue thisObject, JsValue[] jsArguments)
    {
      JsValue[] arguments = this.ProcessParamsArrays(jsArguments, (IEnumerable<MethodInfo>) methodInfos);
      List<MethodBase> list = TypeConverter.FindBestMatch(this.Engine, (MethodBase[]) methodInfos, arguments).ToList<MethodBase>();
      ITypeConverter clrTypeConverter = this.Engine.ClrTypeConverter;
      foreach (MethodBase methodBase in list)
      {
        object[] source = new object[arguments.Length];
        bool flag = true;
        for (int index1 = 0; index1 < arguments.Length; ++index1)
        {
          Type parameterType = methodBase.GetParameters()[index1].ParameterType;
          if (parameterType == typeof (JsValue))
            source[index1] = (object) arguments[index1];
          else if (parameterType == typeof (JsValue[]) && arguments[index1].IsArray())
          {
            ArrayInstance arrayInstance = arguments[index1].AsArray();
            int int32 = TypeConverter.ToInt32(arrayInstance.Get("length"));
            JsValue[] jsValueArray = new JsValue[int32];
            for (int index2 = 0; index2 < int32; ++index2)
            {
              string propertyName = index2.ToString();
              jsValueArray[index2] = arrayInstance.HasProperty(propertyName) ? arrayInstance.Get(propertyName) : JsValue.Undefined;
            }
            source[index1] = (object) jsValueArray;
          }
          else
          {
            if (!clrTypeConverter.TryConvert(arguments[index1].ToObject(), parameterType, (IFormatProvider) CultureInfo.InvariantCulture, out source[index1]))
            {
              flag = false;
              break;
            }
            if (source[index1] is LambdaExpression lambdaExpression)
              source[index1] = (object) lambdaExpression.Compile();
          }
        }
        if (flag)
        {
          try
          {
            return JsValue.FromObject(this.Engine, methodBase.Invoke(thisObject.ToObject(), ((IEnumerable<object>) source).ToArray<object>()));
          }
          catch (TargetInvocationException ex)
          {
            Exception exception = ex.InnerException ?? (Exception) ex;
            Predicate<Exception> exceptionsHandler = this.Engine.Options._ClrExceptionsHandler;
            if (exceptionsHandler != null && exceptionsHandler(exception))
              throw new JavaScriptException(this.Engine.Error, exception.Message);
            throw exception;
          }
        }
      }
      throw new JavaScriptException(this.Engine.TypeError, "No public methods with the specified arguments were found.");
    }

    private JsValue[] ProcessParamsArrays(
      JsValue[] jsArguments,
      IEnumerable<MethodInfo> methodInfos)
    {
      foreach (MethodBase methodInfo in methodInfos)
      {
        ParameterInfo[] parameters = methodInfo.GetParameters();
        if (((IEnumerable<ParameterInfo>) parameters).Any<ParameterInfo>((Func<ParameterInfo, bool>) (p => p.HasAttribute<ParamArrayAttribute>())))
        {
          int count = parameters.Length - 1;
          if (jsArguments.Length >= count)
          {
            List<JsValue> list1 = ((IEnumerable<JsValue>) jsArguments).Take<JsValue>(count).ToList<JsValue>();
            List<JsValue> list2 = ((IEnumerable<JsValue>) jsArguments).Skip<JsValue>(count).ToList<JsValue>();
            if (list2.Count != 1 || !list2.FirstOrDefault<JsValue>().IsArray())
            {
              ObjectInstance thisObject = this.Engine.Array.Construct(Arguments.Empty);
              this.Engine.Array.PrototypeObject.Push((JsValue) thisObject, list2.ToArray());
              list1.Add(new JsValue(thisObject));
              return list1.ToArray();
            }
          }
        }
      }
      return jsArguments;
    }
  }
}
