﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Interop.IReferenceResolver
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Runtime.References;

#nullable disable
namespace Jint.Runtime.Interop
{
  public interface IReferenceResolver
  {
    bool TryUnresolvableReference(Engine engine, Reference reference, out JsValue value);

    bool TryPropertyReference(Engine engine, Reference reference, ref JsValue value);

    bool TryGetCallable(Engine engine, object callee, out JsValue value);

    bool CheckCoercible(JsValue value);
  }
}
