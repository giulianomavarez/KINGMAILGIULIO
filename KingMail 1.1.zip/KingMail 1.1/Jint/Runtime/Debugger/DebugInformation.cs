﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Debugger.DebugInformation
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Parser.Ast;
using System;
using System.Collections.Generic;

#nullable disable
namespace Jint.Runtime.Debugger
{
  public class DebugInformation : EventArgs
  {
    public Stack<string> CallStack { get; set; }

    public Statement CurrentStatement { get; set; }

    public Dictionary<string, JsValue> Locals { get; set; }

    public Dictionary<string, JsValue> Globals { get; set; }
  }
}
