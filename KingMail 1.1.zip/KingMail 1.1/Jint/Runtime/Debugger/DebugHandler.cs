﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Debugger.DebugHandler
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Parser.Ast;
using Jint.Runtime.Environments;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace Jint.Runtime.Debugger
{
  internal class DebugHandler
  {
    private readonly Stack<string> _debugCallStack;
    private StepMode _stepMode;
    private int _callBackStepOverDepth;
    private readonly Engine _engine;

    public DebugHandler(Engine engine)
    {
      this._engine = engine;
      this._debugCallStack = new Stack<string>();
      this._stepMode = StepMode.Into;
    }

    internal void PopDebugCallStack()
    {
      if (this._debugCallStack.Count > 0)
        this._debugCallStack.Pop();
      if (this._stepMode == StepMode.Out && this._debugCallStack.Count < this._callBackStepOverDepth)
      {
        this._callBackStepOverDepth = this._debugCallStack.Count;
        this._stepMode = StepMode.Into;
      }
      else
      {
        if (this._stepMode != StepMode.Over || this._debugCallStack.Count != this._callBackStepOverDepth)
          return;
        this._callBackStepOverDepth = this._debugCallStack.Count;
        this._stepMode = StepMode.Into;
      }
    }

    internal void AddToDebugCallStack(CallExpression callExpression)
    {
      if (!(callExpression.Callee is Identifier callee))
        return;
      string str = callee.Name + "(";
      List<string> values = new List<string>();
      foreach (Expression expression in (IEnumerable<Expression>) callExpression.Arguments)
      {
        if (expression != null)
        {
          Identifier identifier = expression as Identifier;
          values.Add(identifier != null ? identifier.Name : "null");
        }
        else
          values.Add("null");
      }
      this._debugCallStack.Push(str + string.Join(", ", (IEnumerable<string>) values) + ")");
    }

    internal void OnStep(Statement statement)
    {
      StepMode stepMode = this._stepMode;
      if (statement == null)
        return;
      BreakPoint breakPoint1 = this._engine.BreakPoints.FirstOrDefault<BreakPoint>((Func<BreakPoint, bool>) (breakPoint => this.BpTest(statement, breakPoint)));
      bool flag = false;
      if (breakPoint1 != null)
      {
        StepMode? nullable = this._engine.InvokeBreakEvent(this.CreateDebugInformation(statement));
        if (nullable.HasValue)
        {
          this._stepMode = nullable.Value;
          flag = true;
        }
      }
      if (!flag && this._stepMode == StepMode.Into)
      {
        StepMode? nullable = this._engine.InvokeStepEvent(this.CreateDebugInformation(statement));
        if (nullable.HasValue)
          this._stepMode = nullable.Value;
      }
      if (stepMode == StepMode.Into && this._stepMode == StepMode.Out)
      {
        this._callBackStepOverDepth = this._debugCallStack.Count;
      }
      else
      {
        if (stepMode != StepMode.Into || this._stepMode != StepMode.Over)
          return;
        if (statement is ExpressionStatement expressionStatement && expressionStatement.Expression is CallExpression)
          this._callBackStepOverDepth = this._debugCallStack.Count;
        else
          this._stepMode = StepMode.Into;
      }
    }

    private bool BpTest(Statement statement, BreakPoint breakpoint)
    {
      if ((breakpoint.Line != statement.Location.Start.Line ? 0 : (breakpoint.Char >= statement.Location.Start.Column ? 1 : 0)) == 0 || (breakpoint.Line < statement.Location.End.Line ? 1 : (breakpoint.Line != statement.Location.End.Line ? 0 : (breakpoint.Char <= statement.Location.End.Column ? 1 : 0))) == 0)
        return false;
      return string.IsNullOrEmpty(breakpoint.Condition) || this._engine.Execute(breakpoint.Condition).GetCompletionValue().AsBoolean();
    }

    private DebugInformation CreateDebugInformation(Statement statement)
    {
      DebugInformation debugInformation = new DebugInformation()
      {
        CurrentStatement = statement,
        CallStack = this._debugCallStack
      };
      if (this._engine.ExecutionContext != null && this._engine.ExecutionContext.LexicalEnvironment != null)
      {
        LexicalEnvironment lexicalEnvironment = this._engine.ExecutionContext.LexicalEnvironment;
        debugInformation.Locals = DebugHandler.GetLocalVariables(lexicalEnvironment);
        debugInformation.Globals = DebugHandler.GetGlobalVariables(lexicalEnvironment);
      }
      return debugInformation;
    }

    private static Dictionary<string, JsValue> GetLocalVariables(LexicalEnvironment lex)
    {
      Dictionary<string, JsValue> locals = new Dictionary<string, JsValue>();
      if (lex != null && lex.Record != null)
        DebugHandler.AddRecordsFromEnvironment(lex, locals);
      return locals;
    }

    private static Dictionary<string, JsValue> GetGlobalVariables(LexicalEnvironment lex)
    {
      Dictionary<string, JsValue> locals = new Dictionary<string, JsValue>();
      for (LexicalEnvironment lex1 = lex; lex1 != null && lex1.Record != null; lex1 = lex1.Outer)
        DebugHandler.AddRecordsFromEnvironment(lex1, locals);
      return locals;
    }

    private static void AddRecordsFromEnvironment(
      LexicalEnvironment lex,
      Dictionary<string, JsValue> locals)
    {
      foreach (string allBindingName in lex.Record.GetAllBindingNames())
      {
        if (!locals.ContainsKey(allBindingName))
        {
          JsValue bindingValue = lex.Record.GetBindingValue(allBindingName, false);
          if (bindingValue.TryCast<ICallable>() == null)
            locals.Add(allBindingName, bindingValue);
        }
      }
    }
  }
}
