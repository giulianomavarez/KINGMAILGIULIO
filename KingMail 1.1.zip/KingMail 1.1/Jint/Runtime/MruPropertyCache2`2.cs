﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.MruPropertyCache2`2
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using System.Collections;
using System.Collections.Generic;

#nullable disable
namespace Jint.Runtime
{
  public class MruPropertyCache2<TKey, TValue> : 
    IDictionary<TKey, TValue>,
    ICollection<KeyValuePair<TKey, TValue>>,
    IEnumerable<KeyValuePair<TKey, TValue>>,
    IEnumerable
    where TValue : class
  {
    private IDictionary<TKey, TValue> _dictionary = (IDictionary<TKey, TValue>) new Dictionary<TKey, TValue>();
    private bool _set;
    private TKey _key;
    private TValue _value;

    public TValue this[TKey key]
    {
      get => this._set && key.Equals((object) this._key) ? this._value : this._dictionary[key];
      set
      {
        this._set = true;
        this._key = key;
        this._value = value;
        this._dictionary[key] = value;
      }
    }

    public int Count => this._dictionary.Count;

    public bool IsReadOnly => this._dictionary.IsReadOnly;

    public ICollection<TKey> Keys => this._dictionary.Keys;

    public ICollection<TValue> Values => this._dictionary.Values;

    public void Add(KeyValuePair<TKey, TValue> item)
    {
      this._set = true;
      this._key = item.Key;
      this._value = item.Value;
      this._dictionary.Add(item);
    }

    public void Add(TKey key, TValue value)
    {
      this._set = true;
      this._key = key;
      this._value = value;
      this._dictionary.Add(key, value);
    }

    public void Clear()
    {
      this._set = false;
      this._key = default (TKey);
      this._value = default (TValue);
      this._dictionary.Clear();
    }

    public bool Contains(KeyValuePair<TKey, TValue> item)
    {
      return this._set && item.Key.Equals((object) this._key) || this._dictionary.Contains(item);
    }

    public bool ContainsKey(TKey key)
    {
      return this._set && key.Equals((object) this._key) || this._dictionary.ContainsKey(key);
    }

    public void CopyTo(KeyValuePair<TKey, TValue>[] array, int arrayIndex)
    {
      this._dictionary.CopyTo(array, arrayIndex);
    }

    public IEnumerator<KeyValuePair<TKey, TValue>> GetEnumerator()
    {
      return this._dictionary.GetEnumerator();
    }

    public bool Remove(KeyValuePair<TKey, TValue> item)
    {
      if (this._set && item.Key.Equals((object) this._key))
      {
        this._set = false;
        this._key = default (TKey);
        this._value = default (TValue);
      }
      return ((ICollection<KeyValuePair<TKey, TValue>>) this._dictionary).Remove(item);
    }

    public bool Remove(TKey key)
    {
      if (this._set && key.Equals((object) this._key))
      {
        this._set = false;
        this._key = default (TKey);
        this._value = default (TValue);
      }
      return this._dictionary.Remove(key);
    }

    public bool TryGetValue(TKey key, out TValue value)
    {
      if (!this._set || !key.Equals((object) this._key))
        return this._dictionary.TryGetValue(key, out value);
      value = this._value;
      return true;
    }

    IEnumerator IEnumerable.GetEnumerator() => (IEnumerator) this._dictionary.GetEnumerator();
  }
}
