﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.CallStackElement
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Parser.Ast;

#nullable disable
namespace Jint.Runtime
{
  public class CallStackElement
  {
    private string _shortDescription;

    public CallStackElement(
      CallExpression callExpression,
      JsValue function,
      string shortDescription)
    {
      this._shortDescription = shortDescription;
      this.CallExpression = callExpression;
      this.Function = function;
    }

    public CallExpression CallExpression { get; private set; }

    public JsValue Function { get; private set; }

    public override string ToString() => this._shortDescription;
  }
}
