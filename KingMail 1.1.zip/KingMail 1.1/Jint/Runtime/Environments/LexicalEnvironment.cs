﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Environments.LexicalEnvironment
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Native.Object;
using Jint.Runtime.References;

#nullable disable
namespace Jint.Runtime.Environments
{
  public sealed class LexicalEnvironment
  {
    private readonly EnvironmentRecord _record;
    private readonly LexicalEnvironment _outer;

    public LexicalEnvironment(EnvironmentRecord record, LexicalEnvironment outer)
    {
      this._record = record;
      this._outer = outer;
    }

    public EnvironmentRecord Record => this._record;

    public LexicalEnvironment Outer => this._outer;

    public static Reference GetIdentifierReference(
      LexicalEnvironment lex,
      string name,
      bool strict)
    {
      if (lex == null)
        return new Reference(Undefined.Instance, name, strict);
      if (lex.Record.HasBinding(name))
        return new Reference((JsValue) (ObjectInstance) lex.Record, name, strict);
      return lex.Outer == null ? new Reference(Undefined.Instance, name, strict) : LexicalEnvironment.GetIdentifierReference(lex.Outer, name, strict);
    }

    public static LexicalEnvironment NewDeclarativeEnvironment(
      Engine engine,
      LexicalEnvironment outer = null)
    {
      return new LexicalEnvironment((EnvironmentRecord) new DeclarativeEnvironmentRecord(engine), outer);
    }

    public static LexicalEnvironment NewObjectEnvironment(
      Engine engine,
      ObjectInstance objectInstance,
      LexicalEnvironment outer,
      bool provideThis)
    {
      return new LexicalEnvironment((EnvironmentRecord) new ObjectEnvironmentRecord(engine, objectInstance, provideThis), outer);
    }
  }
}
