﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Environments.EnvironmentRecord
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Native.Object;

#nullable disable
namespace Jint.Runtime.Environments
{
  public abstract class EnvironmentRecord(Engine engine) : ObjectInstance(engine)
  {
    public abstract bool HasBinding(string name);

    public abstract void CreateMutableBinding(string name, bool canBeDeleted = false);

    public abstract void SetMutableBinding(string name, JsValue value, bool strict);

    public abstract JsValue GetBindingValue(string name, bool strict);

    public abstract bool DeleteBinding(string name);

    public abstract JsValue ImplicitThisValue();

    public abstract string[] GetAllBindingNames();
  }
}
