﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Environments.ObjectEnvironmentRecord
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using Jint.Native.Object;
using Jint.Runtime.Descriptors;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace Jint.Runtime.Environments
{
  public sealed class ObjectEnvironmentRecord : EnvironmentRecord
  {
    private readonly Engine _engine;
    private readonly ObjectInstance _bindingObject;
    private readonly bool _provideThis;

    public ObjectEnvironmentRecord(Engine engine, ObjectInstance bindingObject, bool provideThis)
      : base(engine)
    {
      this._engine = engine;
      this._bindingObject = bindingObject;
      this._provideThis = provideThis;
    }

    public override bool HasBinding(string name) => this._bindingObject.HasProperty(name);

    public override void CreateMutableBinding(string name, bool configurable = true)
    {
      this._bindingObject.DefineOwnProperty(name, new PropertyDescriptor(Undefined.Instance, new bool?(true), new bool?(true), new bool?(configurable)), true);
    }

    public override void SetMutableBinding(string name, JsValue value, bool strict)
    {
      this._bindingObject.Put(name, value, strict);
    }

    public override JsValue GetBindingValue(string name, bool strict)
    {
      if (this._bindingObject.HasProperty(name))
        return this._bindingObject.Get(name);
      if (!strict)
        return Undefined.Instance;
      throw new JavaScriptException(this._engine.ReferenceError);
    }

    public override bool DeleteBinding(string name) => this._bindingObject.Delete(name, false);

    public override JsValue ImplicitThisValue()
    {
      return this._provideThis ? new JsValue(this._bindingObject) : Undefined.Instance;
    }

    public override string[] GetAllBindingNames()
    {
      return this._bindingObject != null ? this._bindingObject.GetOwnProperties().Select<KeyValuePair<string, PropertyDescriptor>, string>((Func<KeyValuePair<string, PropertyDescriptor>, string>) (x => x.Key)).ToArray<string>() : new string[0];
    }
  }
}
