﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Environments.DeclarativeEnvironmentRecord
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace Jint.Runtime.Environments
{
  public sealed class DeclarativeEnvironmentRecord : EnvironmentRecord
  {
    private readonly Engine _engine;
    private readonly IDictionary<string, Binding> _bindings = (IDictionary<string, Binding>) new Dictionary<string, Binding>();

    public DeclarativeEnvironmentRecord(Engine engine)
      : base(engine)
    {
      this._engine = engine;
    }

    public override bool HasBinding(string name) => this._bindings.ContainsKey(name);

    public override void CreateMutableBinding(string name, bool canBeDeleted = false)
    {
      this._bindings.Add(name, new Binding()
      {
        Value = Undefined.Instance,
        CanBeDeleted = canBeDeleted,
        Mutable = true
      });
    }

    public override void SetMutableBinding(string name, JsValue value, bool strict)
    {
      Binding binding = this._bindings[name];
      if (binding.Mutable)
        binding.Value = value;
      else if (strict)
        throw new JavaScriptException(this._engine.TypeError, "Can't update the value of an immutable binding.");
    }

    public override JsValue GetBindingValue(string name, bool strict)
    {
      Binding binding = this._bindings[name];
      if (binding.Mutable || !(binding.Value == Undefined.Instance))
        return binding.Value;
      if (strict)
        throw new JavaScriptException(this._engine.ReferenceError, "Can't access anm uninitiazed immutable binding.");
      return Undefined.Instance;
    }

    public override bool DeleteBinding(string name)
    {
      Binding binding;
      if (!this._bindings.TryGetValue(name, out binding))
        return true;
      if (!binding.CanBeDeleted)
        return false;
      this._bindings.Remove(name);
      return true;
    }

    public override JsValue ImplicitThisValue() => Undefined.Instance;

    public void CreateImmutableBinding(string name)
    {
      this._bindings.Add(name, new Binding()
      {
        Value = Undefined.Instance,
        Mutable = false,
        CanBeDeleted = false
      });
    }

    public void InitializeImmutableBinding(string name, JsValue value)
    {
      this._bindings[name].Value = value;
    }

    public override string[] GetAllBindingNames() => this._bindings.Keys.ToArray<string>();
  }
}
