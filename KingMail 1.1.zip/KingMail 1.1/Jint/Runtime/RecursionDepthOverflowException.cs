﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.RecursionDepthOverflowException
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Runtime.CallStack;
using System;

#nullable disable
namespace Jint.Runtime
{
  public class RecursionDepthOverflowException : Exception
  {
    public string CallChain { get; private set; }

    public string CallExpressionReference { get; private set; }

    public RecursionDepthOverflowException(
      JintCallStack currentStack,
      string currentExpressionReference)
      : base("The recursion is forbidden by script host.")
    {
      this.CallExpressionReference = currentExpressionReference;
      this.CallChain = currentStack.ToString();
    }
  }
}
