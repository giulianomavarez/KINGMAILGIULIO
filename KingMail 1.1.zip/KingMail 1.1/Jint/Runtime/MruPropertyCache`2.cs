﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.MruPropertyCache`2
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using System.Collections;
using System.Collections.Generic;

#nullable disable
namespace Jint.Runtime
{
  public class MruPropertyCache<TKey, TValue> : 
    IDictionary<TKey, TValue>,
    ICollection<KeyValuePair<TKey, TValue>>,
    IEnumerable<KeyValuePair<TKey, TValue>>,
    IEnumerable
  {
    private IDictionary<TKey, TValue> _dictionary = (IDictionary<TKey, TValue>) new Dictionary<TKey, TValue>();
    private LinkedList<KeyValuePair<TKey, TValue>> _list;
    private uint _length;

    public MruPropertyCache(uint length)
    {
      this._length = length;
      this._list = new LinkedList<KeyValuePair<TKey, TValue>>();
      for (int index = 0; (long) index < (long) length; ++index)
        this._list.AddLast(new KeyValuePair<TKey, TValue>(default (TKey), default (TValue)));
    }

    private bool Find(
      TKey key,
      out LinkedListNode<KeyValuePair<TKey, TValue>> result)
    {
      result = this._list.First;
      while (result != null)
      {
        if (key.Equals((object) result.Value.Key))
          return true;
        result = result.Next;
      }
      return false;
    }

    public TValue this[TKey key]
    {
      get
      {
        LinkedListNode<KeyValuePair<TKey, TValue>> result;
        return this.Find(key, out result) ? result.Value.Value : this._dictionary[key];
      }
      set
      {
        LinkedListNode<KeyValuePair<TKey, TValue>> result;
        if (!this.Find(key, out result))
        {
          this._list.AddFirst(new KeyValuePair<TKey, TValue>(key, value));
          this._list.RemoveLast();
        }
        else
          result.Value = new KeyValuePair<TKey, TValue>(key, value);
        this._dictionary[key] = value;
      }
    }

    public int Count => this._dictionary.Count;

    public bool IsReadOnly => this._dictionary.IsReadOnly;

    public ICollection<TKey> Keys => this._dictionary.Keys;

    public ICollection<TValue> Values => this._dictionary.Values;

    public void Add(KeyValuePair<TKey, TValue> item)
    {
      if (!this.Find(item.Key, out LinkedListNode<KeyValuePair<TKey, TValue>> _))
      {
        this._list.AddFirst(item);
        this._list.RemoveLast();
      }
      this._dictionary.Add(item);
    }

    public void Add(TKey key, TValue value)
    {
      if (!this.Find(key, out LinkedListNode<KeyValuePair<TKey, TValue>> _))
      {
        this._list.AddFirst(new KeyValuePair<TKey, TValue>(key, value));
        this._list.RemoveLast();
      }
      this._dictionary.Add(key, value);
    }

    public void Clear()
    {
      this._list.Clear();
      this._dictionary.Clear();
    }

    public bool Contains(KeyValuePair<TKey, TValue> item)
    {
      return this.Find(item.Key, out LinkedListNode<KeyValuePair<TKey, TValue>> _) || this._dictionary.Contains(item);
    }

    public bool ContainsKey(TKey key)
    {
      return this.Find(key, out LinkedListNode<KeyValuePair<TKey, TValue>> _) || this._dictionary.ContainsKey(key);
    }

    public void CopyTo(KeyValuePair<TKey, TValue>[] array, int arrayIndex)
    {
      this._dictionary.CopyTo(array, arrayIndex);
    }

    public IEnumerator<KeyValuePair<TKey, TValue>> GetEnumerator()
    {
      return this._dictionary.GetEnumerator();
    }

    public bool Remove(KeyValuePair<TKey, TValue> item)
    {
      LinkedListNode<KeyValuePair<TKey, TValue>> result;
      if (this.Find(item.Key, out result))
        this._list.Remove(result);
      return ((ICollection<KeyValuePair<TKey, TValue>>) this._dictionary).Remove(item);
    }

    public bool Remove(TKey key)
    {
      LinkedListNode<KeyValuePair<TKey, TValue>> result;
      if (this.Find(key, out result))
        this._list.Remove(result);
      return this._dictionary.Remove(key);
    }

    public bool TryGetValue(TKey key, out TValue value)
    {
      LinkedListNode<KeyValuePair<TKey, TValue>> result;
      if (!this.Find(key, out result))
        return this._dictionary.TryGetValue(key, out value);
      value = result.Value.Value;
      return true;
    }

    IEnumerator IEnumerable.GetEnumerator() => (IEnumerator) this._dictionary.GetEnumerator();
  }
}
