﻿// Decompiled with JetBrains decompiler
// Type: Jint.Runtime.Arguments
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native;

#nullable disable
namespace Jint.Runtime
{
  public static class Arguments
  {
    public static JsValue[] Empty = new JsValue[0];

    public static JsValue[] From(params JsValue[] o) => o;

    public static JsValue At(this JsValue[] args, int index, JsValue undefinedValue)
    {
      return args.Length <= index ? undefinedValue : args[index];
    }

    public static JsValue At(this JsValue[] args, int index) => args.At(index, Undefined.Instance);
  }
}
