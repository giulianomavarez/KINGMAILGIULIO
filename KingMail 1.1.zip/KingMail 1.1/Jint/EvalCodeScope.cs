﻿// Decompiled with JetBrains decompiler
// Type: Jint.EvalCodeScope
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using System;

#nullable disable
namespace Jint
{
  public class EvalCodeScope : IDisposable
  {
    private readonly bool _eval;
    private readonly bool _force;
    private readonly int _forcedRefCount;
    [ThreadStatic]
    private static int _refCount;

    public EvalCodeScope(bool eval = true, bool force = false)
    {
      this._eval = eval;
      this._force = force;
      if (this._force)
      {
        this._forcedRefCount = EvalCodeScope._refCount;
        EvalCodeScope._refCount = 0;
      }
      if (!this._eval)
        return;
      ++EvalCodeScope._refCount;
    }

    public void Dispose()
    {
      if (this._eval)
        --EvalCodeScope._refCount;
      if (!this._force)
        return;
      EvalCodeScope._refCount = this._forcedRefCount;
    }

    public static bool IsEvalCode => EvalCodeScope._refCount > 0;

    public static int RefCount
    {
      get => EvalCodeScope._refCount;
      set => EvalCodeScope._refCount = value;
    }
  }
}
