﻿// Decompiled with JetBrains decompiler
// Type: Jint.Options
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Runtime.Interop;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;

#nullable disable
namespace Jint
{
  public class Options
  {
    private bool _discardGlobal;
    private bool _strict;
    private bool _allowDebuggerStatement;
    private bool _debugMode;
    private bool _allowClr;
    private readonly List<IObjectConverter> _objectConverters = new List<IObjectConverter>();
    private int _maxStatements;
    private int _maxRecursionDepth = -1;
    private TimeSpan _timeoutInterval;
    private CultureInfo _culture = CultureInfo.CurrentCulture;
    private TimeZoneInfo _localTimeZone = TimeZoneInfo.Local;
    private List<Assembly> _lookupAssemblies = new List<Assembly>();
    private Predicate<Exception> _clrExceptionsHandler;
    private IReferenceResolver _referenceResolver;

    public Options DiscardGlobal(bool discard = true)
    {
      this._discardGlobal = discard;
      return this;
    }

    public Options Strict(bool strict = true)
    {
      this._strict = strict;
      return this;
    }

    public Options AllowDebuggerStatement(bool allowDebuggerStatement = true)
    {
      this._allowDebuggerStatement = allowDebuggerStatement;
      return this;
    }

    public Options DebugMode(bool debugMode = true)
    {
      this._debugMode = debugMode;
      return this;
    }

    public Options AddObjectConverter(IObjectConverter objectConverter)
    {
      this._objectConverters.Add(objectConverter);
      return this;
    }

    public Options AllowClr(params Assembly[] assemblies)
    {
      this._allowClr = true;
      this._lookupAssemblies.AddRange((IEnumerable<Assembly>) assemblies);
      this._lookupAssemblies = this._lookupAssemblies.Distinct<Assembly>().ToList<Assembly>();
      return this;
    }

    public Options CatchClrExceptions()
    {
      this.CatchClrExceptions((Predicate<Exception>) (_ => true));
      return this;
    }

    public Options CatchClrExceptions(Predicate<Exception> handler)
    {
      this._clrExceptionsHandler = handler;
      return this;
    }

    public Options MaxStatements(int maxStatements = 0)
    {
      this._maxStatements = maxStatements;
      return this;
    }

    public Options TimeoutInterval(TimeSpan timeoutInterval)
    {
      this._timeoutInterval = timeoutInterval;
      return this;
    }

    public Options LimitRecursion(int maxRecursionDepth = 0)
    {
      this._maxRecursionDepth = maxRecursionDepth;
      return this;
    }

    public Options Culture(CultureInfo cultureInfo)
    {
      this._culture = cultureInfo;
      return this;
    }

    public Options LocalTimeZone(TimeZoneInfo timeZoneInfo)
    {
      this._localTimeZone = timeZoneInfo;
      return this;
    }

    public Options SetReferencesResolver(IReferenceResolver resolver)
    {
      this._referenceResolver = resolver;
      return this;
    }

    internal bool _IsGlobalDiscarded => this._discardGlobal;

    internal bool _IsStrict => this._strict;

    internal bool _IsDebuggerStatementAllowed => this._allowDebuggerStatement;

    internal bool _IsDebugMode => this._debugMode;

    internal bool _IsClrAllowed => this._allowClr;

    internal Predicate<Exception> _ClrExceptionsHandler => this._clrExceptionsHandler;

    internal IList<Assembly> _LookupAssemblies => (IList<Assembly>) this._lookupAssemblies;

    internal IEnumerable<IObjectConverter> _ObjectConverters
    {
      get => (IEnumerable<IObjectConverter>) this._objectConverters;
    }

    internal int _MaxStatements => this._maxStatements;

    internal int _MaxRecursionDepth => this._maxRecursionDepth;

    internal TimeSpan _TimeoutInterval => this._timeoutInterval;

    internal CultureInfo _Culture => this._culture;

    internal TimeZoneInfo _LocalTimeZone => this._localTimeZone;

    internal IReferenceResolver _ReferenceResolver => this._referenceResolver;
  }
}
