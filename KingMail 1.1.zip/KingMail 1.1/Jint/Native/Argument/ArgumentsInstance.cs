﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Argument.ArgumentsInstance
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Function;
using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Descriptors;
using Jint.Runtime.Descriptors.Specialized;
using Jint.Runtime.Environments;
using System;
using System.Collections.Generic;

#nullable disable
namespace Jint.Native.Argument
{
  public class ArgumentsInstance : ObjectInstance
  {
    private Action<ArgumentsInstance> _initializer;
    private bool _initialized;

    private ArgumentsInstance(Engine engine, Action<ArgumentsInstance> initializer)
      : base(engine)
    {
      this._initializer = initializer;
      this._initialized = false;
    }

    public bool Strict { get; set; }

    protected override void EnsureInitialized()
    {
      if (this._initialized)
        return;
      this._initialized = true;
      this._initializer(this);
    }

    public static ArgumentsInstance CreateArgumentsObject(
      Engine engine,
      FunctionInstance func,
      string[] names,
      JsValue[] args,
      EnvironmentRecord env,
      bool strict)
    {
      ArgumentsInstance argumentsObject = new ArgumentsInstance(engine, (Action<ArgumentsInstance>) (self =>
      {
        int length = args.Length;
        self.FastAddProperty("length", (JsValue) (double) length, true, false, true);
        ObjectInstance objectInstance1 = engine.Object.Construct(Arguments.Empty);
        List<string> stringList = new List<string>();
        for (int o1 = 0; o1 <= length - 1; ++o1)
        {
          string name1 = TypeConverter.ToString((JsValue) (double) o1);
          JsValue jsValue = args[o1];
          self.FastAddProperty(name1, jsValue, true, true, true);
          if (o1 < names.Length)
          {
            string name = names[o1];
            if (!strict && !stringList.Contains(name))
            {
              stringList.Add(name);
              Func<JsValue, JsValue> get = (Func<JsValue, JsValue>) (n => env.GetBindingValue(name, false));
              Action<JsValue, JsValue> set = (Action<JsValue, JsValue>) ((n, o) => env.SetMutableBinding(name, o, true));
              ObjectInstance objectInstance2 = objectInstance1;
              string propertyName = name1;
              objectInstance2.DefineOwnProperty(propertyName, (PropertyDescriptor) new ClrAccessDescriptor(engine, get, set)
              {
                Configurable = new bool?(true)
              }, false);
            }
          }
        }
        if (stringList.Count > 0)
          self.ParameterMap = objectInstance1;
        if (!strict)
        {
          self.FastAddProperty("callee", (JsValue) (ObjectInstance) func, true, false, true);
        }
        else
        {
          FunctionInstance throwTypeError = engine.Function.ThrowTypeError;
          self.DefineOwnProperty("caller", new PropertyDescriptor((JsValue) (ObjectInstance) throwTypeError, (JsValue) (ObjectInstance) throwTypeError, new bool?(false), new bool?(false)), false);
          self.DefineOwnProperty("callee", new PropertyDescriptor((JsValue) (ObjectInstance) throwTypeError, (JsValue) (ObjectInstance) throwTypeError, new bool?(false), new bool?(false)), false);
        }
      }));
      argumentsObject.Prototype = (ObjectInstance) engine.Object.PrototypeObject;
      argumentsObject.Extensible = true;
      argumentsObject.Strict = strict;
      return argumentsObject;
    }

    public ObjectInstance ParameterMap { get; set; }

    public override string Class => "Arguments";

    public override PropertyDescriptor GetOwnProperty(string propertyName)
    {
      this.EnsureInitialized();
      if (this.Strict || this.ParameterMap == null)
        return base.GetOwnProperty(propertyName);
      PropertyDescriptor ownProperty = base.GetOwnProperty(propertyName);
      if (ownProperty == PropertyDescriptor.Undefined || this.ParameterMap.GetOwnProperty(propertyName) == PropertyDescriptor.Undefined)
        return ownProperty;
      ownProperty.Value = this.ParameterMap.Get(propertyName);
      return ownProperty;
    }

    public override void Put(string propertyName, JsValue value, bool throwOnError)
    {
      this.EnsureInitialized();
      if (!this.CanPut(propertyName))
      {
        if (throwOnError)
          throw new JavaScriptException(this.Engine.TypeError);
      }
      else if (this.GetOwnProperty(propertyName).IsDataDescriptor())
      {
        PropertyDescriptor desc = new PropertyDescriptor(value, new bool?(), new bool?(), new bool?());
        this.DefineOwnProperty(propertyName, desc, throwOnError);
      }
      else
      {
        PropertyDescriptor property = this.GetProperty(propertyName);
        if (property.IsAccessorDescriptor())
        {
          property.Set.TryCast<ICallable>().Call(new JsValue((ObjectInstance) this), new JsValue[1]
          {
            value
          });
        }
        else
        {
          PropertyDescriptor desc = new PropertyDescriptor(value, new bool?(true), new bool?(true), new bool?(true));
          this.DefineOwnProperty(propertyName, desc, throwOnError);
        }
      }
    }

    public override bool DefineOwnProperty(
      string propertyName,
      PropertyDescriptor desc,
      bool throwOnError)
    {
      this.EnsureInitialized();
      if (this.Strict || this.ParameterMap == null)
        return base.DefineOwnProperty(propertyName, desc, throwOnError);
      ObjectInstance parameterMap = this.ParameterMap;
      PropertyDescriptor ownProperty = parameterMap.GetOwnProperty(propertyName);
      if (!base.DefineOwnProperty(propertyName, desc, false) && throwOnError)
        throw new JavaScriptException(this.Engine.TypeError);
      PropertyDescriptor undefined = PropertyDescriptor.Undefined;
      if (ownProperty != undefined)
      {
        if (desc.IsAccessorDescriptor())
        {
          parameterMap.Delete(propertyName, false);
        }
        else
        {
          if (desc.Value != (JsValue) null && desc.Value != Undefined.Instance)
            parameterMap.Put(propertyName, desc.Value, throwOnError);
          if (desc.Writable.HasValue && !desc.Writable.Value)
            parameterMap.Delete(propertyName, false);
        }
      }
      return true;
    }

    public override bool Delete(string propertyName, bool throwOnError)
    {
      this.EnsureInitialized();
      if (this.Strict || this.ParameterMap == null)
        return base.Delete(propertyName, throwOnError);
      ObjectInstance parameterMap = this.ParameterMap;
      PropertyDescriptor ownProperty = parameterMap.GetOwnProperty(propertyName);
      int num = base.Delete(propertyName, throwOnError) ? 1 : 0;
      if (num == 0)
        return num != 0;
      if (ownProperty == PropertyDescriptor.Undefined)
        return num != 0;
      parameterMap.Delete(propertyName, false);
      return num != 0;
    }
  }
}
