﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.JsValue
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Array;
using Jint.Native.Boolean;
using Jint.Native.Date;
using Jint.Native.Function;
using Jint.Native.Number;
using Jint.Native.Object;
using Jint.Native.RegExp;
using Jint.Native.String;
using Jint.Runtime;
using Jint.Runtime.Descriptors;
using Jint.Runtime.Interop;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Dynamic;
using System.Threading;

#nullable disable
namespace Jint.Native
{
  [DebuggerTypeProxy(typeof (JsValue.JsValueDebugView))]
  public class JsValue : IEquatable<JsValue>
  {
    public static readonly JsValue Undefined = new JsValue(Types.Undefined);
    public static readonly JsValue Null = new JsValue(Types.Null);
    public static readonly JsValue False = new JsValue(false);
    public static readonly JsValue True = new JsValue(true);
    private readonly double _double;
    private readonly object _object;
    private readonly Types _type;

    public JsValue(bool value)
    {
      this._double = value ? 1.0 : 0.0;
      this._object = (object) null;
      this._type = Types.Boolean;
    }

    public JsValue(double value)
    {
      this._object = (object) null;
      this._type = Types.Number;
      this._double = value;
    }

    public JsValue(string value)
    {
      this._double = double.NaN;
      this._object = (object) value;
      this._type = Types.String;
    }

    public JsValue(ObjectInstance value)
    {
      this._double = double.NaN;
      this._type = Types.Object;
      this._object = (object) value;
    }

    private JsValue(Types type)
    {
      this._double = double.NaN;
      this._object = (object) null;
      this._type = type;
    }

    public bool IsPrimitive() => this._type != Types.Object && this._type != 0;

    public bool IsUndefined() => this._type == Types.Undefined;

    public bool IsArray() => this.IsObject() && this.AsObject() is ArrayInstance;

    public bool IsDate() => this.IsObject() && this.AsObject() is DateInstance;

    public bool IsRegExp() => this.IsObject() && this.AsObject() is RegExpInstance;

    public bool IsObject() => this._type == Types.Object;

    public bool IsString() => this._type == Types.String;

    public bool IsNumber() => this._type == Types.Number;

    public bool IsBoolean() => this._type == Types.Boolean;

    public bool IsNull() => this._type == Types.Null;

    public ObjectInstance AsObject()
    {
      if (this._type != Types.Object)
        throw new ArgumentException("The value is not an object");
      return this._object as ObjectInstance;
    }

    public ArrayInstance AsArray()
    {
      if (!this.IsArray())
        throw new ArgumentException("The value is not an array");
      return this._object as ArrayInstance;
    }

    public DateInstance AsDate()
    {
      if (!this.IsDate())
        throw new ArgumentException("The value is not a date");
      return this._object as DateInstance;
    }

    public RegExpInstance AsRegExp()
    {
      if (!this.IsRegExp())
        throw new ArgumentException("The value is not a date");
      return this._object as RegExpInstance;
    }

    public T TryCast<T>(Action<JsValue> fail = null) where T : class
    {
      if (this.IsObject() && this.AsObject() is T obj)
        return obj;
      if (fail != null)
        fail(this);
      return default (T);
    }

    public bool Is<T>() => this.IsObject() && this.AsObject() is T;

    public T As<T>() where T : ObjectInstance => this._object as T;

    public bool AsBoolean()
    {
      if (this._type != Types.Boolean)
        throw new ArgumentException("The value is not a boolean");
      return this._double != 0.0;
    }

    public string AsString()
    {
      if (this._type != Types.String)
        throw new ArgumentException("The value is not a string");
      return this._object != null ? this._object as string : throw new ArgumentException("The value is not defined");
    }

    public double AsNumber()
    {
      if (this._type != Types.Number)
        throw new ArgumentException("The value is not a number");
      return this._double;
    }

    public bool Equals(JsValue other)
    {
      if (other == (JsValue) null)
        return false;
      if ((object) this == (object) other)
        return true;
      if (this._type != other._type)
        return false;
      switch (this._type)
      {
        case Types.None:
          return false;
        case Types.Undefined:
          return true;
        case Types.Null:
          return true;
        case Types.Boolean:
        case Types.Number:
          return this._double == other._double;
        case Types.String:
        case Types.Object:
          return this._object == other._object;
        default:
          throw new ArgumentOutOfRangeException();
      }
    }

    public Types Type => this._type;

    public static JsValue FromObject(Engine engine, object value)
    {
      if (value == null)
        return JsValue.Null;
      foreach (IObjectConverter objectConverter in engine.Options._ObjectConverters)
      {
        JsValue result;
        if (objectConverter.TryConvert(value, out result))
          return result;
      }
      System.Type type1 = value.GetType();
      Dictionary<System.Type, Func<Engine, object, JsValue>> typeMappers = Engine.TypeMappers;
      Func<Engine, object, JsValue> func1;
      if (typeMappers.TryGetValue(type1, out func1))
        return func1(engine, value);
      if (value is ObjectInstance objectInstance)
      {
        ref Dictionary<System.Type, Func<Engine, object, JsValue>> local = ref Engine.TypeMappers;
        Dictionary<System.Type, Func<Engine, object, JsValue>> dictionary = new Dictionary<System.Type, Func<Engine, object, JsValue>>((IDictionary<System.Type, Func<Engine, object, JsValue>>) typeMappers);
        dictionary[type1] = (Func<Engine, object, JsValue>) ((e, v) => new JsValue((ObjectInstance) v));
        Dictionary<System.Type, Func<Engine, object, JsValue>> comparand = typeMappers;
        Interlocked.CompareExchange<Dictionary<System.Type, Func<Engine, object, JsValue>>>(ref local, dictionary, comparand);
        return new JsValue(objectInstance);
      }
      System.Type type2 = value as System.Type;
      if (type2 != (System.Type) null)
        return new JsValue((ObjectInstance) TypeReference.CreateTypeReference(engine, type2));
      if (value is System.Array array1)
      {
        Func<Engine, object, JsValue> func2 = (Func<Engine, object, JsValue>) ((e, v) =>
        {
          System.Array array = (System.Array) v;
          ObjectInstance thisObject = engine.Array.Construct(Arguments.Empty);
          foreach (object obj in array)
          {
            JsValue jsValue = JsValue.FromObject(engine, obj);
            engine.Array.PrototypeObject.Push((JsValue) thisObject, Arguments.From(jsValue));
          }
          return (JsValue) thisObject;
        });
        ref Dictionary<System.Type, Func<Engine, object, JsValue>> local = ref Engine.TypeMappers;
        Dictionary<System.Type, Func<Engine, object, JsValue>> dictionary = new Dictionary<System.Type, Func<Engine, object, JsValue>>((IDictionary<System.Type, Func<Engine, object, JsValue>>) typeMappers);
        dictionary[type1] = func2;
        Dictionary<System.Type, Func<Engine, object, JsValue>> comparand = typeMappers;
        Interlocked.CompareExchange<Dictionary<System.Type, Func<Engine, object, JsValue>>>(ref local, dictionary, comparand);
        return func2(engine, (object) array1);
      }
      if (value is Delegate d)
        return (JsValue) (ObjectInstance) new DelegateWrapper(engine, d);
      return value.GetType().IsEnum() ? new JsValue((double) (int) value) : (JsValue) (ObjectInstance) new ObjectWrapper(engine, value);
    }

    public object ToObject()
    {
      switch (this._type)
      {
        case Types.None:
        case Types.Undefined:
        case Types.Null:
          return (object) null;
        case Types.Boolean:
          return (object) (this._double != 0.0);
        case Types.String:
          return this._object;
        case Types.Number:
          return (object) this._double;
        case Types.Object:
          if (this._object is IObjectWrapper objectWrapper)
            return objectWrapper.Target;
          switch ((this._object as ObjectInstance).Class)
          {
            case "Arguments":
            case "Object":
              IDictionary<string, object> dictionary = (IDictionary<string, object>) new ExpandoObject();
              foreach (KeyValuePair<string, PropertyDescriptor> ownProperty in (this._object as ObjectInstance).GetOwnProperties())
              {
                bool? enumerable = ownProperty.Value.Enumerable;
                if (enumerable.HasValue)
                {
                  enumerable = ownProperty.Value.Enumerable;
                  if (enumerable.Value)
                    dictionary.Add(ownProperty.Key, (this._object as ObjectInstance).Get(ownProperty.Key).ToObject());
                }
              }
              return (object) dictionary;
            case "Array":
              if (this._object is ArrayInstance arrayInstance)
              {
                int int32 = TypeConverter.ToInt32(arrayInstance.Get("length"));
                object[] objArray = new object[int32];
                for (int index = 0; index < int32; ++index)
                {
                  string propertyName = index.ToString();
                  if (arrayInstance.HasProperty(propertyName))
                  {
                    JsValue jsValue = arrayInstance.Get(propertyName);
                    objArray[index] = jsValue.ToObject();
                  }
                  else
                    objArray[index] = (object) null;
                }
                return (object) objArray;
              }
              break;
            case "Boolean":
              if (this._object is BooleanInstance booleanInstance)
                return (object) booleanInstance.PrimitiveValue.AsBoolean();
              break;
            case "Date":
              if (this._object is DateInstance dateInstance)
                return (object) dateInstance.ToDateTime();
              break;
            case "Function":
              if (this._object is FunctionInstance functionInstance)
                return (object) new Func<JsValue, JsValue[], JsValue>(functionInstance.Call);
              break;
            case "Number":
              if (this._object is NumberInstance numberInstance)
                return (object) numberInstance.PrimitiveValue.AsNumber();
              break;
            case "RegExp":
              if (this._object is RegExpInstance regExpInstance)
                return (object) regExpInstance.Value;
              break;
            case "String":
              if (this._object is StringInstance stringInstance)
                return (object) stringInstance.PrimitiveValue.AsString();
              break;
          }
          return this._object;
        default:
          throw new ArgumentOutOfRangeException();
      }
    }

    public JsValue Invoke(params JsValue[] arguments) => this.Invoke(JsValue.Undefined, arguments);

    public JsValue Invoke(JsValue thisObj, JsValue[] arguments)
    {
      return (this.TryCast<ICallable>() ?? throw new ArgumentException("Can only invoke functions")).Call(thisObj, arguments);
    }

    public override string ToString()
    {
      switch (this.Type)
      {
        case Types.None:
          return "None";
        case Types.Undefined:
          return "undefined";
        case Types.Null:
          return "null";
        case Types.Boolean:
          return this._double == 0.0 ? bool.FalseString : bool.TrueString;
        case Types.String:
        case Types.Object:
          return this._object.ToString();
        case Types.Number:
          return this._double.ToString();
        default:
          return string.Empty;
      }
    }

    public static bool operator ==(JsValue a, JsValue b)
    {
      if ((object) a != null)
        return a.Equals(b);
      return (object) b == null;
    }

    public static bool operator !=(JsValue a, JsValue b)
    {
      if ((object) a != null)
        return !a.Equals(b);
      return (object) b != null;
    }

    public static implicit operator JsValue(double value) => new JsValue(value);

    public static implicit operator JsValue(bool value) => new JsValue(value);

    public static implicit operator JsValue(string value) => new JsValue(value);

    public static implicit operator JsValue(ObjectInstance value) => new JsValue(value);

    public override bool Equals(object obj)
    {
      return obj != null && (object) (obj as JsValue) != null && this.Equals((JsValue) obj);
    }

    public override int GetHashCode()
    {
      return (int) ((Types) (((0 * 397 ^ this._double.GetHashCode()) * 397 ^ (this._object != null ? this._object.GetHashCode() : 0)) * 397) ^ this._type);
    }

    internal class JsValueDebugView
    {
      public string Value;

      public JsValueDebugView(JsValue value)
      {
        switch (value.Type)
        {
          case Types.None:
            this.Value = "None";
            break;
          case Types.Undefined:
            this.Value = "undefined";
            break;
          case Types.Null:
            this.Value = "null";
            break;
          case Types.Boolean:
            this.Value = value.AsBoolean().ToString() + " (bool)";
            break;
          case Types.String:
            this.Value = value.AsString() + " (string)";
            break;
          case Types.Number:
            this.Value = value.AsNumber().ToString() + " (number)";
            break;
          case Types.Object:
            this.Value = value.AsObject().GetType().Name;
            break;
          default:
            this.Value = "Unknown";
            break;
        }
      }
    }
  }
}
