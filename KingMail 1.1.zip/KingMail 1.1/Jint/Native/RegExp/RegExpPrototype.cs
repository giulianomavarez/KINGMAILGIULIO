﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.RegExp.RegExpPrototype
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Descriptors;
using Jint.Runtime.Interop;
using System;
using System.Text.RegularExpressions;

#nullable disable
namespace Jint.Native.RegExp
{
  public sealed class RegExpPrototype : RegExpInstance
  {
    private RegExpPrototype(Engine engine)
      : base(engine)
    {
    }

    public static RegExpPrototype CreatePrototypeObject(
      Engine engine,
      RegExpConstructor regExpConstructor)
    {
      RegExpPrototype prototypeObject = new RegExpPrototype(engine);
      prototypeObject.Prototype = (ObjectInstance) engine.Object.PrototypeObject;
      prototypeObject.Extensible = true;
      prototypeObject.FastAddProperty("constructor", (JsValue) (ObjectInstance) regExpConstructor, true, false, true);
      return prototypeObject;
    }

    public void Configure()
    {
      this.FastAddProperty("toString", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToRegExpString)), true, false, true);
      this.FastAddProperty("exec", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Exec), 1), true, false, true);
      this.FastAddProperty("test", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Test), 1), true, false, true);
      this.FastAddProperty("global", (JsValue) false, false, false, false);
      this.FastAddProperty("ignoreCase", (JsValue) false, false, false, false);
      this.FastAddProperty("multiline", (JsValue) false, false, false, false);
      this.FastAddProperty("source", (JsValue) "(?:)", false, false, false);
      this.FastAddProperty("lastIndex", (JsValue) 0.0, true, false, false);
    }

    private JsValue ToRegExpString(JsValue thisObj, JsValue[] arguments)
    {
      RegExpInstance regExpInstance = thisObj.TryCast<RegExpInstance>();
      return (JsValue) ("/" + regExpInstance.Source + "/" + (regExpInstance.Flags.Contains("g") ? "g" : "") + (regExpInstance.Flags.Contains("i") ? "i" : "") + (regExpInstance.Flags.Contains("m") ? "m" : ""));
    }

    private JsValue Test(JsValue thisObj, JsValue[] arguments)
    {
      ObjectInstance thisObj1 = TypeConverter.ToObject(this.Engine, thisObj);
      if (thisObj1.Class != "RegExp")
        throw new JavaScriptException(this.Engine.TypeError);
      return (JsValue) (this.Exec((JsValue) thisObj1, arguments) != Null.Instance);
    }

    internal JsValue Exec(JsValue thisObj, JsValue[] arguments)
    {
      if (!(TypeConverter.ToObject(this.Engine, thisObj) is RegExpInstance regExpInstance))
        throw new JavaScriptException(this.Engine.TypeError);
      string str = TypeConverter.ToString(arguments.At(0));
      int length = str.Length;
      double start = TypeConverter.ToInteger((JsValue) TypeConverter.ToNumber(regExpInstance.Get("lastIndex")));
      bool global = regExpInstance.Global;
      if (!global)
        start = 0.0;
      if (regExpInstance.Source == "(?:)")
      {
        ObjectInstance objectInstance = RegExpPrototype.InitReturnValueArray(this.Engine.Array.Construct(Arguments.Empty), str, 1, 0);
        objectInstance.DefineOwnProperty("0", new PropertyDescriptor((JsValue) "", new bool?(true), new bool?(true), new bool?(true)), true);
        return (JsValue) objectInstance;
      }
      if (start < 0.0 || start > (double) length)
      {
        regExpInstance.Put("lastIndex", (JsValue) 0.0, true);
        return Null.Instance;
      }
      System.Text.RegularExpressions.Match match = regExpInstance.Match(str, start);
      if (!match.Success)
      {
        regExpInstance.Put("lastIndex", (JsValue) 0.0, true);
        return Null.Instance;
      }
      int num = match.Index + match.Length;
      if (global)
        regExpInstance.Put("lastIndex", (JsValue) (double) num, true);
      int count = match.Groups.Count;
      int index = match.Index;
      ObjectInstance objectInstance1 = RegExpPrototype.InitReturnValueArray(this.Engine.Array.Construct(Arguments.Empty), str, count, index);
      for (int groupnum = 0; groupnum < count; ++groupnum)
      {
        Group group = match.Groups[groupnum];
        JsValue jsValue = group.Success ? (JsValue) group.Value : Undefined.Instance;
        objectInstance1.DefineOwnProperty(groupnum.ToString(), new PropertyDescriptor(jsValue, new bool?(true), new bool?(true), new bool?(true)), true);
      }
      return (JsValue) objectInstance1;
    }

    private static ObjectInstance InitReturnValueArray(
      ObjectInstance array,
      string inputValue,
      int lengthValue,
      int indexValue)
    {
      array.DefineOwnProperty("index", new PropertyDescriptor((JsValue) (double) indexValue, new bool?(true), new bool?(true), new bool?(true)), true);
      array.DefineOwnProperty("input", new PropertyDescriptor((JsValue) inputValue, new bool?(true), new bool?(true), new bool?(true)), true);
      array.DefineOwnProperty("length", new PropertyDescriptor((JsValue) (double) lengthValue, new bool?(true), new bool?(false), new bool?(false)), true);
      return array;
    }
  }
}
