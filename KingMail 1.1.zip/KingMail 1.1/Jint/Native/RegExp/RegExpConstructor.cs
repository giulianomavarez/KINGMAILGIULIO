﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.RegExp.RegExpConstructor
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Function;
using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Environments;
using System;
using System.Text.RegularExpressions;

#nullable disable
namespace Jint.Native.RegExp
{
  public sealed class RegExpConstructor(Engine engine) : FunctionInstance(engine, (string[]) null, (LexicalEnvironment) null, false), IConstructor
  {
    public static RegExpConstructor CreateRegExpConstructor(Engine engine)
    {
      RegExpConstructor regExpConstructor = new RegExpConstructor(engine);
      regExpConstructor.Extensible = true;
      regExpConstructor.Prototype = (ObjectInstance) engine.Function.PrototypeObject;
      regExpConstructor.PrototypeObject = RegExpPrototype.CreatePrototypeObject(engine, regExpConstructor);
      regExpConstructor.FastAddProperty("length", (JsValue) 2.0, false, false, false);
      regExpConstructor.FastAddProperty("prototype", (JsValue) (ObjectInstance) regExpConstructor.PrototypeObject, false, false, false);
      return regExpConstructor;
    }

    public void Configure()
    {
    }

    public override JsValue Call(JsValue thisObject, JsValue[] arguments)
    {
      JsValue jsValue1 = arguments.At(0);
      JsValue jsValue2 = arguments.At(1);
      return jsValue1 != Undefined.Instance && jsValue2 == Undefined.Instance && TypeConverter.ToObject(this.Engine, jsValue1).Class == "Regex" ? jsValue1 : (JsValue) this.Construct(arguments);
    }

    public ObjectInstance Construct(JsValue[] arguments)
    {
      JsValue o1 = arguments.At(0);
      JsValue o2 = arguments.At(1);
      RegExpInstance regExpInstance = o1.TryCast<RegExpInstance>();
      if (o2 == Undefined.Instance && regExpInstance != null)
        return (ObjectInstance) regExpInstance;
      if (o2 != Undefined.Instance && regExpInstance != null)
        throw new JavaScriptException(this.Engine.TypeError);
      string pattern = !(o1 == Undefined.Instance) ? TypeConverter.ToString(o1) : "";
      string flags = o2 != Undefined.Instance ? TypeConverter.ToString(o2) : "";
      RegExpInstance r = new RegExpInstance(this.Engine);
      r.Prototype = (ObjectInstance) this.PrototypeObject;
      r.Extensible = true;
      RegexOptions options = this.ParseOptions(r, flags);
      try
      {
        r.Value = new Regex(pattern, options);
      }
      catch (Exception ex)
      {
        throw new JavaScriptException(this.Engine.SyntaxError, ex.Message);
      }
      string str = pattern;
      if (string.IsNullOrEmpty(str))
        str = "(?:)";
      r.Flags = flags;
      r.Source = str;
      r.FastAddProperty("global", (JsValue) r.Global, false, false, false);
      r.FastAddProperty("ignoreCase", (JsValue) r.IgnoreCase, false, false, false);
      r.FastAddProperty("multiline", (JsValue) r.Multiline, false, false, false);
      r.FastAddProperty("source", (JsValue) r.Source, false, false, false);
      r.FastAddProperty("lastIndex", (JsValue) 0.0, true, false, false);
      return (ObjectInstance) r;
    }

    public RegExpInstance Construct(string regExp)
    {
      RegExpInstance r = new RegExpInstance(this.Engine);
      r.Prototype = (ObjectInstance) this.PrototypeObject;
      r.Extensible = true;
      int num1 = regExp[0] == '/' ? regExp.LastIndexOf('/') : throw new JavaScriptException(this.Engine.SyntaxError, "Regexp should start with slash");
      string pattern1 = regExp.Substring(1, num1 - 1).Replace("\\/", "/");
      string flags = regExp.Substring(num1 + 1);
      RegexOptions options = this.ParseOptions(r, flags);
      try
      {
        if ((RegexOptions.Multiline & options) == RegexOptions.Multiline)
        {
          int num2 = 0;
          string pattern2 = pattern1;
          while ((num2 = pattern2.IndexOf("$", num2)) != -1)
          {
            if (num2 > 0 && pattern2[num2 - 1] != '\\')
            {
              pattern2 = pattern2.Substring(0, num2) + "\\r?" + pattern2.Substring(num2);
              num2 += 4;
            }
          }
          r.Value = new Regex(pattern2, options);
        }
        else
          r.Value = new Regex(pattern1, options);
      }
      catch (Exception ex)
      {
        throw new JavaScriptException(this.Engine.SyntaxError, ex.Message);
      }
      r.Flags = flags;
      r.Source = string.IsNullOrEmpty(pattern1) ? "(?:)" : pattern1;
      r.FastAddProperty("global", (JsValue) r.Global, false, false, false);
      r.FastAddProperty("ignoreCase", (JsValue) r.IgnoreCase, false, false, false);
      r.FastAddProperty("multiline", (JsValue) r.Multiline, false, false, false);
      r.FastAddProperty("source", (JsValue) r.Source, false, false, false);
      r.FastAddProperty("lastIndex", (JsValue) 0.0, true, false, false);
      return r;
    }

    private RegexOptions ParseOptions(RegExpInstance r, string flags)
    {
      for (int index = 0; index < flags.Length; ++index)
      {
        switch (flags[index])
        {
          case 'g':
            r.Global = !r.Global ? true : throw new JavaScriptException(this.Engine.SyntaxError);
            break;
          case 'i':
            r.IgnoreCase = !r.IgnoreCase ? true : throw new JavaScriptException(this.Engine.SyntaxError);
            break;
          case 'm':
            r.Multiline = !r.Multiline ? true : throw new JavaScriptException(this.Engine.SyntaxError);
            break;
          default:
            throw new JavaScriptException(this.Engine.SyntaxError);
        }
      }
      RegexOptions options = RegexOptions.ECMAScript;
      if (r.Multiline)
        options |= RegexOptions.Multiline;
      if (r.IgnoreCase)
        options |= RegexOptions.IgnoreCase;
      return options;
    }

    public RegExpPrototype PrototypeObject { get; private set; }
  }
}
