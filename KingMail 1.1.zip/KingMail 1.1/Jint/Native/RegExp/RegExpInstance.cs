﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.RegExp.RegExpInstance
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Object;
using System.Text.RegularExpressions;

#nullable disable
namespace Jint.Native.RegExp
{
  public class RegExpInstance(Engine engine) : ObjectInstance(engine)
  {
    public override string Class => "RegExp";

    public Regex Value { get; set; }

    public string Source { get; set; }

    public string Flags { get; set; }

    public bool Global { get; set; }

    public bool IgnoreCase { get; set; }

    public bool Multiline { get; set; }

    public System.Text.RegularExpressions.Match Match(string input, double start)
    {
      return this.Value.Match(input, (int) start);
    }
  }
}
