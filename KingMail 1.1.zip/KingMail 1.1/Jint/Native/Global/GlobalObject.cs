﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Global.GlobalObject
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Object;
using Jint.Native.String;
using Jint.Runtime;
using Jint.Runtime.Interop;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

#nullable disable
namespace Jint.Native.Global
{
  public sealed class GlobalObject : ObjectInstance
  {
    private static readonly char[] UriReserved = new char[10]
    {
      ';',
      '/',
      '?',
      ':',
      '@',
      '&',
      '=',
      '+',
      '$',
      ','
    };
    private static readonly char[] UriUnescaped = new char[71]
    {
      'a',
      'b',
      'c',
      'd',
      'e',
      'f',
      'g',
      'h',
      'i',
      'j',
      'k',
      'l',
      'm',
      'n',
      'o',
      'p',
      'q',
      'r',
      's',
      't',
      'u',
      'v',
      'w',
      'x',
      'y',
      'z',
      'A',
      'B',
      'C',
      'D',
      'E',
      'F',
      'G',
      'H',
      'I',
      'J',
      'K',
      'L',
      'M',
      'N',
      'O',
      'P',
      'Q',
      'R',
      'S',
      'T',
      'U',
      'V',
      'W',
      'X',
      'Y',
      'Z',
      '0',
      '1',
      '2',
      '3',
      '4',
      '5',
      '6',
      '7',
      '8',
      '9',
      '-',
      '_',
      '.',
      '!',
      '~',
      '*',
      '\'',
      '(',
      ')'
    };
    private const string HexaMap = "0123456789ABCDEF";

    private GlobalObject(Engine engine)
      : base(engine)
    {
    }

    public static GlobalObject CreateGlobalObject(Engine engine)
    {
      GlobalObject globalObject = new GlobalObject(engine);
      globalObject.Prototype = (ObjectInstance) null;
      globalObject.Extensible = true;
      return globalObject;
    }

    public void Configure()
    {
      this.Prototype = (ObjectInstance) this.Engine.Object.PrototypeObject;
      this.FastAddProperty("Object", (JsValue) (ObjectInstance) this.Engine.Object, true, false, true);
      this.FastAddProperty("Function", (JsValue) (ObjectInstance) this.Engine.Function, true, false, true);
      this.FastAddProperty("Array", (JsValue) (ObjectInstance) this.Engine.Array, true, false, true);
      this.FastAddProperty("String", (JsValue) (ObjectInstance) this.Engine.String, true, false, true);
      this.FastAddProperty("RegExp", (JsValue) (ObjectInstance) this.Engine.RegExp, true, false, true);
      this.FastAddProperty("Number", (JsValue) (ObjectInstance) this.Engine.Number, true, false, true);
      this.FastAddProperty("Boolean", (JsValue) (ObjectInstance) this.Engine.Boolean, true, false, true);
      this.FastAddProperty("Date", (JsValue) (ObjectInstance) this.Engine.Date, true, false, true);
      this.FastAddProperty("Math", (JsValue) (ObjectInstance) this.Engine.Math, true, false, true);
      this.FastAddProperty("JSON", (JsValue) (ObjectInstance) this.Engine.Json, true, false, true);
      this.FastAddProperty("Error", (JsValue) (ObjectInstance) this.Engine.Error, true, false, true);
      this.FastAddProperty("EvalError", (JsValue) (ObjectInstance) this.Engine.EvalError, true, false, true);
      this.FastAddProperty("RangeError", (JsValue) (ObjectInstance) this.Engine.RangeError, true, false, true);
      this.FastAddProperty("ReferenceError", (JsValue) (ObjectInstance) this.Engine.ReferenceError, true, false, true);
      this.FastAddProperty("SyntaxError", (JsValue) (ObjectInstance) this.Engine.SyntaxError, true, false, true);
      this.FastAddProperty("TypeError", (JsValue) (ObjectInstance) this.Engine.TypeError, true, false, true);
      this.FastAddProperty("URIError", (JsValue) (ObjectInstance) this.Engine.UriError, true, false, true);
      this.FastAddProperty("NaN", (JsValue) double.NaN, false, false, false);
      this.FastAddProperty("Infinity", (JsValue) double.PositiveInfinity, false, false, false);
      this.FastAddProperty("undefined", Undefined.Instance, false, false, false);
      this.FastAddProperty("parseInt", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(GlobalObject.ParseInt), 2), true, false, true);
      this.FastAddProperty("parseFloat", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(GlobalObject.ParseFloat), 1), true, false, true);
      this.FastAddProperty("isNaN", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(GlobalObject.IsNaN), 1), true, false, true);
      this.FastAddProperty("isFinite", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(GlobalObject.IsFinite), 1), true, false, true);
      this.FastAddProperty("decodeURI", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.DecodeUri), 1), true, false, true);
      this.FastAddProperty("decodeURIComponent", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.DecodeUriComponent), 1), true, false, true);
      this.FastAddProperty("encodeURI", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.EncodeUri), 1), true, false, true);
      this.FastAddProperty("encodeURIComponent", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.EncodeUriComponent), 1), true, false, true);
      this.FastAddProperty("escape", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Escape), 1), true, false, true);
      this.FastAddProperty("unescape", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Unescape), 1), true, false, true);
    }

    public static JsValue ParseInt(JsValue thisObject, JsValue[] arguments)
    {
      string number = StringPrototype.TrimEx(TypeConverter.ToString(arguments.At(0)));
      int num = 1;
      if (!string.IsNullOrEmpty(number))
      {
        if (number[0] == '-')
          num = -1;
        if (number[0] == '-' || number[0] == '+')
          number = number.Substring(1);
      }
      bool flag = true;
      int radix = arguments.Length > 1 ? TypeConverter.ToInt32(arguments[1]) : 0;
      if (radix == 0)
      {
        radix = number.Length >= 2 && number.StartsWith("0x") || number.StartsWith("0X") ? 16 : 10;
      }
      else
      {
        if (radix < 2 || radix > 36)
          return (JsValue) double.NaN;
        if (radix != 16)
          flag = false;
      }
      if (flag && number.Length >= 2 && number.StartsWith("0x") || number.StartsWith("0X"))
        number = number.Substring(2);
      try
      {
        return (JsValue) ((double) num * GlobalObject.Parse(number, radix).AsNumber());
      }
      catch
      {
        return (JsValue) double.NaN;
      }
    }

    private static JsValue Parse(string number, int radix)
    {
      if (number == "")
        return (JsValue) double.NaN;
      double num1 = 0.0;
      double num2 = 1.0;
      for (int index = number.Length - 1; index >= 0; --index)
      {
        double d = double.NaN;
        char ch = number[index];
        if (ch >= '0' && ch <= '9')
          d = (double) ((int) ch - 48);
        else if (ch >= 'a' && ch <= 'z')
          d = (double) ((int) ch - 97 + 10);
        else if (ch >= 'A' && ch <= 'Z')
          d = (double) ((int) ch - 65 + 10);
        if (double.IsNaN(d) || d >= (double) radix)
          return GlobalObject.Parse(number.Substring(0, index), radix);
        num1 += d * num2;
        num2 *= (double) radix;
      }
      return (JsValue) num1;
    }

    public static JsValue ParseFloat(JsValue thisObject, JsValue[] arguments)
    {
      string str = StringPrototype.TrimStartEx(TypeConverter.ToString(arguments.At(0)));
      int num1 = 1;
      if (str.Length > 0)
      {
        if (str[0] == '-')
        {
          num1 = -1;
          str = str.Substring(1);
        }
        else if (str[0] == '+')
          str = str.Substring(1);
      }
      if (str.StartsWith("Infinity"))
        return (JsValue) ((double) num1 * double.PositiveInfinity);
      if (str.StartsWith("NaN"))
        return (JsValue) double.NaN;
      char ch1 = char.MinValue;
      bool flag = true;
      Decimal num2 = 0M;
      int index1;
      for (index1 = 0; index1 < str.Length; ++index1)
      {
        char ch2 = str[index1];
        switch (ch2)
        {
          case '.':
            ++index1;
            ch1 = '.';
            goto label_16;
          case 'E':
          case 'e':
            ++index1;
            ch1 = 'e';
            goto label_16;
          default:
            int num3 = (int) ch2 - 48;
            switch (num3)
            {
              case 0:
              case 1:
              case 2:
              case 3:
              case 4:
              case 5:
              case 6:
              case 7:
              case 8:
              case 9:
                flag = false;
                num2 = num2 * 10M + (Decimal) num3;
                continue;
              default:
                goto label_16;
            }
        }
      }
label_16:
      Decimal num4 = 0.1M;
      if (ch1 == '.')
      {
        for (; index1 < str.Length; ++index1)
        {
          char ch3 = str[index1];
          int num5 = (int) ch3 - 48;
          switch (num5)
          {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
              flag = false;
              num2 += (Decimal) num5 * num4;
              num4 *= 0.1M;
              continue;
            default:
              if (ch3 == 'e' || ch3 == 'E')
              {
                ++index1;
                ch1 = 'e';
                goto label_22;
              }
              else
                goto label_22;
          }
        }
      }
label_22:
      int num6 = 0;
      int num7 = 1;
      if (ch1 == 'e')
      {
        if (index1 < str.Length)
        {
          if (str[index1] == '-')
          {
            num7 = -1;
            ++index1;
          }
          else if (str[index1] == '+')
            ++index1;
        }
        for (; index1 < str.Length; ++index1)
        {
          int num8 = (int) str[index1] - 48;
          switch (num8)
          {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
              num6 = num6 * 10 + num8;
              continue;
            default:
              goto label_31;
          }
        }
      }
label_31:
      if (flag)
        return (JsValue) double.NaN;
      for (int index2 = 1; index2 <= num6; ++index2)
      {
        if (num7 > 0)
          num2 *= 10M;
        else
          num2 /= 10M;
      }
      return (JsValue) (double) ((Decimal) num1 * num2);
    }

    public static JsValue IsNaN(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) double.IsNaN(TypeConverter.ToNumber(arguments.At(0)));
    }

    public static JsValue IsFinite(JsValue thisObject, JsValue[] arguments)
    {
      if (arguments.Length != 1)
        return (JsValue) false;
      double number = TypeConverter.ToNumber(arguments.At(0));
      return double.IsNaN(number) || double.IsInfinity(number) ? (JsValue) false : (JsValue) true;
    }

    private static bool IsValidHexaChar(char c)
    {
      if (c >= '0' && c <= '9' || c >= 'a' && c <= 'f')
        return true;
      return c >= 'A' && c <= 'F';
    }

    public JsValue EncodeUri(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) this.Encode(TypeConverter.ToString(arguments.At(0)), ((IEnumerable<char>) GlobalObject.UriReserved).Concat<char>((IEnumerable<char>) GlobalObject.UriUnescaped).Concat<char>((IEnumerable<char>) new char[1]
      {
        '#'
      }).ToArray<char>());
    }

    public JsValue EncodeUriComponent(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) this.Encode(TypeConverter.ToString(arguments.At(0)), GlobalObject.UriUnescaped);
    }

    private string Encode(string uriString, char[] unescapedUriSet)
    {
      int length = uriString.Length;
      StringBuilder stringBuilder = new StringBuilder(uriString.Length);
      for (int index1 = 0; index1 < length; ++index1)
      {
        char ch1 = uriString[index1];
        if (Array.IndexOf<char>(unescapedUriSet, ch1) != -1)
        {
          stringBuilder.Append(ch1);
        }
        else
        {
          if (ch1 >= '\uDC00' && ch1 <= '\uDBFF')
            throw new JavaScriptException(this.Engine.UriError);
          int num1;
          if (ch1 < '\uD800' || ch1 > '\uDBFF')
          {
            num1 = (int) ch1;
          }
          else
          {
            ++index1;
            int num2 = index1 != length ? (int) uriString[index1] : throw new JavaScriptException(this.Engine.UriError);
            if (num2 < 56320 || num2 > 57343)
              throw new JavaScriptException(this.Engine.UriError);
            num1 = ((int) ch1 - 55296) * 1024 + (num2 - 56320) + 65536;
          }
          byte[] numArray;
          if (num1 >= 0 && num1 <= (int) sbyte.MaxValue)
            numArray = new byte[1]{ (byte) num1 };
          else if (num1 <= 2047)
            numArray = new byte[2]
            {
              (byte) (192 | num1 >> 6),
              (byte) (128 | num1 & 63)
            };
          else if (num1 <= 55295)
          {
            numArray = new byte[3]
            {
              (byte) (224 | num1 >> 12),
              (byte) (128 | num1 >> 6 & 63),
              (byte) (128 | num1 & 63)
            };
          }
          else
          {
            if (num1 <= 57343)
              throw new JavaScriptException(this.Engine.UriError);
            if (num1 <= (int) ushort.MaxValue)
              numArray = new byte[3]
              {
                (byte) (224 | num1 >> 12),
                (byte) (128 | num1 >> 6 & 63),
                (byte) (128 | num1 & 63)
              };
            else
              numArray = new byte[4]
              {
                (byte) (240 | num1 >> 18),
                (byte) (128 | num1 >> 12 & 63),
                (byte) (128 | num1 >> 6 & 63),
                (byte) (128 | num1 & 63)
              };
          }
          for (int index2 = 0; index2 < numArray.Length; ++index2)
          {
            byte num3 = numArray[index2];
            char ch2 = "0123456789ABCDEF"[(int) num3 / 16];
            char ch3 = "0123456789ABCDEF"[(int) num3 % 16];
            stringBuilder.Append('%').Append(ch2).Append(ch3);
          }
        }
      }
      return stringBuilder.ToString();
    }

    public JsValue DecodeUri(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) this.Decode(TypeConverter.ToString(arguments.At(0)), ((IEnumerable<char>) GlobalObject.UriReserved).Concat<char>((IEnumerable<char>) new char[1]
      {
        '#'
      }).ToArray<char>());
    }

    public JsValue DecodeUriComponent(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) this.Decode(TypeConverter.ToString(arguments.At(0)), new char[0]);
    }

    public string Decode(string uriString, char[] reservedSet)
    {
      int length1 = uriString.Length;
      StringBuilder stringBuilder = new StringBuilder(length1);
      for (int index1 = 0; index1 < length1; ++index1)
      {
        char ch1 = uriString[index1];
        if (ch1 != '%')
        {
          stringBuilder.Append(ch1);
        }
        else
        {
          int startIndex = index1;
          if (index1 + 2 >= length1)
            throw new JavaScriptException(this.Engine.UriError);
          byte num1 = GlobalObject.IsValidHexaChar(uriString[index1 + 1]) && GlobalObject.IsValidHexaChar(uriString[index1 + 2]) ? Convert.ToByte(uriString[index1 + 1].ToString() + uriString[index1 + 2].ToString(), 16) : throw new JavaScriptException(this.Engine.UriError);
          index1 += 2;
          if (((int) num1 & 128) == 0)
          {
            char ch2 = (char) num1;
            if (Array.IndexOf<char>(reservedSet, ch2) == -1)
              stringBuilder.Append(ch2);
            else
              stringBuilder.Append(uriString.Substring(startIndex, index1 - startIndex + 1));
          }
          else
          {
            int length2 = 0;
            while (((int) num1 << length2 & 128) != 0)
              ++length2;
            byte[] bytes = length2 != 1 && length2 <= 4 ? new byte[length2] : throw new JavaScriptException(this.Engine.UriError);
            bytes[0] = num1;
            if (index1 + 3 * (length2 - 1) >= length1)
              throw new JavaScriptException(this.Engine.UriError);
            for (int index2 = 1; index2 < length2; ++index2)
            {
              int index3 = index1 + 1;
              if (uriString[index3] != '%')
                throw new JavaScriptException(this.Engine.UriError);
              byte num2 = GlobalObject.IsValidHexaChar(uriString[index3 + 1]) && GlobalObject.IsValidHexaChar(uriString[index3 + 2]) ? Convert.ToByte(uriString[index3 + 1].ToString() + uriString[index3 + 2].ToString(), 16) : throw new JavaScriptException(this.Engine.UriError);
              if (((int) num2 & 192) != 128)
                throw new JavaScriptException(this.Engine.UriError);
              index1 = index3 + 2;
              bytes[index2] = num2;
            }
            stringBuilder.Append(Encoding.UTF8.GetString(bytes, 0, bytes.Length));
          }
        }
      }
      return stringBuilder.ToString();
    }

    public JsValue Escape(JsValue thisObject, JsValue[] arguments)
    {
      string str1 = TypeConverter.ToString(arguments.At(0));
      int length = str1.Length;
      StringBuilder stringBuilder1 = new StringBuilder(length);
      for (int index = 0; index < length; ++index)
      {
        char ch = str1[index];
        int num;
        if ("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@*_ + -./".IndexOf(ch) != -1)
          stringBuilder1.Append(ch);
        else if (ch < 'Ā')
        {
          StringBuilder stringBuilder2 = stringBuilder1;
          num = (int) ch;
          string str2 = string.Format("%{0}", (object) num.ToString("X2"));
          stringBuilder2.Append(str2);
        }
        else
        {
          StringBuilder stringBuilder3 = stringBuilder1;
          num = (int) ch;
          string str3 = string.Format("%u{0}", (object) num.ToString("X4"));
          stringBuilder3.Append(str3);
        }
      }
      return (JsValue) stringBuilder1.ToString();
    }

    public JsValue Unescape(JsValue thisObject, JsValue[] arguments)
    {
      string source = TypeConverter.ToString(arguments.At(0));
      int length = source.Length;
      StringBuilder stringBuilder = new StringBuilder(length);
      for (int index = 0; index < length; ++index)
      {
        char ch = source[index];
        if (ch == '%')
        {
          if (index < length - 6 && source[index + 1] == 'u' && source.Skip<char>(index + 2).Take<char>(4).All<char>(new Func<char, bool>(GlobalObject.IsValidHexaChar)))
          {
            ch = (char) int.Parse(string.Join<char>(string.Empty, source.Skip<char>(index + 2).Take<char>(4)), NumberStyles.AllowHexSpecifier);
            index += 5;
          }
          else if (index < length - 3 && source.Skip<char>(index + 1).Take<char>(2).All<char>(new Func<char, bool>(GlobalObject.IsValidHexaChar)))
          {
            ch = (char) int.Parse(string.Join<char>(string.Empty, source.Skip<char>(index + 1).Take<char>(2)), NumberStyles.AllowHexSpecifier);
            index += 2;
          }
        }
        stringBuilder.Append(ch);
      }
      return (JsValue) stringBuilder.ToString();
    }
  }
}
