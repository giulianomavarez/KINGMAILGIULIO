﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Boolean.BooleanConstructor
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Function;
using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Environments;

#nullable disable
namespace Jint.Native.Boolean
{
  public sealed class BooleanConstructor : FunctionInstance, IConstructor
  {
    private BooleanConstructor(Engine engine)
      : base(engine, (string[]) null, (LexicalEnvironment) null, false)
    {
    }

    public static BooleanConstructor CreateBooleanConstructor(Engine engine)
    {
      BooleanConstructor booleanConstructor = new BooleanConstructor(engine);
      booleanConstructor.Extensible = true;
      booleanConstructor.Prototype = (ObjectInstance) engine.Function.PrototypeObject;
      booleanConstructor.PrototypeObject = BooleanPrototype.CreatePrototypeObject(engine, booleanConstructor);
      booleanConstructor.FastAddProperty("length", (JsValue) 1.0, false, false, false);
      booleanConstructor.FastAddProperty("prototype", (JsValue) (ObjectInstance) booleanConstructor.PrototypeObject, false, false, false);
      return booleanConstructor;
    }

    public void Configure()
    {
    }

    public override JsValue Call(JsValue thisObject, JsValue[] arguments)
    {
      return arguments.Length == 0 ? (JsValue) false : (JsValue) TypeConverter.ToBoolean(arguments[0]);
    }

    public ObjectInstance Construct(JsValue[] arguments)
    {
      return (ObjectInstance) this.Construct(TypeConverter.ToBoolean(arguments.At(0)));
    }

    public BooleanPrototype PrototypeObject { get; private set; }

    public BooleanInstance Construct(bool value)
    {
      BooleanInstance booleanInstance = new BooleanInstance(this.Engine);
      booleanInstance.Prototype = (ObjectInstance) this.PrototypeObject;
      booleanInstance.PrimitiveValue = (JsValue) value;
      booleanInstance.Extensible = true;
      return booleanInstance;
    }
  }
}
