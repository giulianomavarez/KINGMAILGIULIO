﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Boolean.BooleanPrototype
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Interop;
using System;

#nullable disable
namespace Jint.Native.Boolean
{
  public sealed class BooleanPrototype : BooleanInstance
  {
    private BooleanPrototype(Engine engine)
      : base(engine)
    {
    }

    public static BooleanPrototype CreatePrototypeObject(
      Engine engine,
      BooleanConstructor booleanConstructor)
    {
      BooleanPrototype prototypeObject = new BooleanPrototype(engine);
      prototypeObject.Prototype = (ObjectInstance) engine.Object.PrototypeObject;
      prototypeObject.PrimitiveValue = (JsValue) false;
      prototypeObject.Extensible = true;
      prototypeObject.FastAddProperty("constructor", (JsValue) (ObjectInstance) booleanConstructor, true, false, true);
      return prototypeObject;
    }

    public void Configure()
    {
      this.FastAddProperty("toString", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToBooleanString)), true, false, true);
      this.FastAddProperty("valueOf", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ValueOf)), true, false, true);
    }

    private JsValue ValueOf(JsValue thisObj, JsValue[] arguments)
    {
      JsValue jsValue = thisObj;
      if (jsValue.IsBoolean())
        return jsValue;
      return (jsValue.TryCast<BooleanInstance>() ?? throw new JavaScriptException(this.Engine.TypeError)).PrimitiveValue;
    }

    private JsValue ToBooleanString(JsValue thisObj, JsValue[] arguments)
    {
      return (JsValue) (this.ValueOf(thisObj, Arguments.Empty).AsBoolean() ? "true" : "false");
    }
  }
}
