﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Function.FunctionPrototype
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Descriptors;
using Jint.Runtime.Environments;
using Jint.Runtime.Interop;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace Jint.Native.Function
{
  public sealed class FunctionPrototype : FunctionInstance
  {
    private FunctionPrototype(Engine engine)
      : base(engine, (string[]) null, (LexicalEnvironment) null, false)
    {
    }

    public static FunctionPrototype CreatePrototypeObject(Engine engine)
    {
      FunctionPrototype prototypeObject = new FunctionPrototype(engine);
      prototypeObject.Extensible = true;
      prototypeObject.Prototype = (ObjectInstance) engine.Object.PrototypeObject;
      prototypeObject.FastAddProperty("length", (JsValue) 0.0, false, false, false);
      return prototypeObject;
    }

    public void Configure()
    {
      this.FastAddProperty("constructor", (JsValue) (ObjectInstance) this.Engine.Function, true, false, true);
      this.FastAddProperty("toString", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToString)), true, false, true);
      this.FastAddProperty("apply", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Apply), 2), true, false, true);
      this.FastAddProperty("call", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.CallImpl), 1), true, false, true);
      this.FastAddProperty("bind", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Bind), 1), true, false, true);
    }

    private JsValue Bind(JsValue thisObj, JsValue[] arguments)
    {
      ICallable callable = thisObj.TryCast<ICallable>((Action<JsValue>) (x =>
      {
        throw new JavaScriptException(this.Engine.TypeError);
      }));
      JsValue jsValue = arguments.At(0);
      BindFunctionInstance functionInstance1 = new BindFunctionInstance(this.Engine);
      functionInstance1.Extensible = true;
      BindFunctionInstance functionInstance2 = functionInstance1;
      functionInstance2.TargetFunction = thisObj;
      functionInstance2.BoundThis = jsValue;
      functionInstance2.BoundArgs = ((IEnumerable<JsValue>) arguments).Skip<JsValue>(1).ToArray<JsValue>();
      functionInstance2.Prototype = (ObjectInstance) this.Engine.Function.PrototypeObject;
      if (callable is FunctionInstance functionInstance3)
      {
        double val1 = TypeConverter.ToNumber(functionInstance3.Get("length")) - (double) (arguments.Length - 1);
        functionInstance2.FastAddProperty("length", (JsValue) Math.Max(val1, 0.0), false, false, false);
      }
      else
        functionInstance2.FastAddProperty("length", (JsValue) 0.0, false, false, false);
      FunctionInstance throwTypeError = this.Engine.Function.ThrowTypeError;
      functionInstance2.DefineOwnProperty("caller", new PropertyDescriptor((JsValue) (ObjectInstance) throwTypeError, (JsValue) (ObjectInstance) throwTypeError, new bool?(false), new bool?(false)), false);
      functionInstance2.DefineOwnProperty(nameof (arguments), new PropertyDescriptor((JsValue) (ObjectInstance) throwTypeError, (JsValue) (ObjectInstance) throwTypeError, new bool?(false), new bool?(false)), false);
      return (JsValue) (ObjectInstance) functionInstance2;
    }

    private JsValue ToString(JsValue thisObj, JsValue[] arguments)
    {
      if (thisObj.TryCast<FunctionInstance>() == null)
        throw new JavaScriptException(this.Engine.TypeError, "Function object expected.");
      return (JsValue) string.Format("function() {{ ... }}");
    }

    public JsValue Apply(JsValue thisObject, JsValue[] arguments)
    {
      ICallable callable = thisObject.TryCast<ICallable>();
      JsValue thisObject1 = arguments.At(0);
      JsValue jsValue1 = arguments.At(1);
      if (callable == null)
        throw new JavaScriptException(this.Engine.TypeError);
      if (jsValue1 == Null.Instance || jsValue1 == Undefined.Instance)
        return callable.Call(thisObject1, Arguments.Empty);
      ObjectInstance objectInstance = jsValue1.TryCast<ObjectInstance>();
      uint num = objectInstance != null ? TypeConverter.ToUint32((JsValue) objectInstance.Get("length").AsNumber()) : throw new JavaScriptException(this.Engine.TypeError);
      List<JsValue> jsValueList = new List<JsValue>();
      for (int index = 0; (long) index < (long) num; ++index)
      {
        string propertyName = index.ToString();
        JsValue jsValue2 = objectInstance.Get(propertyName);
        jsValueList.Add(jsValue2);
      }
      return callable.Call(thisObject1, jsValueList.ToArray());
    }

    public JsValue CallImpl(JsValue thisObject, JsValue[] arguments)
    {
      return (thisObject.TryCast<ICallable>() ?? throw new JavaScriptException(this.Engine.TypeError)).Call(arguments.At(0), arguments.Length == 0 ? arguments : ((IEnumerable<JsValue>) arguments).Skip<JsValue>(1).ToArray<JsValue>());
    }

    public override JsValue Call(JsValue thisObject, JsValue[] arguments) => Undefined.Instance;
  }
}
