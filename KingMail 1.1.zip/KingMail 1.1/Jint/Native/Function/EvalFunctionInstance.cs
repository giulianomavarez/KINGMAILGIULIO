﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Function.EvalFunctionInstance
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Object;
using Jint.Parser;
using Jint.Parser.Ast;
using Jint.Runtime;
using Jint.Runtime.Environments;

#nullable disable
namespace Jint.Native.Function
{
  public class EvalFunctionInstance : FunctionInstance
  {
    private readonly Engine _engine;

    public EvalFunctionInstance(
      Engine engine,
      string[] parameters,
      LexicalEnvironment scope,
      bool strict)
      : base(engine, parameters, scope, strict)
    {
      this._engine = engine;
      this.Prototype = (ObjectInstance) this.Engine.Function.PrototypeObject;
      this.FastAddProperty("length", (JsValue) 1.0, false, false, false);
    }

    public override JsValue Call(JsValue thisObject, JsValue[] arguments)
    {
      return this.Call(thisObject, arguments, false);
    }

    public JsValue Call(JsValue thisObject, JsValue[] arguments, bool directCall)
    {
      if (arguments.At(0).Type != Types.String)
        return arguments.At(0);
      string code = TypeConverter.ToString(arguments.At(0));
      try
      {
        Program program = new JavaScriptParser(StrictModeScope.IsStrictModeCode).Parse(code);
        using (new StrictModeScope(program.Strict))
        {
          using (new EvalCodeScope())
          {
            LexicalEnvironment lexicalEnvironment = (LexicalEnvironment) null;
            try
            {
              if (!directCall)
                this.Engine.EnterExecutionContext(this.Engine.GlobalEnvironment, this.Engine.GlobalEnvironment, (JsValue) (ObjectInstance) this.Engine.Global);
              if (StrictModeScope.IsStrictModeCode)
              {
                lexicalEnvironment = LexicalEnvironment.NewDeclarativeEnvironment(this.Engine, this.Engine.ExecutionContext.LexicalEnvironment);
                this.Engine.EnterExecutionContext(lexicalEnvironment, lexicalEnvironment, this.Engine.ExecutionContext.ThisBinding);
              }
              this.Engine.DeclarationBindingInstantiation(DeclarationBindingType.EvalCode, program.FunctionDeclarations, program.VariableDeclarations, (FunctionInstance) this, arguments);
              Completion completion = this._engine.ExecuteStatement((Statement) program);
              if (completion.Type == Completion.Throw)
                throw new JavaScriptException(completion.GetValueOrDefault()).SetCallstack(this._engine, completion.Location);
              return completion.GetValueOrDefault();
            }
            finally
            {
              if (lexicalEnvironment != null)
                this.Engine.LeaveExecutionContext();
              if (!directCall)
                this.Engine.LeaveExecutionContext();
            }
          }
        }
      }
      catch (ParserException ex)
      {
        throw new JavaScriptException(this.Engine.SyntaxError);
      }
    }
  }
}
