﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Function.FunctionInstance
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Environments;

#nullable disable
namespace Jint.Native.Function
{
  public abstract class FunctionInstance : ObjectInstance, ICallable
  {
    private readonly Engine _engine;

    protected FunctionInstance(
      Engine engine,
      string[] parameters,
      LexicalEnvironment scope,
      bool strict)
      : base(engine)
    {
      this._engine = engine;
      this.FormalParameters = parameters;
      this.Scope = scope;
      this.Strict = strict;
    }

    public abstract JsValue Call(JsValue thisObject, JsValue[] arguments);

    public LexicalEnvironment Scope { get; private set; }

    public string[] FormalParameters { get; private set; }

    public bool Strict { get; private set; }

    public virtual bool HasInstance(JsValue v)
    {
      ObjectInstance objectInstance1 = v.TryCast<ObjectInstance>();
      if (objectInstance1 == null)
        return false;
      JsValue o = this.Get("prototype");
      ObjectInstance objectInstance2 = o.IsObject() ? o.AsObject() : throw new JavaScriptException(this._engine.TypeError, string.Format("Function has non-object prototype '{0}' in instanceof check", (object) TypeConverter.ToString(o)));
      if (objectInstance2 == null)
        throw new JavaScriptException(this._engine.TypeError);
      do
      {
        objectInstance1 = objectInstance1.Prototype;
        if (objectInstance1 == null)
          return false;
      }
      while (objectInstance1 != objectInstance2);
      return true;
    }

    public override string Class => "Function";

    public override JsValue Get(string propertyName)
    {
      JsValue jsValue = base.Get(propertyName);
      FunctionInstance functionInstance = jsValue.As<FunctionInstance>();
      if (!(propertyName == "caller") || functionInstance == null || !functionInstance.Strict)
        return jsValue;
      throw new JavaScriptException(this._engine.TypeError);
    }
  }
}
