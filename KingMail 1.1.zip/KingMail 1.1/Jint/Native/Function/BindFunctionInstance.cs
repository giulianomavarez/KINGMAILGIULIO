﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Function.BindFunctionInstance
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Environments;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace Jint.Native.Function
{
  public class BindFunctionInstance(Engine engine) : FunctionInstance(engine, new string[0], (LexicalEnvironment) null, false), IConstructor
  {
    public JsValue TargetFunction { get; set; }

    public JsValue BoundThis { get; set; }

    public JsValue[] BoundArgs { get; set; }

    public override JsValue Call(JsValue thisObject, JsValue[] arguments)
    {
      return this.TargetFunction.TryCast<FunctionInstance>((Action<JsValue>) (x =>
      {
        throw new JavaScriptException(this.Engine.TypeError);
      })).Call(this.BoundThis, ((IEnumerable<JsValue>) this.BoundArgs).Union<JsValue>((IEnumerable<JsValue>) arguments).ToArray<JsValue>());
    }

    public ObjectInstance Construct(JsValue[] arguments)
    {
      return this.TargetFunction.TryCast<IConstructor>((Action<JsValue>) (x =>
      {
        throw new JavaScriptException(this.Engine.TypeError);
      })).Construct(((IEnumerable<JsValue>) this.BoundArgs).Union<JsValue>((IEnumerable<JsValue>) arguments).ToArray<JsValue>());
    }

    public override bool HasInstance(JsValue v)
    {
      return this.TargetFunction.TryCast<FunctionInstance>((Action<JsValue>) (x =>
      {
        throw new JavaScriptException(this.Engine.TypeError);
      })).HasInstance(v);
    }
  }
}
