﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Function.FunctionConstructor
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Object;
using Jint.Native.String;
using Jint.Parser;
using Jint.Parser.Ast;
using Jint.Runtime;
using Jint.Runtime.Environments;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace Jint.Native.Function
{
  public sealed class FunctionConstructor : FunctionInstance, IConstructor
  {
    private FunctionInstance _throwTypeError;

    private FunctionConstructor(Engine engine)
      : base(engine, (string[]) null, (LexicalEnvironment) null, false)
    {
    }

    public static FunctionConstructor CreateFunctionConstructor(Engine engine)
    {
      FunctionConstructor functionConstructor = new FunctionConstructor(engine);
      functionConstructor.Extensible = true;
      functionConstructor.PrototypeObject = FunctionPrototype.CreatePrototypeObject(engine);
      functionConstructor.Prototype = (ObjectInstance) functionConstructor.PrototypeObject;
      functionConstructor.FastAddProperty("prototype", (JsValue) (ObjectInstance) functionConstructor.PrototypeObject, false, false, false);
      functionConstructor.FastAddProperty("length", (JsValue) 1.0, false, false, false);
      return functionConstructor;
    }

    public void Configure()
    {
    }

    public FunctionPrototype PrototypeObject { get; private set; }

    public override JsValue Call(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) this.Construct(arguments);
    }

    private string[] ParseArgumentNames(string parameterDeclaration)
    {
      string[] strArray = parameterDeclaration.Split(new char[1]
      {
        ','
      }, StringSplitOptions.RemoveEmptyEntries);
      string[] argumentNames = new string[strArray.Length];
      for (int index = 0; index < strArray.Length; ++index)
        argumentNames[index] = StringPrototype.TrimEx(strArray[index]);
      return argumentNames;
    }

    public ObjectInstance Construct(JsValue[] arguments)
    {
      int length = arguments.Length;
      string parameterDeclaration = "";
      string str = "";
      if (length == 1)
        str = TypeConverter.ToString(arguments[0]);
      else if (length > 1)
      {
        parameterDeclaration = TypeConverter.ToString(arguments[0]);
        for (int index = 1; index < length - 1; ++index)
        {
          JsValue o = arguments[index];
          parameterDeclaration = parameterDeclaration + "," + TypeConverter.ToString(o);
        }
        str = TypeConverter.ToString(arguments[length - 1]);
      }
      string[] argumentNames = this.ParseArgumentNames(parameterDeclaration);
      JavaScriptParser javaScriptParser = new JavaScriptParser();
      FunctionExpression functionExpression1;
      try
      {
        string functionExpression2 = "function(" + parameterDeclaration + ") { " + str + "}";
        functionExpression1 = javaScriptParser.ParseFunctionExpression(functionExpression2);
      }
      catch (ParserException ex)
      {
        throw new JavaScriptException(this.Engine.SyntaxError);
      }
      Engine engine = this.Engine;
      FunctionDeclaration functionDeclaration1 = new FunctionDeclaration();
      functionDeclaration1.Type = SyntaxNodes.FunctionDeclaration;
      FunctionDeclaration functionDeclaration2 = functionDeclaration1;
      BlockStatement blockStatement1 = new BlockStatement();
      blockStatement1.Type = SyntaxNodes.BlockStatement;
      blockStatement1.Body = (IEnumerable<Statement>) new Statement[1]
      {
        functionExpression1.Body
      };
      BlockStatement blockStatement2 = blockStatement1;
      functionDeclaration2.Body = (Statement) blockStatement2;
      functionDeclaration1.Parameters = (IEnumerable<Identifier>) ((IEnumerable<string>) argumentNames).Select<string, Identifier>((Func<string, Identifier>) (x =>
      {
        return new Identifier()
        {
          Type = SyntaxNodes.Identifier,
          Name = x
        };
      })).ToArray<Identifier>();
      functionDeclaration1.FunctionDeclarations = functionExpression1.FunctionDeclarations;
      functionDeclaration1.VariableDeclarations = functionExpression1.VariableDeclarations;
      FunctionDeclaration functionDeclaration3 = functionDeclaration1;
      LexicalEnvironment scope = LexicalEnvironment.NewDeclarativeEnvironment(this.Engine, this.Engine.ExecutionContext.LexicalEnvironment);
      int num = functionExpression1.Strict ? 1 : 0;
      ScriptFunctionInstance functionInstance = new ScriptFunctionInstance(engine, (IFunctionDeclaration) functionDeclaration3, scope, num != 0);
      functionInstance.Extensible = true;
      return (ObjectInstance) functionInstance;
    }

    public FunctionInstance CreateFunctionObject(FunctionDeclaration functionDeclaration)
    {
      ScriptFunctionInstance functionObject = new ScriptFunctionInstance(this.Engine, (IFunctionDeclaration) functionDeclaration, LexicalEnvironment.NewDeclarativeEnvironment(this.Engine, this.Engine.ExecutionContext.LexicalEnvironment), functionDeclaration.Strict);
      functionObject.Extensible = true;
      return (FunctionInstance) functionObject;
    }

    public FunctionInstance ThrowTypeError
    {
      get
      {
        if (this._throwTypeError != null)
          return this._throwTypeError;
        this._throwTypeError = (FunctionInstance) new Jint.Native.Function.ThrowTypeError(this.Engine);
        return this._throwTypeError;
      }
    }

    public object Apply(JsValue thisObject, JsValue[] arguments)
    {
      if (arguments.Length != 2)
        throw new ArgumentException("Apply has to be called with two arguments.");
      ICallable callable = thisObject.TryCast<ICallable>();
      JsValue thisObject1 = arguments[0];
      JsValue jsValue1 = arguments[1];
      if (callable == null)
        throw new JavaScriptException(this.Engine.TypeError);
      if (jsValue1 == Null.Instance || jsValue1 == Undefined.Instance)
        return (object) callable.Call(thisObject1, Arguments.Empty);
      ObjectInstance objectInstance = jsValue1.TryCast<ObjectInstance>();
      uint num = objectInstance != null ? TypeConverter.ToUint32(objectInstance.Get("length")) : throw new JavaScriptException(this.Engine.TypeError);
      List<JsValue> jsValueList = new List<JsValue>();
      for (int index = 0; (long) index < (long) num; ++index)
      {
        string propertyName = index.ToString();
        JsValue jsValue2 = objectInstance.Get(propertyName);
        jsValueList.Add(jsValue2);
      }
      return (object) callable.Call(thisObject1, jsValueList.ToArray());
    }
  }
}
