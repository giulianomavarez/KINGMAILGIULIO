﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Function.ScriptFunctionInstance
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Object;
using Jint.Parser;
using Jint.Parser.Ast;
using Jint.Runtime;
using Jint.Runtime.Descriptors;
using Jint.Runtime.Environments;
using System;
using System.Linq;

#nullable disable
namespace Jint.Native.Function
{
  public sealed class ScriptFunctionInstance : FunctionInstance, IConstructor
  {
    private readonly IFunctionDeclaration _functionDeclaration;

    public ScriptFunctionInstance(
      Engine engine,
      IFunctionDeclaration functionDeclaration,
      LexicalEnvironment scope,
      bool strict)
      : base(engine, functionDeclaration.Parameters.Select<Identifier, string>((Func<Identifier, string>) (x => x.Name)).ToArray<string>(), scope, strict)
    {
      this._functionDeclaration = functionDeclaration;
      this.Engine = engine;
      this.Extensible = true;
      this.Prototype = (ObjectInstance) engine.Function.PrototypeObject;
      this.DefineOwnProperty("length", new PropertyDescriptor(new JsValue((double) this.FormalParameters.Length), new bool?(false), new bool?(false), new bool?(false)), false);
      ObjectInstance objectInstance = engine.Object.Construct(Arguments.Empty);
      objectInstance.DefineOwnProperty("constructor", new PropertyDescriptor((JsValue) (ObjectInstance) this, new bool?(true), new bool?(false), new bool?(true)), false);
      this.DefineOwnProperty("prototype", new PropertyDescriptor((JsValue) objectInstance, new bool?(true), new bool?(false), new bool?(false)), false);
      if (this._functionDeclaration.Id != null)
        this.DefineOwnProperty("name", new PropertyDescriptor((JsValue) this._functionDeclaration.Id.Name, new bool?(), new bool?(), new bool?()), false);
      if (!strict)
        return;
      FunctionInstance throwTypeError = engine.Function.ThrowTypeError;
      this.DefineOwnProperty("caller", new PropertyDescriptor((JsValue) (ObjectInstance) throwTypeError, (JsValue) (ObjectInstance) throwTypeError, new bool?(false), new bool?(false)), false);
      this.DefineOwnProperty("arguments", new PropertyDescriptor((JsValue) (ObjectInstance) throwTypeError, (JsValue) (ObjectInstance) throwTypeError, new bool?(false), new bool?(false)), false);
    }

    public override JsValue Call(JsValue thisArg, JsValue[] arguments)
    {
      using (new StrictModeScope(this.Strict, true))
      {
        JsValue thisBinding = !StrictModeScope.IsStrictModeCode ? (thisArg == Undefined.Instance || thisArg == Null.Instance ? (JsValue) (ObjectInstance) this.Engine.Global : (thisArg.IsObject() ? thisArg : (JsValue) TypeConverter.ToObject(this.Engine, thisArg))) : thisArg;
        LexicalEnvironment lexicalEnvironment = LexicalEnvironment.NewDeclarativeEnvironment(this.Engine, this.Scope);
        this.Engine.EnterExecutionContext(lexicalEnvironment, lexicalEnvironment, thisBinding);
        try
        {
          this.Engine.DeclarationBindingInstantiation(DeclarationBindingType.FunctionCode, this._functionDeclaration.FunctionDeclarations, this._functionDeclaration.VariableDeclarations, (FunctionInstance) this, arguments);
          Completion completion = this.Engine.ExecuteStatement(this._functionDeclaration.Body);
          if (completion.Type == Completion.Throw)
            throw new JavaScriptException(completion.GetValueOrDefault()).SetCallstack(this.Engine, completion.Location);
          if (completion.Type == Completion.Return)
            return completion.GetValueOrDefault();
        }
        finally
        {
          this.Engine.LeaveExecutionContext();
        }
        return Undefined.Instance;
      }
    }

    public ObjectInstance Construct(JsValue[] arguments)
    {
      ObjectInstance objectInstance = this.Get("prototype").TryCast<ObjectInstance>();
      ObjectInstance thisObject = new ObjectInstance(this.Engine);
      thisObject.Extensible = true;
      thisObject.Prototype = objectInstance ?? (ObjectInstance) this.Engine.Object.PrototypeObject;
      return this.Call((JsValue) thisObject, arguments).TryCast<ObjectInstance>() ?? thisObject;
    }

    public ObjectInstance PrototypeObject { get; private set; }
  }
}
