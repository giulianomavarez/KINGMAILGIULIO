﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Function.ThrowTypeError
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Runtime;
using Jint.Runtime.Descriptors;

#nullable disable
namespace Jint.Native.Function
{
  public sealed class ThrowTypeError : FunctionInstance
  {
    private readonly Engine _engine;

    public ThrowTypeError(Engine engine)
      : base(engine, new string[0], engine.GlobalEnvironment, false)
    {
      this._engine = engine;
      this.DefineOwnProperty("length", new PropertyDescriptor((JsValue) 0.0, new bool?(false), new bool?(false), new bool?(false)), false);
      this.Extensible = false;
    }

    public override JsValue Call(JsValue thisObject, JsValue[] arguments)
    {
      throw new JavaScriptException(this._engine.TypeError);
    }
  }
}
