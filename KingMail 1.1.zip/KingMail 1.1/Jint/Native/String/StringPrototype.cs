﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.String.StringPrototype
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Array;
using Jint.Native.Function;
using Jint.Native.Object;
using Jint.Native.RegExp;
using Jint.Runtime;
using Jint.Runtime.Descriptors;
using Jint.Runtime.Interop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

#nullable disable
namespace Jint.Native.String
{
  public sealed class StringPrototype : StringInstance
  {
    private const char BOM_CHAR = '\uFEFF';
    private const char MONGOLIAN_VOWEL_SEPARATOR = '\u180E';

    private StringPrototype(Engine engine)
      : base(engine)
    {
    }

    public static StringPrototype CreatePrototypeObject(
      Engine engine,
      StringConstructor stringConstructor)
    {
      StringPrototype prototypeObject = new StringPrototype(engine);
      prototypeObject.Prototype = (ObjectInstance) engine.Object.PrototypeObject;
      prototypeObject.PrimitiveValue = (JsValue) "";
      prototypeObject.Extensible = true;
      prototypeObject.FastAddProperty("length", (JsValue) 0.0, false, false, false);
      prototypeObject.FastAddProperty("constructor", (JsValue) (ObjectInstance) stringConstructor, true, false, true);
      return prototypeObject;
    }

    public void Configure()
    {
      this.FastAddProperty("toString", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToStringString)), true, false, true);
      this.FastAddProperty("valueOf", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ValueOf)), true, false, true);
      this.FastAddProperty("charAt", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.CharAt), 1), true, false, true);
      this.FastAddProperty("charCodeAt", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.CharCodeAt), 1), true, false, true);
      this.FastAddProperty("concat", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Concat), 1), true, false, true);
      this.FastAddProperty("indexOf", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.IndexOf), 1), true, false, true);
      this.FastAddProperty("lastIndexOf", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.LastIndexOf), 1), true, false, true);
      this.FastAddProperty("localeCompare", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.LocaleCompare), 1), true, false, true);
      this.FastAddProperty("match", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Match), 1), true, false, true);
      this.FastAddProperty("replace", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Replace), 2), true, false, true);
      this.FastAddProperty("search", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Search), 1), true, false, true);
      this.FastAddProperty("slice", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Slice), 2), true, false, true);
      this.FastAddProperty("split", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Split), 2), true, false, true);
      this.FastAddProperty("substr", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Substr), 2), true, false, true);
      this.FastAddProperty("substring", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Substring), 2), true, false, true);
      this.FastAddProperty("toLowerCase", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(StringPrototype.ToLowerCase)), true, false, true);
      this.FastAddProperty("toLocaleLowerCase", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(StringPrototype.ToLocaleLowerCase)), true, false, true);
      this.FastAddProperty("toUpperCase", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(StringPrototype.ToUpperCase)), true, false, true);
      this.FastAddProperty("toLocaleUpperCase", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(StringPrototype.ToLocaleUpperCase)), true, false, true);
      this.FastAddProperty("trim", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Trim)), true, false, true);
      this.FastAddProperty("padStart", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.PadStart)), true, false, true);
      this.FastAddProperty("padEnd", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.PadEnd)), true, false, true);
    }

    private JsValue ToStringString(JsValue thisObj, JsValue[] arguments)
    {
      if (!(TypeConverter.ToObject(this.Engine, thisObj) is StringInstance stringInstance))
        throw new JavaScriptException(this.Engine.TypeError);
      return stringInstance.PrimitiveValue;
    }

    private static bool IsWhiteSpaceEx(char c)
    {
      return char.IsWhiteSpace(c) || c == '\uFEFF' || c == '\u180E';
    }

    public static string TrimEndEx(string s)
    {
      if (s.Length == 0)
        return string.Empty;
      int index = s.Length - 1;
      while (index >= 0 && StringPrototype.IsWhiteSpaceEx(s[index]))
        --index;
      return index >= 0 ? s.Substring(0, index + 1) : string.Empty;
    }

    public static string TrimStartEx(string s)
    {
      if (s.Length == 0)
        return string.Empty;
      int num = 0;
      while (num < s.Length && StringPrototype.IsWhiteSpaceEx(s[num]))
        ++num;
      return num >= s.Length ? string.Empty : s.Substring(num);
    }

    public static string TrimEx(string s)
    {
      return StringPrototype.TrimEndEx(StringPrototype.TrimStartEx(s));
    }

    private JsValue Trim(JsValue thisObj, JsValue[] arguments)
    {
      TypeConverter.CheckObjectCoercible(this.Engine, thisObj);
      return (JsValue) StringPrototype.TrimEx(TypeConverter.ToString(thisObj));
    }

    private static JsValue ToLocaleUpperCase(JsValue thisObj, JsValue[] arguments)
    {
      return (JsValue) TypeConverter.ToString(thisObj).ToUpper();
    }

    private static JsValue ToUpperCase(JsValue thisObj, JsValue[] arguments)
    {
      return (JsValue) TypeConverter.ToString(thisObj).ToUpperInvariant();
    }

    private static JsValue ToLocaleLowerCase(JsValue thisObj, JsValue[] arguments)
    {
      return (JsValue) TypeConverter.ToString(thisObj).ToLower();
    }

    private static JsValue ToLowerCase(JsValue thisObj, JsValue[] arguments)
    {
      return (JsValue) TypeConverter.ToString(thisObj).ToLowerInvariant();
    }

    private static int ToIntegerSupportInfinity(JsValue numberVal)
    {
      double integer = TypeConverter.ToInteger(numberVal);
      return !double.IsPositiveInfinity(integer) ? (!double.IsNegativeInfinity(integer) ? (int) integer : int.MinValue) : int.MaxValue;
    }

    private JsValue Substring(JsValue thisObj, JsValue[] arguments)
    {
      TypeConverter.CheckObjectCoercible(this.Engine, thisObj);
      string str = TypeConverter.ToString(thisObj);
      double num1 = TypeConverter.ToNumber(arguments.At(0));
      double num2 = TypeConverter.ToNumber(arguments.At(1));
      if (double.IsNaN(num1) || num1 < 0.0)
        num1 = 0.0;
      if (double.IsNaN(num2) || num2 < 0.0)
        num2 = 0.0;
      int length = str.Length;
      int integerSupportInfinity = StringPrototype.ToIntegerSupportInfinity((JsValue) num1);
      int val1_1 = arguments.At(1) == Undefined.Instance ? length : StringPrototype.ToIntegerSupportInfinity((JsValue) num2);
      int val1_2 = Math.Min(length, Math.Max(integerSupportInfinity, 0));
      int val2 = Math.Min(length, Math.Max(val1_1, 0));
      int startIndex = Math.Min(val1_2, val2);
      int num3 = Math.Max(val1_2, val2);
      return (JsValue) str.Substring(startIndex, num3 - startIndex);
    }

    private JsValue Substr(JsValue thisObj, JsValue[] arguments)
    {
      string str = TypeConverter.ToString(thisObj);
      double integer = TypeConverter.ToInteger(arguments.At(0));
      double val1 = arguments.At(1) == JsValue.Undefined ? double.PositiveInfinity : TypeConverter.ToInteger(arguments.At(1));
      double o1 = integer >= 0.0 ? integer : Math.Max((double) str.Length + integer, 0.0);
      double o2 = Math.Min(Math.Max(val1, 0.0), (double) str.Length - o1);
      return o2 <= 0.0 ? (JsValue) "" : (JsValue) str.Substring(TypeConverter.ToInt32((JsValue) o1), TypeConverter.ToInt32((JsValue) o2));
    }

    private JsValue Split(JsValue thisObj, JsValue[] arguments)
    {
      TypeConverter.CheckObjectCoercible(this.Engine, thisObj);
      string input = TypeConverter.ToString(thisObj);
      JsValue o1 = arguments.At(0);
      JsValue o2 = arguments.At(1);
      ArrayInstance arrayInstance = (ArrayInstance) this.Engine.Array.Construct(Arguments.Empty);
      uint num1 = o2 == Undefined.Instance ? uint.MaxValue : TypeConverter.ToUint32(o2);
      int length = input.Length;
      if (num1 == 0U)
        return (JsValue) (ObjectInstance) arrayInstance;
      if (o1 == Null.Instance)
      {
        o1 = (JsValue) Null.Text;
      }
      else
      {
        if (o1 == Undefined.Instance)
          return (JsValue) this.Engine.Array.Construct(Arguments.From((JsValue) input));
        if (!o1.IsRegExp())
          o1 = (JsValue) TypeConverter.ToString(o1);
      }
      if (TypeConverter.ToObject(this.Engine, o1) is RegExpInstance regExpInstance && regExpInstance.Source != "(?:)")
      {
        System.Text.RegularExpressions.Match match = regExpInstance.Value.Match(input, 0);
        if (!match.Success)
        {
          arrayInstance.DefineOwnProperty("0", new PropertyDescriptor((JsValue) input, new bool?(true), new bool?(true), new bool?(true)), false);
          return (JsValue) (ObjectInstance) arrayInstance;
        }
        int startIndex = 0;
        int num2 = 0;
        while (match.Success && (long) num2 < (long) num1)
        {
          if (match.Length == 0 && (match.Index == 0 || match.Index == length || match.Index == startIndex))
          {
            match = match.NextMatch();
          }
          else
          {
            arrayInstance.DefineOwnProperty(num2++.ToString(), new PropertyDescriptor((JsValue) input.Substring(startIndex, match.Index - startIndex), new bool?(true), new bool?(true), new bool?(true)), false);
            if ((long) num2 >= (long) num1)
              return (JsValue) (ObjectInstance) arrayInstance;
            startIndex = match.Index + match.Length;
            for (int groupnum = 1; groupnum < match.Groups.Count; ++groupnum)
            {
              Group group = match.Groups[groupnum];
              JsValue instance = Undefined.Instance;
              if (group.Captures.Count > 0)
                instance = (JsValue) match.Groups[groupnum].Value;
              arrayInstance.DefineOwnProperty(num2++.ToString(), new PropertyDescriptor(instance, new bool?(true), new bool?(true), new bool?(true)), false);
              if ((long) num2 >= (long) num1)
                return (JsValue) (ObjectInstance) arrayInstance;
            }
            match = match.NextMatch();
            if (!match.Success)
              arrayInstance.DefineOwnProperty(num2++.ToString(), new PropertyDescriptor((JsValue) input.Substring(startIndex), new bool?(true), new bool?(true), new bool?(true)), false);
          }
        }
        return (JsValue) (ObjectInstance) arrayInstance;
      }
      List<string> stringList = new List<string>();
      string str = TypeConverter.ToString(o1);
      if (str == string.Empty || regExpInstance != null && regExpInstance.Source == "(?:)")
      {
        foreach (char ch in input)
          stringList.Add(ch.ToString());
      }
      else
        stringList = ((IEnumerable<string>) input.Split(new string[1]
        {
          str
        }, StringSplitOptions.None)).ToList<string>();
      for (int index = 0; index < stringList.Count && (long) index < (long) num1; ++index)
        arrayInstance.DefineOwnProperty(index.ToString(), new PropertyDescriptor((JsValue) stringList[index], new bool?(true), new bool?(true), new bool?(true)), false);
      return (JsValue) (ObjectInstance) arrayInstance;
    }

    private JsValue Slice(JsValue thisObj, JsValue[] arguments)
    {
      TypeConverter.CheckObjectCoercible(this.Engine, thisObj);
      string str = TypeConverter.ToString(thisObj);
      double o1 = TypeConverter.ToNumber(arguments.At(0));
      if (double.NegativeInfinity.Equals(o1))
        o1 = 0.0;
      if (double.PositiveInfinity.Equals(o1))
        return (JsValue) string.Empty;
      double o2 = TypeConverter.ToNumber(arguments.At(1));
      if (double.PositiveInfinity.Equals(o2))
        o2 = (double) str.Length;
      int length1 = str.Length;
      int integer = (int) TypeConverter.ToInteger((JsValue) o1);
      int val1 = arguments.At(1) == Undefined.Instance ? length1 : (int) TypeConverter.ToInteger((JsValue) o2);
      int startIndex = integer < 0 ? Math.Max(length1 + integer, 0) : Math.Min(integer, length1);
      int length2 = Math.Max((val1 < 0 ? Math.Max(length1 + val1, 0) : Math.Min(val1, length1)) - startIndex, 0);
      return (JsValue) str.Substring(startIndex, length2);
    }

    private JsValue Search(JsValue thisObj, JsValue[] arguments)
    {
      TypeConverter.CheckObjectCoercible(this.Engine, thisObj);
      string input = TypeConverter.ToString(thisObj);
      JsValue jsValue = arguments.At(0);
      if (jsValue.IsUndefined())
        jsValue = (JsValue) string.Empty;
      else if (jsValue.IsNull())
        jsValue = (JsValue) Null.Text;
      if (!(TypeConverter.ToObject(this.Engine, jsValue) is RegExpInstance regExpInstance))
        regExpInstance = (RegExpInstance) this.Engine.RegExp.Construct(new JsValue[1]
        {
          jsValue
        });
      System.Text.RegularExpressions.Match match = regExpInstance.Value.Match(input);
      return !match.Success ? (JsValue) -1.0 : (JsValue) (double) match.Index;
    }

    private JsValue Replace(JsValue thisObj, JsValue[] arguments)
    {
      TypeConverter.CheckObjectCoercible(this.Engine, thisObj);
      string thisString = TypeConverter.ToString(thisObj);
      JsValue o = arguments.At(0);
      JsValue replaceValue = arguments.At(1);
      FunctionInstance replaceFunction = replaceValue.TryCast<FunctionInstance>();
      if (replaceFunction == null)
        replaceFunction = (FunctionInstance) new ClrFunctionInstance(this.Engine, (Func<JsValue, JsValue[], JsValue>) ((self, args) =>
        {
          string str1 = TypeConverter.ToString(replaceValue);
          string str2 = TypeConverter.ToString(args.At(0));
          int integer = (int) TypeConverter.ToInteger(args.At(args.Length - 2));
          if (str1.IndexOf('$') < 0)
            return (JsValue) str1;
          StringBuilder stringBuilder = new StringBuilder();
          for (int index1 = 0; index1 < str1.Length; ++index1)
          {
            char ch1 = str1[index1];
            if (ch1 == '$' && index1 < str1.Length - 1)
            {
              char ch2 = str1[++index1];
              switch (ch2)
              {
                case '$':
                  stringBuilder.Append('$');
                  continue;
                case '&':
                  stringBuilder.Append(str2);
                  continue;
                case '\'':
                  stringBuilder.Append(thisString.Substring(integer + str2.Length));
                  continue;
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                  int index2 = (int) ch2 - 48;
                  int index3 = 0;
                  if (index1 < str1.Length - 1 && str1[index1 + 1] >= '0' && str1[index1 + 1] <= '9')
                    index3 = index2 * 10 + ((int) str1[index1 + 1] - 48);
                  if (index3 > 0 && index3 < args.Length - 2)
                  {
                    stringBuilder.Append(TypeConverter.ToString(args[index3]));
                    ++index1;
                    continue;
                  }
                  if (index2 > 0 && index2 < args.Length - 2)
                  {
                    stringBuilder.Append(TypeConverter.ToString(args[index2]));
                    continue;
                  }
                  stringBuilder.Append('$');
                  --index1;
                  continue;
                case '`':
                  stringBuilder.Append(thisString.Substring(0, integer));
                  continue;
                default:
                  stringBuilder.Append('$');
                  stringBuilder.Append(ch2);
                  continue;
              }
            }
            else
              stringBuilder.Append(ch1);
          }
          return (JsValue) stringBuilder.ToString();
        }));
      if (o.IsNull())
        o = new JsValue(Null.Text);
      if (o.IsUndefined())
        o = new JsValue(Undefined.Text);
      if (TypeConverter.ToObject(this.Engine, o) is RegExpInstance regExpInstance)
        return (JsValue) regExpInstance.Value.Replace(thisString, (MatchEvaluator) (match =>
        {
          List<JsValue> jsValueList = new List<JsValue>();
          for (int groupnum = 0; groupnum < match.Groups.Count; ++groupnum)
          {
            Group group = match.Groups[groupnum];
            jsValueList.Add((JsValue) group.Value);
          }
          jsValueList.Add((JsValue) (double) match.Index);
          jsValueList.Add((JsValue) thisString);
          return TypeConverter.ToString(replaceFunction.Call(Undefined.Instance, jsValueList.ToArray()));
        }), regExpInstance.Global ? -1 : 1);
      string str3 = TypeConverter.ToString(o);
      int count = thisString.IndexOf(str3, StringComparison.Ordinal);
      if (count == -1)
        return (JsValue) thisString;
      int startIndex = count + str3.Length;
      string str4 = TypeConverter.ToString(replaceFunction.Call(Undefined.Instance, new List<JsValue>()
      {
        (JsValue) str3,
        (JsValue) (double) count,
        (JsValue) thisString
      }.ToArray()));
      StringBuilder stringBuilder1 = new StringBuilder(thisString.Length + (str3.Length - str3.Length));
      stringBuilder1.Append(thisString, 0, count);
      stringBuilder1.Append(str4);
      stringBuilder1.Append(thisString, startIndex, thisString.Length - startIndex);
      return (JsValue) stringBuilder1.ToString();
    }

    private JsValue Match(JsValue thisObj, JsValue[] arguments)
    {
      TypeConverter.CheckObjectCoercible(this.Engine, thisObj);
      string str = TypeConverter.ToString(thisObj);
      JsValue jsValue1 = arguments.At(0);
      RegExpInstance regExpInstance = jsValue1.TryCast<RegExpInstance>();
      if (regExpInstance == null)
        regExpInstance = (RegExpInstance) this.Engine.RegExp.Construct(new JsValue[1]
        {
          jsValue1
        });
      RegExpInstance thisObj1 = regExpInstance;
      if (!thisObj1.Get("global").AsBoolean())
        return this.Engine.RegExp.PrototypeObject.Exec((JsValue) (ObjectInstance) thisObj1, Arguments.From((JsValue) str));
      thisObj1.Put("lastIndex", (JsValue) 0.0, false);
      ObjectInstance objectInstance1 = this.Engine.Array.Construct(Arguments.Empty);
      double num1 = 0.0;
      int o = 0;
      bool flag = true;
      while (flag)
      {
        ObjectInstance objectInstance2 = this.Engine.RegExp.PrototypeObject.Exec((JsValue) (ObjectInstance) thisObj1, Arguments.From((JsValue) str)).TryCast<ObjectInstance>();
        if (objectInstance2 == null)
        {
          flag = false;
        }
        else
        {
          double num2 = thisObj1.Get("lastIndex").AsNumber();
          if (num2 == num1)
          {
            thisObj1.Put("lastIndex", (JsValue) (num2 + 1.0), false);
            num1 = num2;
          }
          JsValue jsValue2 = objectInstance2.Get("0");
          objectInstance1.DefineOwnProperty(TypeConverter.ToString((JsValue) (double) o), new PropertyDescriptor(jsValue2, new bool?(true), new bool?(true), new bool?(true)), false);
          ++o;
        }
      }
      return o == 0 ? Null.Instance : (JsValue) objectInstance1;
    }

    private JsValue LocaleCompare(JsValue thisObj, JsValue[] arguments)
    {
      TypeConverter.CheckObjectCoercible(this.Engine, thisObj);
      return (JsValue) (double) string.CompareOrdinal(TypeConverter.ToString(thisObj), TypeConverter.ToString(arguments.At(0)));
    }

    private JsValue LastIndexOf(JsValue thisObj, JsValue[] arguments)
    {
      TypeConverter.CheckObjectCoercible(this.Engine, thisObj);
      string str1 = TypeConverter.ToString(thisObj);
      string str2 = TypeConverter.ToString(arguments.At(0));
      double num1 = double.NaN;
      if (arguments.Length > 1 && arguments[1] != Undefined.Instance)
        num1 = TypeConverter.ToNumber(arguments[1]);
      double val1 = double.IsNaN(num1) ? double.PositiveInfinity : TypeConverter.ToInteger((JsValue) num1);
      int length1 = str1.Length;
      int num2 = (int) Math.Min(Math.Max(val1, 0.0), (double) length1);
      int length2 = str2.Length;
      int num3 = num2;
      bool flag;
      do
      {
        flag = true;
        int index = 0;
        while (flag && index < length2)
        {
          if (num3 + length2 > length1 || (int) str1[num3 + index] != (int) str2[index])
            flag = false;
          else
            ++index;
        }
        if (!flag)
          --num3;
      }
      while (!flag && num3 >= 0);
      return (JsValue) (double) num3;
    }

    private JsValue IndexOf(JsValue thisObj, JsValue[] arguments)
    {
      TypeConverter.CheckObjectCoercible(this.Engine, thisObj);
      string str1 = TypeConverter.ToString(thisObj);
      string str2 = TypeConverter.ToString(arguments.At(0));
      double startIndex = 0.0;
      if (arguments.Length > 1 && arguments[1] != Undefined.Instance)
        startIndex = TypeConverter.ToInteger(arguments[1]);
      if (startIndex >= (double) str1.Length)
        return (JsValue) -1.0;
      if (startIndex < 0.0)
        startIndex = 0.0;
      return (JsValue) (double) str1.IndexOf(str2, (int) startIndex, StringComparison.Ordinal);
    }

    private JsValue Concat(JsValue thisObj, JsValue[] arguments)
    {
      TypeConverter.CheckObjectCoercible(this.Engine, thisObj);
      StringBuilder stringBuilder = new StringBuilder(TypeConverter.ToString(thisObj));
      for (int index = 0; index < arguments.Length; ++index)
        stringBuilder.Append(TypeConverter.ToString(arguments[index]));
      return (JsValue) stringBuilder.ToString();
    }

    private JsValue CharCodeAt(JsValue thisObj, JsValue[] arguments)
    {
      TypeConverter.CheckObjectCoercible(this.Engine, thisObj);
      JsValue o = arguments.Length != 0 ? arguments[0] : (JsValue) 0.0;
      string str = TypeConverter.ToString(thisObj);
      int integer = (int) TypeConverter.ToInteger(o);
      return integer < 0 || integer >= str.Length ? (JsValue) double.NaN : (JsValue) (double) str[integer];
    }

    private JsValue CharAt(JsValue thisObj, JsValue[] arguments)
    {
      TypeConverter.CheckObjectCoercible(this.Engine, thisObj);
      string str = TypeConverter.ToString(thisObj);
      double integer = TypeConverter.ToInteger(arguments.At(0));
      int length = str.Length;
      return integer >= (double) length || integer < 0.0 ? (JsValue) "" : (JsValue) str[(int) integer].ToString();
    }

    private JsValue ValueOf(JsValue thisObj, JsValue[] arguments)
    {
      return (thisObj.TryCast<StringInstance>() ?? throw new JavaScriptException(this.Engine.TypeError)).PrimitiveValue;
    }

    private JsValue PadStart(JsValue thisObj, JsValue[] arguments)
    {
      return this.Pad(thisObj, arguments, true);
    }

    private JsValue PadEnd(JsValue thisObj, JsValue[] arguments)
    {
      return this.Pad(thisObj, arguments, false);
    }

    private JsValue Pad(JsValue thisObj, JsValue[] arguments, bool padStart)
    {
      TypeConverter.CheckObjectCoercible(this.Engine, thisObj);
      int int32 = TypeConverter.ToInt32(arguments.At(0));
      string element = TypeConverter.ToString(arguments.At(1, new JsValue(" ")));
      string str = TypeConverter.ToString(thisObj);
      if (str.Length > int32)
        return (JsValue) str;
      int length = int32 - str.Length;
      if (length > element.Length)
        element = string.Join("", Enumerable.Repeat<string>(element, length / element.Length + 1));
      return (JsValue) (padStart ? string.Format("{0}{1}", (object) element.Substring(0, length), (object) str) : string.Format("{0}{1}", (object) str, (object) element.Substring(0, length)));
    }
  }
}
