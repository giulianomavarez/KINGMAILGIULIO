﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.String.StringConstructor
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Function;
using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Environments;
using Jint.Runtime.Interop;
using System;

#nullable disable
namespace Jint.Native.String
{
  public sealed class StringConstructor(Engine engine) : FunctionInstance(engine, (string[]) null, (LexicalEnvironment) null, false), IConstructor
  {
    public static StringConstructor CreateStringConstructor(Engine engine)
    {
      StringConstructor stringConstructor = new StringConstructor(engine);
      stringConstructor.Extensible = true;
      stringConstructor.Prototype = (ObjectInstance) engine.Function.PrototypeObject;
      stringConstructor.PrototypeObject = StringPrototype.CreatePrototypeObject(engine, stringConstructor);
      stringConstructor.FastAddProperty("length", (JsValue) 1.0, false, false, false);
      stringConstructor.FastAddProperty("prototype", (JsValue) (ObjectInstance) stringConstructor.PrototypeObject, false, false, false);
      return stringConstructor;
    }

    public void Configure()
    {
      this.FastAddProperty("fromCharCode", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(StringConstructor.FromCharCode), 1), true, false, true);
    }

    private static JsValue FromCharCode(JsValue thisObj, JsValue[] arguments)
    {
      char[] chArray = new char[arguments.Length];
      for (int index = 0; index < chArray.Length; ++index)
        chArray[index] = (char) TypeConverter.ToUint16(arguments[index]);
      return (JsValue) new string(chArray);
    }

    public override JsValue Call(JsValue thisObject, JsValue[] arguments)
    {
      return arguments.Length == 0 ? (JsValue) "" : (JsValue) TypeConverter.ToString(arguments[0]);
    }

    public ObjectInstance Construct(JsValue[] arguments)
    {
      return (ObjectInstance) this.Construct(arguments.Length != 0 ? TypeConverter.ToString(arguments[0]) : "");
    }

    public StringPrototype PrototypeObject { get; private set; }

    public StringInstance Construct(string value)
    {
      StringInstance stringInstance = new StringInstance(this.Engine);
      stringInstance.Prototype = (ObjectInstance) this.PrototypeObject;
      stringInstance.PrimitiveValue = (JsValue) value;
      stringInstance.Extensible = true;
      stringInstance.FastAddProperty("length", (JsValue) (double) value.Length, false, false, false);
      return stringInstance;
    }
  }
}
