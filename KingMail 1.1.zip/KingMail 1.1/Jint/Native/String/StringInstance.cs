﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.String.StringInstance
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Descriptors;
using System;

#nullable disable
namespace Jint.Native.String
{
  public class StringInstance(Engine engine) : ObjectInstance(engine), IPrimitiveInstance
  {
    public override string Class => "String";

    Types IPrimitiveInstance.Type => Types.String;

    JsValue IPrimitiveInstance.PrimitiveValue => this.PrimitiveValue;

    public JsValue PrimitiveValue { get; set; }

    private static bool IsInt(double d)
    {
      if (d < (double) long.MinValue || d > (double) long.MaxValue)
        return false;
      long num = (long) d;
      return num >= (long) int.MinValue && num <= (long) int.MaxValue;
    }

    public override PropertyDescriptor GetOwnProperty(string propertyName)
    {
      if (propertyName == "Infinity")
        return PropertyDescriptor.Undefined;
      PropertyDescriptor ownProperty = base.GetOwnProperty(propertyName);
      if (ownProperty != PropertyDescriptor.Undefined)
        return ownProperty;
      if (propertyName != Math.Abs(TypeConverter.ToInteger((JsValue) propertyName)).ToString())
        return PropertyDescriptor.Undefined;
      JsValue primitiveValue = this.PrimitiveValue;
      double integer = TypeConverter.ToInteger((JsValue) propertyName);
      if (!StringInstance.IsInt(integer))
        return PropertyDescriptor.Undefined;
      int index = (int) integer;
      return primitiveValue.AsString().Length <= index || index < 0 ? PropertyDescriptor.Undefined : new PropertyDescriptor(new JsValue(primitiveValue.AsString()[index].ToString()), new bool?(false), new bool?(true), new bool?(false));
    }
  }
}
