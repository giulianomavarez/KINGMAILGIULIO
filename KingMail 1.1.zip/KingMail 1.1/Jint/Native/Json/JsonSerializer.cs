﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Json.JsonSerializer
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Array;
using Jint.Native.Global;
using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Descriptors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#nullable disable
namespace Jint.Native.Json
{
  public class JsonSerializer
  {
    private readonly Engine _engine;
    private Stack<object> _stack;
    private string _indent;
    private string _gap;
    private List<string> _propertyList;
    private JsValue _replacerFunction = Undefined.Instance;

    public JsonSerializer(Engine engine) => this._engine = engine;

    public JsValue Serialize(JsValue value, JsValue replacer, JsValue space)
    {
      this._stack = new Stack<object>();
      if (value.Is<ICallable>() && replacer == Undefined.Instance)
        return Undefined.Instance;
      if (replacer.IsObject())
      {
        if (replacer.Is<ICallable>())
        {
          this._replacerFunction = replacer;
        }
        else
        {
          ObjectInstance objectInstance1 = replacer.AsObject();
          if (objectInstance1.Class == "Array")
            this._propertyList = new List<string>();
          foreach (object obj in objectInstance1.GetOwnProperties().Select<KeyValuePair<string, PropertyDescriptor>, PropertyDescriptor>((Func<KeyValuePair<string, PropertyDescriptor>, PropertyDescriptor>) (x => x.Value)))
          {
            JsValue o = this._engine.GetValue(obj);
            string str = (string) null;
            if (o.IsString())
              str = o.AsString();
            else if (o.IsNumber())
              str = TypeConverter.ToString(o);
            else if (o.IsObject())
            {
              ObjectInstance objectInstance2 = o.AsObject();
              if (objectInstance2.Class == "String" || objectInstance2.Class == "Number")
                str = TypeConverter.ToString(o);
            }
            if (str != null && !this._propertyList.Contains(str))
              this._propertyList.Add(str);
          }
        }
      }
      if (space.IsObject())
      {
        ObjectInstance o = space.AsObject();
        if (o.Class == "Number")
          space = (JsValue) TypeConverter.ToNumber((JsValue) o);
        else if (o.Class == "String")
          space = (JsValue) TypeConverter.ToString((JsValue) o);
      }
      if (space.IsNumber())
        this._gap = space.AsNumber() <= 0.0 ? string.Empty : new string(' ', (int) Math.Min(10.0, space.AsNumber()));
      else if (space.IsString())
      {
        string str = space.AsString();
        this._gap = str.Length <= 10 ? str : str.Substring(0, 10);
      }
      else
        this._gap = string.Empty;
      ObjectInstance holder = this._engine.Object.Construct(Arguments.Empty);
      holder.DefineOwnProperty("", new PropertyDescriptor(value, new bool?(true), new bool?(true), new bool?(true)), false);
      return this.Str("", holder);
    }

    private JsValue Str(string key, ObjectInstance holder)
    {
      JsValue jsValue1 = holder.Get(key);
      if (jsValue1.IsObject())
      {
        JsValue jsValue2 = jsValue1.AsObject().Get("toJSON");
        if (jsValue2.IsObject() && jsValue2.AsObject() is ICallable callable)
        {
          JsValue thisObject = jsValue1;
          JsValue[] arguments = Arguments.From((JsValue) key);
          jsValue1 = callable.Call(thisObject, arguments);
        }
      }
      if (this._replacerFunction != Undefined.Instance)
        jsValue1 = ((ICallable) this._replacerFunction.AsObject()).Call((JsValue) holder, Arguments.From((JsValue) key, jsValue1));
      if (jsValue1.IsObject())
      {
        switch (jsValue1.AsObject().Class)
        {
          case "Number":
            jsValue1 = (JsValue) TypeConverter.ToNumber(jsValue1);
            break;
          case "String":
            jsValue1 = (JsValue) TypeConverter.ToString(jsValue1);
            break;
          case "Boolean":
            jsValue1 = TypeConverter.ToPrimitive(jsValue1);
            break;
          case "Array":
            return (JsValue) this.SerializeArray(jsValue1.As<ArrayInstance>());
          case "Object":
            return (JsValue) this.SerializeObject(jsValue1.AsObject());
        }
      }
      if (jsValue1 == Null.Instance)
        return (JsValue) "null";
      if (jsValue1.IsBoolean() && jsValue1.AsBoolean())
        return (JsValue) "true";
      if (jsValue1.IsBoolean() && !jsValue1.AsBoolean())
        return (JsValue) "false";
      if (jsValue1.IsString())
        return (JsValue) this.Quote(jsValue1.AsString());
      if (jsValue1.IsNumber())
        return GlobalObject.IsFinite(Undefined.Instance, Arguments.From(jsValue1)).AsBoolean() ? (JsValue) TypeConverter.ToString(jsValue1) : (JsValue) "null";
      bool flag = jsValue1.IsObject() && jsValue1.AsObject() is ICallable;
      if (!jsValue1.IsObject() || flag)
        return JsValue.Undefined;
      return jsValue1.AsObject().Class == "Array" ? (JsValue) this.SerializeArray(jsValue1.As<ArrayInstance>()) : (JsValue) this.SerializeObject(jsValue1.AsObject());
    }

    private string Quote(string value)
    {
      StringBuilder stringBuilder = new StringBuilder("\"");
      foreach (char ch in value)
      {
        switch (ch)
        {
          case '\b':
            stringBuilder.Append("\\b");
            break;
          case '\t':
            stringBuilder.Append("\\t");
            break;
          case '\n':
            stringBuilder.Append("\\n");
            break;
          case '\f':
            stringBuilder.Append("\\f");
            break;
          case '\r':
            stringBuilder.Append("\\r");
            break;
          case '"':
            stringBuilder.Append("\\\"");
            break;
          case '\\':
            stringBuilder.Append("\\\\");
            break;
          default:
            if (ch < ' ')
            {
              stringBuilder.Append("\\u");
              stringBuilder.Append(((int) ch).ToString("x4"));
              break;
            }
            stringBuilder.Append(ch);
            break;
        }
      }
      stringBuilder.Append("\"");
      return stringBuilder.ToString();
    }

    private string SerializeArray(ArrayInstance value)
    {
      this.EnsureNonCyclicity((object) value);
      this._stack.Push((object) value);
      string indent = this._indent;
      this._indent += this._gap;
      List<string> stringList = new List<string>();
      uint uint32 = TypeConverter.ToUint32(value.Get("length"));
      for (int o = 0; (long) o < (long) uint32; ++o)
      {
        JsValue jsValue = this.Str(TypeConverter.ToString((JsValue) (double) o), (ObjectInstance) value);
        if (jsValue == JsValue.Undefined)
          jsValue = (JsValue) "null";
        stringList.Add(jsValue.AsString());
      }
      if (stringList.Count == 0)
        return "[]";
      string str;
      if (this._gap == "")
        str = "[" + string.Join(",", stringList.ToArray()) + "]";
      else
        str = "[\n" + this._indent + string.Join(",\n" + this._indent, stringList.ToArray()) + "\n" + indent + "]";
      this._stack.Pop();
      this._indent = indent;
      return str;
    }

    private void EnsureNonCyclicity(object value)
    {
      if (value == null)
        throw new ArgumentNullException(nameof (value));
      if (this._stack.Contains(value))
        throw new JavaScriptException(this._engine.TypeError, "Cyclic reference detected.");
    }

    private string SerializeObject(ObjectInstance value)
    {
      this.EnsureNonCyclicity((object) value);
      this._stack.Push((object) value);
      string indent = this._indent;
      this._indent += this._gap;
      List<string> stringList1 = this._propertyList ?? value.GetOwnProperties().Where<KeyValuePair<string, PropertyDescriptor>>((Func<KeyValuePair<string, PropertyDescriptor>, bool>) (x => x.Value.Enumerable.HasValue && x.Value.Enumerable.Value)).Select<KeyValuePair<string, PropertyDescriptor>, string>((Func<KeyValuePair<string, PropertyDescriptor>, string>) (x => x.Key)).ToList<string>();
      List<string> stringList2 = new List<string>();
      foreach (string key in stringList1)
      {
        JsValue jsValue = this.Str(key, value);
        if (jsValue != JsValue.Undefined)
        {
          string str1 = this.Quote(key) + ":";
          if (this._gap != "")
            str1 += " ";
          string str2 = str1 + jsValue.AsString();
          stringList2.Add(str2);
        }
      }
      string str;
      if (stringList2.Count == 0)
        str = "{}";
      else if (this._gap == "")
        str = "{" + string.Join(",", stringList2.ToArray()) + "}";
      else
        str = "{\n" + this._indent + string.Join(",\n" + this._indent, stringList2.ToArray()) + "\n" + indent + "}";
      this._stack.Pop();
      this._indent = indent;
      return str;
    }
  }
}
