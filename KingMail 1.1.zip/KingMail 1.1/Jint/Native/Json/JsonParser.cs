﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Json.JsonParser
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Object;
using Jint.Parser;
using Jint.Parser.Ast;
using Jint.Runtime;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

#nullable disable
namespace Jint.Native.Json
{
  public class JsonParser
  {
    private readonly Engine _engine;
    private JsonParser.Extra _extra;
    private int _index;
    private int _length;
    private int _lineNumber;
    private int _lineStart;
    private Location _location;
    private JsonParser.Token _lookahead;
    private string _source;
    private Jint.Parser.State _state;

    public JsonParser(Engine engine) => this._engine = engine;

    private static bool IsDecimalDigit(char ch) => ch >= '0' && ch <= '9';

    private static bool IsHexDigit(char ch)
    {
      if (ch >= '0' && ch <= '9' || ch >= 'a' && ch <= 'f')
        return true;
      return ch >= 'A' && ch <= 'F';
    }

    private static bool IsOctalDigit(char ch) => ch >= '0' && ch <= '7';

    private static bool IsWhiteSpace(char ch)
    {
      return ch == ' ' || ch == '\t' || ch == '\n' || ch == '\r';
    }

    private static bool IsLineTerminator(char ch)
    {
      return ch == '\n' || ch == '\r' || ch == '\u2028' || ch == '\u2029';
    }

    private static bool IsNullChar(char ch) => ch == 'n' || ch == 'u' || ch == 'l' || ch == 'l';

    private static bool IsTrueOrFalseChar(char ch)
    {
      return ch == 't' || ch == 'r' || ch == 'u' || ch == 'e' || ch == 'f' || ch == 'a' || ch == 'l' || ch == 's';
    }

    private char ScanHexEscape(char prefix)
    {
      int num1 = 0;
      int num2 = prefix == 'u' ? 4 : 2;
      for (int index = 0; index < num2; ++index)
      {
        if (this._index >= this._length || !JsonParser.IsHexDigit(this._source.CharCodeAt(this._index)))
          throw new JavaScriptException(this._engine.SyntaxError, string.Format("Expected hexadecimal digit:{0}", (object) this._source));
        char ch = this._source.CharCodeAt(this._index++);
        num1 = num1 * 16 + "0123456789abcdef".IndexOf(ch.ToString(), StringComparison.OrdinalIgnoreCase);
      }
      return (char) num1;
    }

    private void SkipWhiteSpace()
    {
      while (this._index < this._length && JsonParser.IsWhiteSpace(this._source.CharCodeAt(this._index)))
        ++this._index;
    }

    private JsonParser.Token ScanPunctuator()
    {
      int index = this._index;
      char ch = this._source.CharCodeAt(this._index);
      switch (ch)
      {
        case '(':
        case ')':
        case ',':
        case '.':
        case ':':
        case ';':
        case '?':
        case '[':
        case ']':
        case '{':
        case '}':
        case '~':
          ++this._index;
          return new JsonParser.Token()
          {
            Type = JsonParser.Tokens.Punctuator,
            Value = (object) ch.ToString(),
            LineNumber = new int?(this._lineNumber),
            LineStart = this._lineStart,
            Range = new int[2]{ index, this._index }
          };
        default:
          throw new JavaScriptException(this._engine.SyntaxError, string.Format("Unexpected token {0}", (object) ch));
      }
    }

    private JsonParser.Token ScanNumericLiteral()
    {
      char ch1 = this._source.CharCodeAt(this._index);
      int index = this._index;
      string s = "";
      char ch2;
      if (ch1 == '-')
      {
        string str1 = s;
        ch2 = this._source.CharCodeAt(this._index++);
        string str2 = ch2.ToString();
        s = str1 + str2;
        ch1 = this._source.CharCodeAt(this._index);
      }
      if (ch1 != '.')
      {
        string str3 = s;
        ch2 = this._source.CharCodeAt(this._index++);
        string str4 = ch2.ToString();
        s = str3 + str4;
        char ch3 = this._source.CharCodeAt(this._index);
        if (s == "0" && ch3 > char.MinValue && JsonParser.IsDecimalDigit(ch3))
          throw new Exception("Unexpected token {0}");
        while (JsonParser.IsDecimalDigit(this._source.CharCodeAt(this._index)))
        {
          string str5 = s;
          ch2 = this._source.CharCodeAt(this._index++);
          string str6 = ch2.ToString();
          s = str5 + str6;
        }
        ch1 = this._source.CharCodeAt(this._index);
      }
      if (ch1 == '.')
      {
        string str7 = s;
        ch2 = this._source.CharCodeAt(this._index++);
        string str8 = ch2.ToString();
        s = str7 + str8;
        while (JsonParser.IsDecimalDigit(this._source.CharCodeAt(this._index)))
        {
          string str9 = s;
          ch2 = this._source.CharCodeAt(this._index++);
          string str10 = ch2.ToString();
          s = str9 + str10;
        }
        ch1 = this._source.CharCodeAt(this._index);
      }
      if (ch1 == 'e' || ch1 == 'E')
      {
        string str11 = s;
        ch2 = this._source.CharCodeAt(this._index++);
        string str12 = ch2.ToString();
        s = str11 + str12;
        switch (this._source.CharCodeAt(this._index))
        {
          case '+':
          case '-':
            string str13 = s;
            ch2 = this._source.CharCodeAt(this._index++);
            string str14 = ch2.ToString();
            s = str13 + str14;
            break;
        }
        if (!JsonParser.IsDecimalDigit(this._source.CharCodeAt(this._index)))
          throw new Exception("Unexpected token {0}");
        while (JsonParser.IsDecimalDigit(this._source.CharCodeAt(this._index)))
        {
          string str15 = s;
          ch2 = this._source.CharCodeAt(this._index++);
          string str16 = ch2.ToString();
          s = str15 + str16;
        }
      }
      return new JsonParser.Token()
      {
        Type = JsonParser.Tokens.Number,
        Value = (object) double.Parse(s, NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint | NumberStyles.AllowExponent, (IFormatProvider) CultureInfo.InvariantCulture),
        LineNumber = new int?(this._lineNumber),
        LineStart = this._lineStart,
        Range = new int[2]{ index, this._index }
      };
    }

    private JsonParser.Token ScanBooleanLiteral()
    {
      int index = this._index;
      string str = "";
      while (JsonParser.IsTrueOrFalseChar(this._source.CharCodeAt(this._index)))
        str += this._source.CharCodeAt(this._index++).ToString();
      if (!(str == "true") && !(str == "false"))
        throw new JavaScriptException(this._engine.SyntaxError, string.Format("Unexpected token {0}", (object) str));
      return new JsonParser.Token()
      {
        Type = JsonParser.Tokens.BooleanLiteral,
        Value = (object) (str == "true"),
        LineNumber = new int?(this._lineNumber),
        LineStart = this._lineStart,
        Range = new int[2]{ index, this._index }
      };
    }

    private JsonParser.Token ScanNullLiteral()
    {
      int index = this._index;
      string str = "";
      while (JsonParser.IsNullChar(this._source.CharCodeAt(this._index)))
        str += this._source.CharCodeAt(this._index++).ToString();
      if (!(str == Null.Text))
        throw new JavaScriptException(this._engine.SyntaxError, string.Format("Unexpected token {0}", (object) str));
      return new JsonParser.Token()
      {
        Type = JsonParser.Tokens.NullLiteral,
        Value = (object) Null.Instance,
        LineNumber = new int?(this._lineNumber),
        LineStart = this._lineStart,
        Range = new int[2]{ index, this._index }
      };
    }

    private JsonParser.Token ScanStringLiteral()
    {
      StringBuilder stringBuilder = new StringBuilder();
      char ch1 = this._source.CharCodeAt(this._index);
      int index1 = this._index;
      ++this._index;
      while (this._index < this._length)
      {
        char ch2 = this._source.CharCodeAt(this._index++);
        if ((int) ch2 == (int) ch1)
        {
          ch1 = char.MinValue;
          break;
        }
        if (ch2 <= '\u001F')
          throw new JavaScriptException(this._engine.SyntaxError, string.Format("Invalid character '{0}', position:{1}, string:{2}", (object) ch2, (object) this._index, (object) this._source));
        if (ch2 == '\\')
        {
          ch2 = this._source.CharCodeAt(this._index++);
          if (ch2 > char.MinValue || !JsonParser.IsLineTerminator(ch2))
          {
            switch (ch2)
            {
              case 'b':
                stringBuilder.Append("\b");
                continue;
              case 'f':
                stringBuilder.Append("\f");
                continue;
              case 'n':
                stringBuilder.Append('\n');
                continue;
              case 'r':
                stringBuilder.Append('\r');
                continue;
              case 't':
                stringBuilder.Append('\t');
                continue;
              case 'u':
              case 'x':
                int index2 = this._index;
                char ch3 = this.ScanHexEscape(ch2);
                if (ch3 > char.MinValue)
                {
                  stringBuilder.Append(ch3.ToString());
                  continue;
                }
                this._index = index2;
                stringBuilder.Append(ch2.ToString());
                continue;
              case 'v':
                stringBuilder.Append("\v");
                continue;
              default:
                if (JsonParser.IsOctalDigit(ch2))
                {
                  int num = "01234567".IndexOf(ch2);
                  if (this._index < this._length && JsonParser.IsOctalDigit(this._source.CharCodeAt(this._index)))
                  {
                    num = num * 8 + "01234567".IndexOf(this._source.CharCodeAt(this._index++));
                    if ("0123".IndexOf(ch2) >= 0 && this._index < this._length && JsonParser.IsOctalDigit(this._source.CharCodeAt(this._index)))
                      num = num * 8 + "01234567".IndexOf(this._source.CharCodeAt(this._index++));
                  }
                  stringBuilder.Append(((char) num).ToString());
                  continue;
                }
                stringBuilder.Append(ch2.ToString());
                continue;
            }
          }
          else
          {
            ++this._lineNumber;
            if (ch2 == '\r' && this._source.CharCodeAt(this._index) == '\n')
              ++this._index;
          }
        }
        else if (!JsonParser.IsLineTerminator(ch2))
          stringBuilder.Append(ch2.ToString());
        else
          break;
      }
      if (ch1 != char.MinValue)
        throw new JavaScriptException(this._engine.SyntaxError, string.Format("Unexpected token {0}", (object) this._source));
      return new JsonParser.Token()
      {
        Type = JsonParser.Tokens.String,
        Value = (object) stringBuilder.ToString(),
        LineNumber = new int?(this._lineNumber),
        LineStart = this._lineStart,
        Range = new int[2]{ index1, this._index }
      };
    }

    private JsonParser.Token Advance()
    {
      this.SkipWhiteSpace();
      if (this._index >= this._length)
        return new JsonParser.Token()
        {
          Type = JsonParser.Tokens.EOF,
          LineNumber = new int?(this._lineNumber),
          LineStart = this._lineStart,
          Range = new int[2]{ this._index, this._index }
        };
      char ch = this._source.CharCodeAt(this._index);
      switch (ch)
      {
        case '"':
          return this.ScanStringLiteral();
        case '(':
        case ')':
        case ':':
          return this.ScanPunctuator();
        case '-':
          return JsonParser.IsDecimalDigit(this._source.CharCodeAt(this._index + 1)) ? this.ScanNumericLiteral() : this.ScanPunctuator();
        case '.':
          return JsonParser.IsDecimalDigit(this._source.CharCodeAt(this._index + 1)) ? this.ScanNumericLiteral() : this.ScanPunctuator();
        default:
          if (JsonParser.IsDecimalDigit(ch))
            return this.ScanNumericLiteral();
          switch (ch)
          {
            case 'f':
            case 't':
              return this.ScanBooleanLiteral();
            case 'n':
              return this.ScanNullLiteral();
            default:
              return this.ScanPunctuator();
          }
      }
    }

    private JsonParser.Token CollectToken()
    {
      this._location = new Location()
      {
        Start = new Position()
        {
          Line = this._lineNumber,
          Column = this._index - this._lineStart
        }
      };
      JsonParser.Token token = this.Advance();
      this._location.End = new Position()
      {
        Line = this._lineNumber,
        Column = this._index - this._lineStart
      };
      if (token.Type != JsonParser.Tokens.EOF)
      {
        int[] numArray = new int[2]
        {
          token.Range[0],
          token.Range[1]
        };
        string str = this._source.Slice(token.Range[0], token.Range[1]);
        this._extra.Tokens.Add(new JsonParser.Token()
        {
          Type = token.Type,
          Value = (object) str,
          Range = numArray
        });
      }
      return token;
    }

    private JsonParser.Token Lex()
    {
      JsonParser.Token lookahead = this._lookahead;
      this._index = lookahead.Range[1];
      this._lineNumber = lookahead.LineNumber.HasValue ? lookahead.LineNumber.Value : 0;
      this._lineStart = lookahead.LineStart;
      this._lookahead = this._extra.Tokens != null ? this.CollectToken() : this.Advance();
      this._index = lookahead.Range[1];
      this._lineNumber = lookahead.LineNumber.HasValue ? lookahead.LineNumber.Value : 0;
      this._lineStart = lookahead.LineStart;
      return lookahead;
    }

    private void Peek()
    {
      int index = this._index;
      int lineNumber = this._lineNumber;
      int lineStart = this._lineStart;
      this._lookahead = this._extra.Tokens != null ? this.CollectToken() : this.Advance();
      this._index = index;
      this._lineNumber = lineNumber;
      this._lineStart = lineStart;
    }

    private void MarkStart()
    {
      if (this._extra.Loc.HasValue)
      {
        this._state.MarkerStack.Push(this._index - this._lineStart);
        this._state.MarkerStack.Push(this._lineNumber);
      }
      if (this._extra.Range == null)
        return;
      this._state.MarkerStack.Push(this._index);
    }

    private T MarkEnd<T>(T node) where T : SyntaxNode
    {
      if (this._extra.Range != null)
        node.Range = new int[2]
        {
          this._state.MarkerStack.Pop(),
          this._index
        };
      if (this._extra.Loc.HasValue)
      {
        node.Location = new Location()
        {
          Start = new Position()
          {
            Line = this._state.MarkerStack.Pop(),
            Column = this._state.MarkerStack.Pop()
          },
          End = new Position()
          {
            Line = this._lineNumber,
            Column = this._index - this._lineStart
          }
        };
        this.PostProcess((SyntaxNode) node);
      }
      return node;
    }

    public T MarkEndIf<T>(T node) where T : SyntaxNode
    {
      if (node.Range != null || node.Location != null)
      {
        if (this._extra.Loc.HasValue)
        {
          this._state.MarkerStack.Pop();
          this._state.MarkerStack.Pop();
        }
        if (this._extra.Range != null)
          this._state.MarkerStack.Pop();
      }
      else
        this.MarkEnd<T>(node);
      return node;
    }

    public SyntaxNode PostProcess(SyntaxNode node)
    {
      if (this._extra.Source != null)
        node.Location.Source = this._extra.Source;
      return node;
    }

    public ObjectInstance CreateArrayInstance(IEnumerable<JsValue> values)
    {
      ObjectInstance thisObject = this._engine.Array.Construct(Arguments.Empty);
      this._engine.Array.PrototypeObject.Push((JsValue) thisObject, values.ToArray<JsValue>());
      return thisObject;
    }

    private void ThrowError(
      JsonParser.Token token,
      string messageFormat,
      params object[] arguments)
    {
      string str = string.Format(messageFormat, arguments);
      ParserException parserException;
      if (token.LineNumber.HasValue)
        parserException = new ParserException("Line " + (object) token.LineNumber + ": " + str)
        {
          Index = token.Range[0],
          LineNumber = token.LineNumber.Value,
          Column = token.Range[0] - this._lineStart + 1
        };
      else
        parserException = new ParserException("Line " + (object) this._lineNumber + ": " + str)
        {
          Index = this._index,
          LineNumber = this._lineNumber,
          Column = this._index - this._lineStart + 1
        };
      parserException.Description = str;
      throw parserException;
    }

    private void ThrowUnexpected(JsonParser.Token token)
    {
      if (token.Type == JsonParser.Tokens.EOF)
        this.ThrowError(token, "Unexpected end of input");
      if (token.Type == JsonParser.Tokens.Number)
        this.ThrowError(token, "Unexpected number");
      if (token.Type == JsonParser.Tokens.String)
        this.ThrowError(token, "Unexpected string");
      this.ThrowError(token, "Unexpected token {0}", (object) (token.Value as string));
    }

    private void Expect(string value)
    {
      JsonParser.Token token = this.Lex();
      if (token.Type == JsonParser.Tokens.Punctuator && value.Equals(token.Value))
        return;
      this.ThrowUnexpected(token);
    }

    private bool Match(string value)
    {
      return this._lookahead.Type == JsonParser.Tokens.Punctuator && value.Equals(this._lookahead.Value);
    }

    private ObjectInstance ParseJsonArray()
    {
      List<JsValue> values = new List<JsValue>();
      this.Expect("[");
      while (!this.Match("]"))
      {
        if (this.Match(","))
        {
          this.Lex();
          values.Add(Null.Instance);
        }
        else
        {
          values.Add(this.ParseJsonValue());
          if (!this.Match("]"))
            this.Expect(",");
        }
      }
      this.Expect("]");
      return this.CreateArrayInstance((IEnumerable<JsValue>) values);
    }

    public ObjectInstance ParseJsonObject()
    {
      this.Expect("{");
      ObjectInstance jsonObject = this._engine.Object.Construct(Arguments.Empty);
      while (!this.Match("}"))
      {
        if (this._lookahead.Type != JsonParser.Tokens.String)
          this.ThrowUnexpected(this.Lex());
        string str = this.Lex().Value.ToString();
        if (this.PropertyNameContainsInvalidChar0To31(str))
          throw new JavaScriptException(this._engine.SyntaxError, string.Format("Invalid character in property name '{0}'", (object) str));
        this.Expect(":");
        JsValue jsonValue = this.ParseJsonValue();
        jsonObject.FastAddProperty(str, jsonValue, true, true, true);
        if (!this.Match("}"))
          this.Expect(",");
      }
      this.Expect("}");
      return jsonObject;
    }

    private bool PropertyNameContainsInvalidChar0To31(string s)
    {
      for (int index = 0; index < s.Length; ++index)
      {
        if (s[index] <= '\u001F')
          return true;
      }
      return false;
    }

    private JsValue ParseJsonValue()
    {
      JsonParser.Tokens type = this._lookahead.Type;
      this.MarkStart();
      switch (type)
      {
        case JsonParser.Tokens.NullLiteral:
          object obj = this.Lex().Value;
          return Null.Instance;
        case JsonParser.Tokens.BooleanLiteral:
          return new JsValue((bool) this.Lex().Value);
        case JsonParser.Tokens.String:
          return new JsValue((string) this.Lex().Value);
        case JsonParser.Tokens.Number:
          return new JsValue((double) this.Lex().Value);
        default:
          if (this.Match("["))
            return (JsValue) this.ParseJsonArray();
          if (this.Match("{"))
            return (JsValue) this.ParseJsonObject();
          this.ThrowUnexpected(this.Lex());
          return Null.Instance;
      }
    }

    public JsValue Parse(string code) => this.Parse(code, (ParserOptions) null);

    public JsValue Parse(string code, ParserOptions options)
    {
      this._source = code;
      this._index = 0;
      this._lineNumber = this._source.Length > 0 ? 1 : 0;
      this._lineStart = 0;
      this._length = this._source.Length;
      this._lookahead = (JsonParser.Token) null;
      this._state = new Jint.Parser.State()
      {
        AllowIn = true,
        LabelSet = new HashSet<string>(),
        InFunctionBody = false,
        InIteration = false,
        InSwitch = false,
        LastCommentStart = -1,
        MarkerStack = new Stack<int>()
      };
      this._extra = new JsonParser.Extra()
      {
        Range = new int[0],
        Loc = new int?(0)
      };
      if (options != null)
      {
        if (!string.IsNullOrEmpty(options.Source))
          this._extra.Source = options.Source;
        if (options.Tokens)
          this._extra.Tokens = new List<JsonParser.Token>();
      }
      try
      {
        this.MarkStart();
        this.Peek();
        JsValue jsonValue = this.ParseJsonValue();
        this.Peek();
        int type = (int) this._lookahead.Type;
        object obj = this._lookahead.Value;
        if (this._lookahead.Type != JsonParser.Tokens.EOF)
          throw new JavaScriptException(this._engine.SyntaxError, string.Format("Unexpected {0} {1}", (object) this._lookahead.Type, this._lookahead.Value));
        return jsonValue;
      }
      finally
      {
        this._extra = new JsonParser.Extra();
      }
    }

    private class Extra
    {
      public int? Loc;
      public int[] Range;
      public string Source;
      public List<JsonParser.Token> Tokens;
    }

    private enum Tokens
    {
      NullLiteral,
      BooleanLiteral,
      String,
      Number,
      Punctuator,
      EOF,
    }

    private class Token
    {
      public JsonParser.Tokens Type;
      public object Value;
      public int[] Range;
      public int? LineNumber;
      public int LineStart;
    }

    private static class Messages
    {
      public const string UnexpectedToken = "Unexpected token {0}";
      public const string UnexpectedNumber = "Unexpected number";
      public const string UnexpectedString = "Unexpected string";
      public const string UnexpectedEOS = "Unexpected end of input";
    }
  }
}
