﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Json.JsonInstance
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Interop;
using System;

#nullable disable
namespace Jint.Native.Json
{
  public sealed class JsonInstance : ObjectInstance
  {
    private readonly Engine _engine;

    private JsonInstance(Engine engine)
      : base(engine)
    {
      this._engine = engine;
      this.Extensible = true;
    }

    public override string Class => "JSON";

    public static JsonInstance CreateJsonObject(Engine engine)
    {
      JsonInstance jsonObject = new JsonInstance(engine);
      jsonObject.Prototype = (ObjectInstance) engine.Object.PrototypeObject;
      return jsonObject;
    }

    public void Configure()
    {
      this.FastAddProperty("parse", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Parse), 2), true, false, true);
      this.FastAddProperty("stringify", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Stringify), 3), true, false, true);
    }

    public JsValue Parse(JsValue thisObject, JsValue[] arguments)
    {
      return new JsonParser(this._engine).Parse(TypeConverter.ToString(arguments[0]));
    }

    public JsValue Stringify(JsValue thisObject, JsValue[] arguments)
    {
      JsValue instance1 = Undefined.Instance;
      JsValue instance2 = Undefined.Instance;
      JsValue instance3 = Undefined.Instance;
      if (arguments.Length > 2)
        instance3 = arguments[2];
      if (arguments.Length > 1)
        instance2 = arguments[1];
      if (arguments.Length != 0)
        instance1 = arguments[0];
      JsonSerializer jsonSerializer = new JsonSerializer(this._engine);
      return instance1 == Undefined.Instance && instance2 == Undefined.Instance ? Undefined.Instance : jsonSerializer.Serialize(instance1, instance2, instance3);
    }
  }
}
