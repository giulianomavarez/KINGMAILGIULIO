﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Array.ArrayPrototype
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Descriptors;
using Jint.Runtime.Interop;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace Jint.Native.Array
{
  public sealed class ArrayPrototype : ArrayInstance
  {
    private ArrayPrototype(Engine engine)
      : base(engine)
    {
    }

    public static ArrayPrototype CreatePrototypeObject(
      Engine engine,
      ArrayConstructor arrayConstructor)
    {
      ArrayPrototype prototypeObject = new ArrayPrototype(engine);
      prototypeObject.Extensible = true;
      prototypeObject.Prototype = (ObjectInstance) engine.Object.PrototypeObject;
      prototypeObject.FastAddProperty("length", (JsValue) 0.0, true, false, false);
      prototypeObject.FastAddProperty("constructor", (JsValue) (ObjectInstance) arrayConstructor, true, false, true);
      return prototypeObject;
    }

    public void Configure()
    {
      this.FastAddProperty("toString", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToString), 0), true, false, true);
      this.FastAddProperty("toLocaleString", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToLocaleString)), true, false, true);
      this.FastAddProperty("concat", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Concat), 1), true, false, true);
      this.FastAddProperty("join", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Join), 1), true, false, true);
      this.FastAddProperty("pop", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Pop)), true, false, true);
      this.FastAddProperty("push", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Push), 1), true, false, true);
      this.FastAddProperty("reverse", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Reverse)), true, false, true);
      this.FastAddProperty("shift", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Shift)), true, false, true);
      this.FastAddProperty("slice", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Slice), 2), true, false, true);
      this.FastAddProperty("sort", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Sort), 1), true, false, true);
      this.FastAddProperty("splice", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Splice), 2), true, false, true);
      this.FastAddProperty("unshift", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Unshift), 1), true, false, true);
      this.FastAddProperty("indexOf", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.IndexOf), 1), true, false, true);
      this.FastAddProperty("lastIndexOf", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.LastIndexOf), 1), true, false, true);
      this.FastAddProperty("every", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Every), 1), true, false, true);
      this.FastAddProperty("some", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Some), 1), true, false, true);
      this.FastAddProperty("forEach", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ForEach), 1), true, false, true);
      this.FastAddProperty("map", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Map), 1), true, false, true);
      this.FastAddProperty("filter", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Filter), 1), true, false, true);
      this.FastAddProperty("reduce", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Reduce), 1), true, false, true);
      this.FastAddProperty("reduceRight", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ReduceRight), 1), true, false, true);
    }

    private JsValue LastIndexOf(JsValue thisObj, JsValue[] arguments)
    {
      ObjectInstance objectInstance = TypeConverter.ToObject(this.Engine, thisObj);
      uint uint32 = TypeConverter.ToUint32(objectInstance.Get("length"));
      if (uint32 == 0U)
        return (JsValue) -1.0;
      double val1 = arguments.Length > 1 ? TypeConverter.ToInteger(arguments[1]) : (double) (uint32 - 1U);
      double o = val1 < 0.0 ? (double) uint32 - Math.Abs(val1) : Math.Min(val1, (double) (uint32 - 1U));
      JsValue y = arguments.At(0);
      for (; o >= 0.0; --o)
      {
        string propertyName = TypeConverter.ToString((JsValue) o);
        if (objectInstance.HasProperty(propertyName) && ExpressionInterpreter.StrictlyEqual(objectInstance.Get(propertyName), y))
          return (JsValue) o;
      }
      return (JsValue) -1.0;
    }

    private JsValue Reduce(JsValue thisObj, JsValue[] arguments)
    {
      JsValue jsValue1 = arguments.At(0);
      JsValue jsValue2 = arguments.At(1);
      ObjectInstance objectInstance = TypeConverter.ToObject(this.Engine, thisObj);
      uint uint32 = TypeConverter.ToUint32(objectInstance.Get("length"));
      Action<JsValue> fail = (Action<JsValue>) (x =>
      {
        throw new JavaScriptException(this.Engine.TypeError, "Argument must be callable");
      });
      ICallable callable = jsValue1.TryCast<ICallable>(fail);
      if (uint32 == 0U && arguments.Length < 2)
        throw new JavaScriptException(this.Engine.TypeError);
      int num = 0;
      JsValue jsValue3 = Undefined.Instance;
      if (arguments.Length > 1)
      {
        jsValue3 = jsValue2;
      }
      else
      {
        bool flag;
        for (flag = false; !flag && (long) num < (long) uint32; ++num)
        {
          string propertyName = num.ToString();
          flag = objectInstance.HasProperty(propertyName);
          if (flag)
            jsValue3 = objectInstance.Get(propertyName);
        }
        if (!flag)
          throw new JavaScriptException(this.Engine.TypeError);
      }
      for (; (long) num < (long) uint32; ++num)
      {
        string propertyName = num.ToString();
        if (objectInstance.HasProperty(propertyName))
        {
          JsValue jsValue4 = objectInstance.Get(propertyName);
          jsValue3 = callable.Call(Undefined.Instance, new JsValue[4]
          {
            jsValue3,
            jsValue4,
            (JsValue) (double) num,
            (JsValue) objectInstance
          });
        }
      }
      return jsValue3;
    }

    private JsValue Filter(JsValue thisObj, JsValue[] arguments)
    {
      JsValue jsValue1 = arguments.At(0);
      JsValue thisObject = arguments.At(1);
      ObjectInstance objectInstance = TypeConverter.ToObject(this.Engine, thisObj);
      uint uint32 = TypeConverter.ToUint32(objectInstance.Get("length"));
      Action<JsValue> fail = (Action<JsValue>) (x =>
      {
        throw new JavaScriptException(this.Engine.TypeError, "Argument must be callable");
      });
      ICallable callable = jsValue1.TryCast<ICallable>(fail);
      ArrayInstance arrayInstance = (ArrayInstance) this.Engine.Array.Construct(Arguments.Empty);
      int num = 0;
      for (int index = 0; (long) index < (long) uint32; ++index)
      {
        string propertyName = index.ToString();
        if (objectInstance.HasProperty(propertyName))
        {
          JsValue jsValue2 = objectInstance.Get(propertyName);
          if (TypeConverter.ToBoolean(callable.Call(thisObject, new JsValue[3]
          {
            jsValue2,
            (JsValue) (double) index,
            (JsValue) objectInstance
          })))
          {
            arrayInstance.DefineOwnProperty(num.ToString(), new PropertyDescriptor(jsValue2, new bool?(true), new bool?(true), new bool?(true)), false);
            ++num;
          }
        }
      }
      return (JsValue) (ObjectInstance) arrayInstance;
    }

    private JsValue Map(JsValue thisObj, JsValue[] arguments)
    {
      JsValue jsValue1 = arguments.At(0);
      JsValue thisObject = arguments.At(1);
      ObjectInstance objectInstance1 = TypeConverter.ToObject(this.Engine, thisObj);
      uint uint32 = TypeConverter.ToUint32(objectInstance1.Get("length"));
      Action<JsValue> fail = (Action<JsValue>) (x =>
      {
        throw new JavaScriptException(this.Engine.TypeError, "Argument must be callable");
      });
      ICallable callable = jsValue1.TryCast<ICallable>(fail);
      ObjectInstance objectInstance2 = this.Engine.Array.Construct(new JsValue[1]
      {
        (JsValue) (double) uint32
      });
      for (int index = 0; (long) index < (long) uint32; ++index)
      {
        string propertyName = index.ToString();
        if (objectInstance1.HasProperty(propertyName))
        {
          JsValue jsValue2 = objectInstance1.Get(propertyName);
          JsValue jsValue3 = callable.Call(thisObject, new JsValue[3]
          {
            jsValue2,
            (JsValue) (double) index,
            (JsValue) objectInstance1
          });
          objectInstance2.DefineOwnProperty(propertyName, new PropertyDescriptor(jsValue3, new bool?(true), new bool?(true), new bool?(true)), false);
        }
      }
      return (JsValue) objectInstance2;
    }

    private JsValue ForEach(JsValue thisObj, JsValue[] arguments)
    {
      JsValue jsValue1 = arguments.At(0);
      JsValue thisObject = arguments.At(1);
      ObjectInstance objectInstance = TypeConverter.ToObject(this.Engine, thisObj);
      uint uint32 = TypeConverter.ToUint32(objectInstance.Get("length"));
      Action<JsValue> fail = (Action<JsValue>) (x =>
      {
        throw new JavaScriptException(this.Engine.TypeError, "Argument must be callable");
      });
      ICallable callable = jsValue1.TryCast<ICallable>(fail);
      for (int index = 0; (long) index < (long) uint32; ++index)
      {
        string propertyName = index.ToString();
        if (objectInstance.HasProperty(propertyName))
        {
          JsValue jsValue2 = objectInstance.Get(propertyName);
          callable.Call(thisObject, new JsValue[3]
          {
            jsValue2,
            (JsValue) (double) index,
            (JsValue) objectInstance
          });
        }
      }
      return Undefined.Instance;
    }

    private JsValue Some(JsValue thisObj, JsValue[] arguments)
    {
      JsValue jsValue1 = arguments.At(0);
      JsValue thisObject = arguments.At(1);
      ObjectInstance objectInstance = TypeConverter.ToObject(this.Engine, thisObj);
      uint uint32 = TypeConverter.ToUint32(objectInstance.Get("length"));
      Action<JsValue> fail = (Action<JsValue>) (x =>
      {
        throw new JavaScriptException(this.Engine.TypeError, "Argument must be callable");
      });
      ICallable callable = jsValue1.TryCast<ICallable>(fail);
      for (int index = 0; (long) index < (long) uint32; ++index)
      {
        string propertyName = index.ToString();
        if (objectInstance.HasProperty(propertyName))
        {
          JsValue jsValue2 = objectInstance.Get(propertyName);
          if (TypeConverter.ToBoolean(callable.Call(thisObject, new JsValue[3]
          {
            jsValue2,
            (JsValue) (double) index,
            (JsValue) objectInstance
          })))
            return (JsValue) true;
        }
      }
      return (JsValue) false;
    }

    private JsValue Every(JsValue thisObj, JsValue[] arguments)
    {
      JsValue jsValue1 = arguments.At(0);
      JsValue thisObject = arguments.At(1);
      ObjectInstance objectInstance = TypeConverter.ToObject(this.Engine, thisObj);
      uint uint32 = TypeConverter.ToUint32(objectInstance.Get("length"));
      Action<JsValue> fail = (Action<JsValue>) (x =>
      {
        throw new JavaScriptException(this.Engine.TypeError, "Argument must be callable");
      });
      ICallable callable = jsValue1.TryCast<ICallable>(fail);
      for (int index = 0; (long) index < (long) uint32; ++index)
      {
        string propertyName = index.ToString();
        if (objectInstance.HasProperty(propertyName))
        {
          JsValue jsValue2 = objectInstance.Get(propertyName);
          if (!TypeConverter.ToBoolean(callable.Call(thisObject, new JsValue[3]
          {
            jsValue2,
            (JsValue) (double) index,
            (JsValue) objectInstance
          })))
            return JsValue.False;
        }
      }
      return JsValue.True;
    }

    private JsValue IndexOf(JsValue thisObj, JsValue[] arguments)
    {
      ObjectInstance objectInstance = TypeConverter.ToObject(this.Engine, thisObj);
      uint uint32 = TypeConverter.ToUint32(objectInstance.Get("length"));
      if (uint32 == 0U)
        return (JsValue) -1.0;
      double num = arguments.Length > 1 ? TypeConverter.ToInteger(arguments[1]) : 0.0;
      if (num >= (double) uint32)
        return (JsValue) -1.0;
      double o;
      if (num >= 0.0)
      {
        o = num;
      }
      else
      {
        o = (double) uint32 - Math.Abs(num);
        if (o < 0.0)
          o = 0.0;
      }
      JsValue y = arguments.At(0);
      for (; o < (double) uint32; ++o)
      {
        string propertyName = TypeConverter.ToString((JsValue) o);
        if (objectInstance.HasProperty(propertyName) && ExpressionInterpreter.StrictlyEqual(objectInstance.Get(propertyName), y))
          return (JsValue) o;
      }
      return (JsValue) -1.0;
    }

    private JsValue Splice(JsValue thisObj, JsValue[] arguments)
    {
      JsValue o1 = arguments.At(0);
      JsValue o2 = arguments.At(1);
      ObjectInstance objectInstance1 = TypeConverter.ToObject(this.Engine, thisObj);
      ObjectInstance objectInstance2 = this.Engine.Array.Construct(Arguments.Empty);
      uint uint32 = TypeConverter.ToUint32(objectInstance1.Get("length"));
      double integer = TypeConverter.ToInteger(o1);
      uint num1 = integer >= 0.0 ? (uint) Math.Min(integer, (double) uint32) : (uint) Math.Max((double) uint32 + integer, 0.0);
      double num2 = Math.Min(Math.Max(TypeConverter.ToInteger(o2), 0.0), (double) (uint32 - num1));
      long num3;
      for (int index = 0; (double) index < num2; ++index)
      {
        num3 = (long) num1 + (long) index;
        string propertyName = num3.ToString();
        if (objectInstance1.HasProperty(propertyName))
        {
          JsValue jsValue = objectInstance1.Get(propertyName);
          objectInstance2.DefineOwnProperty(index.ToString(), new PropertyDescriptor(jsValue, new bool?(true), new bool?(true), new bool?(true)), false);
        }
      }
      JsValue[] array = ((IEnumerable<JsValue>) arguments).Skip<JsValue>(2).ToArray<JsValue>();
      if ((double) array.Length < num2)
      {
        for (uint index = num1; (double) index < (double) uint32 - num2; ++index)
        {
          string propertyName1 = ((double) index + num2).ToString();
          num3 = (long) index + (long) array.Length;
          string propertyName2 = num3.ToString();
          if (objectInstance1.HasProperty(propertyName1))
          {
            JsValue jsValue = objectInstance1.Get(propertyName1);
            objectInstance1.Put(propertyName2, jsValue, true);
          }
          else
            objectInstance1.Delete(propertyName2, true);
        }
        for (uint index = uint32; (double) index > (double) uint32 - num2 + (double) array.Length; --index)
          objectInstance1.Delete((index - 1U).ToString(), true);
      }
      else if ((double) array.Length > num2)
      {
        for (double num4 = (double) uint32 - num2; num4 > (double) num1; --num4)
        {
          double num5 = num4 + num2 - 1.0;
          string propertyName3 = num5.ToString();
          num5 = num4 + (double) array.Length - 1.0;
          string propertyName4 = num5.ToString();
          if (objectInstance1.HasProperty(propertyName3))
          {
            JsValue jsValue = objectInstance1.Get(propertyName3);
            objectInstance1.Put(propertyName4, jsValue, true);
          }
          else
            objectInstance1.Delete(propertyName4, true);
        }
      }
      for (int index = 0; index < array.Length; ++index)
      {
        JsValue jsValue1 = array[index];
        ObjectInstance objectInstance3 = objectInstance1;
        num3 = (long) index + (long) num1;
        string propertyName = num3.ToString();
        JsValue jsValue2 = jsValue1;
        objectInstance3.Put(propertyName, jsValue2, true);
      }
      objectInstance1.Put("length", (JsValue) ((double) uint32 - num2 + (double) array.Length), true);
      return (JsValue) objectInstance2;
    }

    private JsValue Unshift(JsValue thisObj, JsValue[] arguments)
    {
      ObjectInstance objectInstance = TypeConverter.ToObject(this.Engine, thisObj);
      uint uint32 = TypeConverter.ToUint32(objectInstance.Get("length"));
      uint length = (uint) arguments.Length;
      for (uint index = uint32; index > 0U; --index)
      {
        uint num = index - 1U;
        string propertyName1 = num.ToString();
        num = (uint) ((int) index + (int) length - 1);
        string propertyName2 = num.ToString();
        if (objectInstance.HasProperty(propertyName1))
        {
          JsValue jsValue = objectInstance.Get(propertyName1);
          objectInstance.Put(propertyName2, jsValue, true);
        }
        else
          objectInstance.Delete(propertyName2, true);
      }
      for (int index = 0; (long) index < (long) length; ++index)
        objectInstance.Put(index.ToString(), arguments[index], true);
      objectInstance.Put("length", (JsValue) (double) (uint32 + length), true);
      return (JsValue) (double) (uint32 + length);
    }

    private JsValue Sort(JsValue thisObj, JsValue[] arguments)
    {
      ObjectInstance obj = thisObj.IsObject() ? thisObj.AsObject() : throw new JavaScriptException(this.Engine.TypeError, "Array.prorotype.sort can only be applied on objects");
      int int32 = TypeConverter.ToInt32(obj.Get("length"));
      if (int32 <= 1)
        return (JsValue) obj;
      JsValue jsValue = arguments.At(0);
      ICallable compareFn = (ICallable) null;
      if (jsValue != Undefined.Instance)
        compareFn = jsValue.TryCast<ICallable>((Action<JsValue>) (x =>
        {
          throw new JavaScriptException(this.Engine.TypeError, "The sort argument must be a function");
        }));
      Comparison<JsValue> comparison = (Comparison<JsValue>) ((x, y) =>
      {
        if (x == Undefined.Instance && y == Undefined.Instance)
          return 0;
        if (x == Undefined.Instance)
          return 1;
        if (y == Undefined.Instance)
          return -1;
        if (compareFn == null)
          return string.CompareOrdinal(TypeConverter.ToString(x), TypeConverter.ToString(y));
        double number = TypeConverter.ToNumber(compareFn.Call(Undefined.Instance, new JsValue[2]
        {
          x,
          y
        }));
        if (number < 0.0)
          return -1;
        return number > 0.0 ? 1 : 0;
      });
      JsValue[] array = Enumerable.Range(0, int32).Select<int, JsValue>((Func<int, JsValue>) (i => obj.Get(i.ToString()))).ToArray<JsValue>();
      try
      {
        System.Array.Sort<JsValue>(array, comparison);
      }
      catch (InvalidOperationException ex)
      {
        throw ex.InnerException;
      }
      foreach (int index in Enumerable.Range(0, int32))
        obj.Put(index.ToString(), array[index], false);
      return (JsValue) obj;
    }

    private JsValue Slice(JsValue thisObj, JsValue[] arguments)
    {
      JsValue o1 = arguments.At(0);
      JsValue o2 = arguments.At(1);
      ObjectInstance objectInstance1 = TypeConverter.ToObject(this.Engine, thisObj);
      ObjectInstance objectInstance2 = this.Engine.Array.Construct(Arguments.Empty);
      uint uint32 = TypeConverter.ToUint32(objectInstance1.Get("length"));
      double integer1 = TypeConverter.ToInteger(o1);
      uint o3 = integer1 >= 0.0 ? (uint) Math.Min(TypeConverter.ToInteger(o1), (double) uint32) : (uint) Math.Max((double) uint32 + integer1, 0.0);
      uint num;
      if (o2 == Undefined.Instance)
      {
        num = TypeConverter.ToUint32((JsValue) (double) uint32);
      }
      else
      {
        double integer2 = TypeConverter.ToInteger(o2);
        num = integer2 >= 0.0 ? (uint) Math.Min(TypeConverter.ToInteger((JsValue) integer2), (double) uint32) : (uint) Math.Max((double) uint32 + integer2, 0.0);
      }
      int o4 = 0;
      for (; o3 < num; ++o3)
      {
        string propertyName = TypeConverter.ToString((JsValue) (double) o3);
        if (objectInstance1.HasProperty(propertyName))
        {
          JsValue jsValue = objectInstance1.Get(propertyName);
          objectInstance2.DefineOwnProperty(TypeConverter.ToString((JsValue) (double) o4), new PropertyDescriptor(jsValue, new bool?(true), new bool?(true), new bool?(true)), false);
        }
        ++o4;
      }
      return (JsValue) objectInstance2;
    }

    private JsValue Shift(JsValue thisObj, JsValue[] arg2)
    {
      ObjectInstance objectInstance = TypeConverter.ToObject(this.Engine, thisObj);
      uint uint32 = TypeConverter.ToUint32(objectInstance.Get("length"));
      if (uint32 == 0U)
      {
        objectInstance.Put("length", (JsValue) 0.0, true);
        return Undefined.Instance;
      }
      JsValue jsValue1 = objectInstance.Get("0");
      for (int o = 1; (long) o < (long) uint32; ++o)
      {
        string propertyName1 = TypeConverter.ToString((JsValue) (double) o);
        string propertyName2 = TypeConverter.ToString((JsValue) (double) (o - 1));
        if (objectInstance.HasProperty(propertyName1))
        {
          JsValue jsValue2 = objectInstance.Get(propertyName1);
          objectInstance.Put(propertyName2, jsValue2, true);
        }
        else
          objectInstance.Delete(propertyName2, true);
      }
      objectInstance.Delete(TypeConverter.ToString((JsValue) (double) (uint32 - 1U)), true);
      objectInstance.Put("length", (JsValue) (double) (uint32 - 1U), true);
      return jsValue1;
    }

    private JsValue Reverse(JsValue thisObj, JsValue[] arguments)
    {
      ObjectInstance objectInstance = TypeConverter.ToObject(this.Engine, thisObj);
      uint uint32 = TypeConverter.ToUint32(objectInstance.Get("length"));
      uint num = (uint) Math.Floor((double) uint32 / 2.0);
      for (uint o = 0; (int) o != (int) num; ++o)
      {
        string propertyName1 = TypeConverter.ToString((JsValue) (double) (uint) ((int) uint32 - (int) o - 1));
        string propertyName2 = TypeConverter.ToString((JsValue) (double) o);
        JsValue jsValue1 = objectInstance.Get(propertyName2);
        JsValue jsValue2 = objectInstance.Get(propertyName1);
        bool flag1 = objectInstance.HasProperty(propertyName2);
        bool flag2 = objectInstance.HasProperty(propertyName1);
        if (flag1 & flag2)
        {
          objectInstance.Put(propertyName2, jsValue2, true);
          objectInstance.Put(propertyName1, jsValue1, true);
        }
        if (!flag1 & flag2)
        {
          objectInstance.Put(propertyName2, jsValue2, true);
          objectInstance.Delete(propertyName1, true);
        }
        if (flag1 && !flag2)
        {
          objectInstance.Delete(propertyName2, true);
          objectInstance.Put(propertyName1, jsValue1, true);
        }
      }
      return (JsValue) objectInstance;
    }

    private JsValue Join(JsValue thisObj, JsValue[] arguments)
    {
      JsValue o1 = arguments.At(0);
      ObjectInstance objectInstance = TypeConverter.ToObject(this.Engine, thisObj);
      uint uint32 = TypeConverter.ToUint32(objectInstance.Get("length"));
      if (o1 == Undefined.Instance)
        o1 = (JsValue) ",";
      string str1 = TypeConverter.ToString(o1);
      if (uint32 == 0U)
        return (JsValue) "";
      JsValue o2 = objectInstance.Get("0");
      string str2 = o2 == Undefined.Instance || o2 == Null.Instance ? "" : TypeConverter.ToString(o2);
      for (int index = 1; (long) index < (long) uint32; ++index)
      {
        string str3 = str2 + str1;
        JsValue o3 = objectInstance.Get(index.ToString());
        string str4 = o3 == Undefined.Instance || o3 == Null.Instance ? "" : TypeConverter.ToString(o3);
        str2 = str3 + str4;
      }
      return (JsValue) str2;
    }

    private JsValue ToLocaleString(JsValue thisObj, JsValue[] arguments)
    {
      ObjectInstance objectInstance = TypeConverter.ToObject(this.Engine, thisObj);
      uint uint32 = TypeConverter.ToUint32(objectInstance.Get("length"));
      if (uint32 == 0U)
        return (JsValue) "";
      JsValue jsValue1 = objectInstance.Get("0");
      JsValue localeString;
      if (jsValue1 == Null.Instance || jsValue1 == Undefined.Instance)
      {
        localeString = (JsValue) "";
      }
      else
      {
        ObjectInstance thisObject = TypeConverter.ToObject(this.Engine, jsValue1);
        localeString = thisObject.Get("toLocaleString").TryCast<ICallable>((Action<JsValue>) (x =>
        {
          throw new JavaScriptException(this.Engine.TypeError);
        })).Call((JsValue) thisObject, Arguments.Empty);
      }
      for (int index = 1; (long) index < (long) uint32; ++index)
      {
        string str = localeString.ToString() + ",";
        JsValue jsValue2 = objectInstance.Get(index.ToString());
        JsValue jsValue3;
        if (jsValue2 == Undefined.Instance || jsValue2 == Null.Instance)
        {
          jsValue3 = (JsValue) "";
        }
        else
        {
          ObjectInstance thisObject = TypeConverter.ToObject(this.Engine, jsValue2);
          jsValue3 = thisObject.Get("toLocaleString").TryCast<ICallable>((Action<JsValue>) (x =>
          {
            throw new JavaScriptException(this.Engine.TypeError);
          })).Call((JsValue) thisObject, Arguments.Empty);
        }
        JsValue jsValue4 = jsValue3;
        localeString = (JsValue) (str + (object) jsValue4);
      }
      return localeString;
    }

    private JsValue Concat(JsValue thisObj, JsValue[] arguments)
    {
      ObjectInstance objectInstance1 = TypeConverter.ToObject(this.Engine, thisObj);
      ObjectInstance objectInstance2 = this.Engine.Array.Construct(Arguments.Empty);
      int o = 0;
      List<JsValue> jsValueList = new List<JsValue>();
      jsValueList.Add((JsValue) objectInstance1);
      jsValueList.AddRange((IEnumerable<JsValue>) arguments);
      foreach (JsValue jsValue1 in jsValueList)
      {
        ArrayInstance arrayInstance = jsValue1.TryCast<ArrayInstance>();
        if (arrayInstance != null)
        {
          uint uint32 = TypeConverter.ToUint32(arrayInstance.Get("length"));
          for (int index = 0; (long) index < (long) uint32; ++index)
          {
            string propertyName = index.ToString();
            if (arrayInstance.HasProperty(propertyName))
            {
              JsValue jsValue2 = arrayInstance.Get(propertyName);
              objectInstance2.DefineOwnProperty(TypeConverter.ToString((JsValue) (double) o), new PropertyDescriptor(jsValue2, new bool?(true), new bool?(true), new bool?(true)), false);
            }
            ++o;
          }
        }
        else
        {
          objectInstance2.DefineOwnProperty(TypeConverter.ToString((JsValue) (double) o), new PropertyDescriptor(jsValue1, new bool?(true), new bool?(true), new bool?(true)), false);
          ++o;
        }
      }
      objectInstance2.DefineOwnProperty("length", new PropertyDescriptor((JsValue) (double) o, new bool?(), new bool?(), new bool?()), false);
      return (JsValue) objectInstance2;
    }

    private JsValue ToString(JsValue thisObj, JsValue[] arguments)
    {
      ObjectInstance thisObject = TypeConverter.ToObject(this.Engine, thisObj);
      ICallable func = thisObject.Get("join").TryCast<ICallable>((Action<JsValue>) (x => func = this.Engine.Object.PrototypeObject.Get("toString").TryCast<ICallable>((Action<JsValue>) (y =>
      {
        throw new ArgumentException();
      }))));
      return func.Call((JsValue) thisObject, Arguments.Empty);
    }

    private JsValue ReduceRight(JsValue thisObj, JsValue[] arguments)
    {
      JsValue jsValue1 = arguments.At(0);
      JsValue jsValue2 = arguments.At(1);
      ObjectInstance objectInstance = TypeConverter.ToObject(this.Engine, thisObj);
      int uint32 = (int) TypeConverter.ToUint32(objectInstance.Get("length"));
      ICallable callable = jsValue1.TryCast<ICallable>((Action<JsValue>) (x =>
      {
        throw new JavaScriptException(this.Engine.TypeError, "Argument must be callable");
      }));
      if (uint32 == 0 && arguments.Length < 2)
        throw new JavaScriptException(this.Engine.TypeError);
      int num = uint32 - 1;
      JsValue jsValue3 = Undefined.Instance;
      if (arguments.Length > 1)
      {
        jsValue3 = jsValue2;
      }
      else
      {
        bool flag;
        for (flag = false; !flag && num >= 0; --num)
        {
          string propertyName = num.ToString();
          flag = objectInstance.HasProperty(propertyName);
          if (flag)
            jsValue3 = objectInstance.Get(propertyName);
        }
        if (!flag)
          throw new JavaScriptException(this.Engine.TypeError);
      }
      for (; num >= 0; --num)
      {
        string propertyName = num.ToString();
        if (objectInstance.HasProperty(propertyName))
        {
          JsValue jsValue4 = objectInstance.Get(propertyName);
          jsValue3 = callable.Call(Undefined.Instance, new JsValue[4]
          {
            jsValue3,
            jsValue4,
            (JsValue) (double) num,
            (JsValue) objectInstance
          });
        }
      }
      return jsValue3;
    }

    public JsValue Push(JsValue thisObject, JsValue[] arguments)
    {
      ObjectInstance objectInstance = TypeConverter.ToObject(this.Engine, thisObject);
      double uint32 = (double) TypeConverter.ToUint32((JsValue) TypeConverter.ToNumber(objectInstance.Get("length")));
      foreach (JsValue jsValue in arguments)
      {
        objectInstance.Put(TypeConverter.ToString((JsValue) uint32), jsValue, true);
        ++uint32;
      }
      objectInstance.Put("length", (JsValue) uint32, true);
      return (JsValue) uint32;
    }

    public JsValue Pop(JsValue thisObject, JsValue[] arguments)
    {
      ObjectInstance objectInstance = TypeConverter.ToObject(this.Engine, thisObject);
      uint uint32 = TypeConverter.ToUint32((JsValue) TypeConverter.ToNumber(objectInstance.Get("length")));
      if (uint32 == 0U)
      {
        objectInstance.Put("length", (JsValue) 0.0, true);
        return Undefined.Instance;
      }
      uint o = uint32 - 1U;
      string propertyName = TypeConverter.ToString((JsValue) (double) o);
      JsValue jsValue = objectInstance.Get(propertyName);
      objectInstance.Delete(propertyName, true);
      objectInstance.Put("length", (JsValue) (double) o, true);
      return jsValue;
    }
  }
}
