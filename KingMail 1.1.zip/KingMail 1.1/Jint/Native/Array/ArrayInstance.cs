﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Array.ArrayInstance
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Descriptors;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace Jint.Native.Array
{
  public class ArrayInstance : ObjectInstance
  {
    private readonly Engine _engine;
    private IDictionary<uint, PropertyDescriptor> _array = (IDictionary<uint, PropertyDescriptor>) new MruPropertyCache2<uint, PropertyDescriptor>();
    private PropertyDescriptor _length;

    public ArrayInstance(Engine engine)
      : base(engine)
    {
      this._engine = engine;
    }

    public override string Class => "Array";

    public override void Put(string propertyName, JsValue value, bool throwOnError)
    {
      if (!this.CanPut(propertyName))
      {
        if (throwOnError)
          throw new JavaScriptException(this.Engine.TypeError);
      }
      else if (this.GetOwnProperty(propertyName).IsDataDescriptor())
      {
        PropertyDescriptor desc = new PropertyDescriptor(value, new bool?(), new bool?(), new bool?());
        this.DefineOwnProperty(propertyName, desc, throwOnError);
      }
      else
      {
        PropertyDescriptor property = this.GetProperty(propertyName);
        if (property.IsAccessorDescriptor())
        {
          property.Set.TryCast<ICallable>().Call(new JsValue((ObjectInstance) this), new JsValue[1]
          {
            value
          });
        }
        else
        {
          PropertyDescriptor desc = new PropertyDescriptor(value, new bool?(true), new bool?(true), new bool?(true));
          this.DefineOwnProperty(propertyName, desc, throwOnError);
        }
      }
    }

    public override bool DefineOwnProperty(
      string propertyName,
      PropertyDescriptor desc,
      bool throwOnError)
    {
      PropertyDescriptor ownProperty = this.GetOwnProperty("length");
      uint number = (uint) TypeConverter.ToNumber(ownProperty.Value);
      if (propertyName == "length")
      {
        if (desc.Value == (JsValue) null)
          return base.DefineOwnProperty("length", desc, throwOnError);
        PropertyDescriptor propertyDescriptor = new PropertyDescriptor(desc);
        uint uint32 = TypeConverter.ToUint32(desc.Value);
        if ((double) uint32 != TypeConverter.ToNumber(desc.Value))
          throw new JavaScriptException(this._engine.RangeError);
        propertyDescriptor.Value = (JsValue) (double) uint32;
        if (uint32 >= number)
          return base.DefineOwnProperty("length", this._length = propertyDescriptor, throwOnError);
        bool? nullable = ownProperty.Writable;
        if (!nullable.Value)
        {
          if (throwOnError)
            throw new JavaScriptException(this._engine.TypeError);
          return false;
        }
        nullable = propertyDescriptor.Writable;
        bool flag;
        if (nullable.HasValue)
        {
          nullable = propertyDescriptor.Writable;
          if (!nullable.Value)
          {
            flag = false;
            propertyDescriptor.Writable = new bool?(true);
            goto label_15;
          }
        }
        flag = true;
label_15:
        if (!base.DefineOwnProperty("length", this._length = propertyDescriptor, throwOnError))
          return false;
        if ((long) this._array.Count < (long) (number - uint32))
        {
          foreach (uint p in this._array.Keys.ToArray<uint>())
          {
            uint index;
            if (ArrayInstance.IsArrayIndex((JsValue) (double) p, out index) && index >= uint32 && index < number && !this.Delete(p.ToString(), false))
            {
              propertyDescriptor.Value = new JsValue((double) (index + 1U));
              if (!flag)
                propertyDescriptor.Writable = new bool?(false);
              base.DefineOwnProperty("length", this._length = propertyDescriptor, false);
              if (throwOnError)
                throw new JavaScriptException(this._engine.TypeError);
              return false;
            }
          }
        }
        else
        {
          while (uint32 < number)
          {
            --number;
            if (!this.Delete(TypeConverter.ToString((JsValue) (double) number), false))
            {
              propertyDescriptor.Value = (JsValue) (double) (number + 1U);
              if (!flag)
                propertyDescriptor.Writable = new bool?(false);
              base.DefineOwnProperty("length", this._length = propertyDescriptor, false);
              if (throwOnError)
                throw new JavaScriptException(this._engine.TypeError);
              return false;
            }
          }
        }
        if (!flag)
        {
          bool? writable = new bool?(false);
          nullable = new bool?();
          bool? enumerable = nullable;
          nullable = new bool?();
          bool? configurable = nullable;
          this.DefineOwnProperty("length", new PropertyDescriptor((JsValue) null, writable, enumerable, configurable), false);
        }
        return true;
      }
      uint index1;
      if (!ArrayInstance.IsArrayIndex((JsValue) propertyName, out index1))
        return base.DefineOwnProperty(propertyName, desc, throwOnError);
      if (index1 >= number && !ownProperty.Writable.Value)
      {
        if (throwOnError)
          throw new JavaScriptException(this._engine.TypeError);
        return false;
      }
      if (!base.DefineOwnProperty(propertyName, desc, false))
      {
        if (throwOnError)
          throw new JavaScriptException(this._engine.TypeError);
        return false;
      }
      if (index1 >= number)
      {
        ownProperty.Value = (JsValue) (double) (index1 + 1U);
        base.DefineOwnProperty("length", this._length = ownProperty, false);
      }
      return true;
    }

    public uint GetLength() => TypeConverter.ToUint32(this._length.Value);

    public override IEnumerable<KeyValuePair<string, PropertyDescriptor>> GetOwnProperties()
    {
      foreach (KeyValuePair<uint, PropertyDescriptor> keyValuePair in (IEnumerable<KeyValuePair<uint, PropertyDescriptor>>) this._array)
        yield return new KeyValuePair<string, PropertyDescriptor>(keyValuePair.Key.ToString(), keyValuePair.Value);
      foreach (KeyValuePair<string, PropertyDescriptor> ownProperty in base.GetOwnProperties())
        yield return ownProperty;
    }

    public override PropertyDescriptor GetOwnProperty(string propertyName)
    {
      uint index;
      if (!ArrayInstance.IsArrayIndex((JsValue) propertyName, out index))
        return base.GetOwnProperty(propertyName);
      PropertyDescriptor propertyDescriptor;
      return this._array.TryGetValue(index, out propertyDescriptor) ? propertyDescriptor : PropertyDescriptor.Undefined;
    }

    protected override void SetOwnProperty(string propertyName, PropertyDescriptor desc)
    {
      uint index;
      if (ArrayInstance.IsArrayIndex((JsValue) propertyName, out index))
      {
        this._array[index] = desc;
      }
      else
      {
        if (propertyName == "length")
          this._length = desc;
        base.SetOwnProperty(propertyName, desc);
      }
    }

    public override bool HasOwnProperty(string p)
    {
      uint index;
      if (!ArrayInstance.IsArrayIndex((JsValue) p, out index))
        return base.HasOwnProperty(p);
      return index < this.GetLength() && this._array.ContainsKey(index);
    }

    public override void RemoveOwnProperty(string p)
    {
      uint index;
      if (ArrayInstance.IsArrayIndex((JsValue) p, out index))
        this._array.Remove(index);
      base.RemoveOwnProperty(p);
    }

    public static bool IsArrayIndex(JsValue p, out uint index)
    {
      index = ArrayInstance.ParseArrayIndex(TypeConverter.ToString(p));
      return index != uint.MaxValue;
    }

    internal static uint ParseArrayIndex(string p)
    {
      int num1 = (int) p[0] - 48;
      if (num1 < 0 || num1 > 9 || num1 == 0 && p.Length > 1)
        return uint.MaxValue;
      ulong arrayIndex = (ulong) (uint) num1;
      for (int index = 1; index < p.Length; ++index)
      {
        int num2 = (int) p[index] - 48;
        if (num2 < 0 || num2 > 9)
          return uint.MaxValue;
        arrayIndex = arrayIndex * 10UL + (ulong) (uint) num2;
        if (arrayIndex >= (ulong) uint.MaxValue)
          return uint.MaxValue;
      }
      return (uint) arrayIndex;
    }
  }
}
