﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Array.ArrayConstructor
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Function;
using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Environments;
using Jint.Runtime.Interop;
using System;
using System.Collections;

#nullable disable
namespace Jint.Native.Array
{
  public sealed class ArrayConstructor : FunctionInstance, IConstructor
  {
    private ArrayConstructor(Engine engine)
      : base(engine, (string[]) null, (LexicalEnvironment) null, false)
    {
    }

    public ArrayPrototype PrototypeObject { get; private set; }

    public static ArrayConstructor CreateArrayConstructor(Engine engine)
    {
      ArrayConstructor arrayConstructor = new ArrayConstructor(engine);
      arrayConstructor.Extensible = true;
      arrayConstructor.Prototype = (ObjectInstance) engine.Function.PrototypeObject;
      arrayConstructor.PrototypeObject = ArrayPrototype.CreatePrototypeObject(engine, arrayConstructor);
      arrayConstructor.FastAddProperty("length", (JsValue) 1.0, false, false, false);
      arrayConstructor.FastAddProperty("prototype", (JsValue) (ObjectInstance) arrayConstructor.PrototypeObject, false, false, false);
      return arrayConstructor;
    }

    public void Configure()
    {
      this.FastAddProperty("isArray", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.IsArray), 1), true, false, true);
    }

    private JsValue IsArray(JsValue thisObj, JsValue[] arguments)
    {
      if (arguments.Length == 0)
        return (JsValue) false;
      JsValue jsValue = arguments.At(0);
      return (JsValue) (jsValue.IsObject() && jsValue.AsObject().Class == "Array");
    }

    public override JsValue Call(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) this.Construct(arguments);
    }

    public ObjectInstance Construct(JsValue[] arguments)
    {
      ArrayInstance thisObject1 = new ArrayInstance(this.Engine);
      thisObject1.Prototype = (ObjectInstance) this.PrototypeObject;
      thisObject1.Extensible = true;
      if (arguments.Length == 1 && arguments.At(0).IsNumber())
      {
        uint uint32 = TypeConverter.ToUint32(arguments.At(0));
        if (!TypeConverter.ToNumber(arguments[0]).Equals((double) uint32))
          throw new JavaScriptException(this.Engine.RangeError, "Invalid array length");
        thisObject1.FastAddProperty("length", (JsValue) (double) uint32, true, false, false);
      }
      else if (arguments.Length == 1 && arguments.At(0).IsObject() && arguments.At(0).As<ObjectWrapper>() != null)
      {
        if (arguments.At(0).As<ObjectWrapper>().Target is IEnumerable target)
        {
          ObjectInstance thisObject2 = this.Engine.Array.Construct(Arguments.Empty);
          foreach (object obj in target)
          {
            JsValue jsValue = JsValue.FromObject(this.Engine, obj);
            this.Engine.Array.PrototypeObject.Push((JsValue) thisObject2, Arguments.From(jsValue));
          }
          return thisObject2;
        }
      }
      else
      {
        thisObject1.FastAddProperty("length", (JsValue) 0.0, true, false, false);
        this.PrototypeObject.Push((JsValue) (ObjectInstance) thisObject1, arguments);
      }
      return (ObjectInstance) thisObject1;
    }
  }
}
