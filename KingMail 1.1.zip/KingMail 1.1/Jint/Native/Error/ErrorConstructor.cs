﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Error.ErrorConstructor
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Function;
using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Environments;

#nullable disable
namespace Jint.Native.Error
{
  public class ErrorConstructor(Engine engine) : FunctionInstance(engine, (string[]) null, (LexicalEnvironment) null, false), IConstructor
  {
    private string _name;

    public static ErrorConstructor CreateErrorConstructor(Engine engine, string name)
    {
      ErrorConstructor errorConstructor = new ErrorConstructor(engine);
      errorConstructor.Extensible = true;
      errorConstructor._name = name;
      errorConstructor.Prototype = (ObjectInstance) engine.Function.PrototypeObject;
      errorConstructor.PrototypeObject = ErrorPrototype.CreatePrototypeObject(engine, errorConstructor, name);
      errorConstructor.FastAddProperty("length", (JsValue) 1.0, false, false, false);
      errorConstructor.FastAddProperty("prototype", (JsValue) (ObjectInstance) errorConstructor.PrototypeObject, false, false, false);
      return errorConstructor;
    }

    public void Configure()
    {
    }

    public override JsValue Call(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) this.Construct(arguments);
    }

    public ObjectInstance Construct(JsValue[] arguments)
    {
      ErrorInstance errorInstance = new ErrorInstance(this.Engine, this._name);
      errorInstance.Prototype = (ObjectInstance) this.PrototypeObject;
      errorInstance.Extensible = true;
      if (arguments.At(0) != Undefined.Instance)
        errorInstance.Put("message", (JsValue) TypeConverter.ToString(arguments.At(0)), false);
      return (ObjectInstance) errorInstance;
    }

    public ErrorPrototype PrototypeObject { get; private set; }
  }
}
