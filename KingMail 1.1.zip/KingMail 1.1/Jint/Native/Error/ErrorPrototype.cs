﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Error.ErrorPrototype
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Interop;
using System;

#nullable disable
namespace Jint.Native.Error
{
  public sealed class ErrorPrototype : ErrorInstance
  {
    private ErrorPrototype(Engine engine, string name)
      : base(engine, name)
    {
    }

    public static ErrorPrototype CreatePrototypeObject(
      Engine engine,
      ErrorConstructor errorConstructor,
      string name)
    {
      ErrorPrototype errorPrototype = new ErrorPrototype(engine, name);
      errorPrototype.Extensible = true;
      ErrorPrototype prototypeObject = errorPrototype;
      prototypeObject.FastAddProperty("constructor", (JsValue) (ObjectInstance) errorConstructor, true, false, true);
      prototypeObject.FastAddProperty("message", (JsValue) "", true, false, true);
      if (name != "Error")
        prototypeObject.Prototype = (ObjectInstance) engine.Error.PrototypeObject;
      else
        prototypeObject.Prototype = (ObjectInstance) engine.Object.PrototypeObject;
      return prototypeObject;
    }

    public void Configure()
    {
      this.FastAddProperty("toString", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToString)), true, false, true);
    }

    public JsValue ToString(JsValue thisObject, JsValue[] arguments)
    {
      ObjectInstance objectInstance = thisObject.TryCast<ObjectInstance>();
      string str1 = objectInstance != null ? TypeConverter.ToString(objectInstance.Get("name")) : throw new JavaScriptException(this.Engine.TypeError);
      JsValue o = objectInstance.Get("message");
      string str2 = !(o == Undefined.Instance) ? TypeConverter.ToString(o) : "";
      if (str1 == "")
        return (JsValue) str2;
      return str2 == "" ? (JsValue) str1 : (JsValue) (str1 + ": " + str2);
    }
  }
}
