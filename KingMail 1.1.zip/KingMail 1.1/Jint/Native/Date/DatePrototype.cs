﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Date.DatePrototype
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Interop;
using System;
using System.Globalization;

#nullable disable
namespace Jint.Native.Date
{
  public sealed class DatePrototype : DateInstance
  {
    public const double HoursPerDay = 24.0;
    public const double MinutesPerHour = 60.0;
    public const double SecondsPerMinute = 60.0;
    public const double MsPerSecond = 1000.0;
    public const double MsPerMinute = 60000.0;
    public const double MsPerHour = 3600000.0;
    public const double MsPerDay = 86400000.0;

    private DatePrototype(Engine engine)
      : base(engine)
    {
    }

    public static DatePrototype CreatePrototypeObject(
      Engine engine,
      DateConstructor dateConstructor)
    {
      DatePrototype prototypeObject = new DatePrototype(engine);
      prototypeObject.Prototype = (ObjectInstance) engine.Object.PrototypeObject;
      prototypeObject.Extensible = true;
      prototypeObject.PrimitiveValue = double.NaN;
      prototypeObject.FastAddProperty("constructor", (JsValue) (ObjectInstance) dateConstructor, true, false, true);
      return prototypeObject;
    }

    public void Configure()
    {
      this.FastAddProperty("toString", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToString), 0), true, false, true);
      this.FastAddProperty("toDateString", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToDateString), 0), true, false, true);
      this.FastAddProperty("toTimeString", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToTimeString), 0), true, false, true);
      this.FastAddProperty("toLocaleString", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToLocaleString), 0), true, false, true);
      this.FastAddProperty("toLocaleDateString", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToLocaleDateString), 0), true, false, true);
      this.FastAddProperty("toLocaleTimeString", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToLocaleTimeString), 0), true, false, true);
      this.FastAddProperty("valueOf", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ValueOf), 0), true, false, true);
      this.FastAddProperty("getTime", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetTime), 0), true, false, true);
      this.FastAddProperty("getFullYear", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetFullYear), 0), true, false, true);
      this.FastAddProperty("getYear", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetYear), 0), true, false, true);
      this.FastAddProperty("getUTCFullYear", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetUTCFullYear), 0), true, false, true);
      this.FastAddProperty("getMonth", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetMonth), 0), true, false, true);
      this.FastAddProperty("getUTCMonth", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetUTCMonth), 0), true, false, true);
      this.FastAddProperty("getDate", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetDate), 0), true, false, true);
      this.FastAddProperty("getUTCDate", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetUTCDate), 0), true, false, true);
      this.FastAddProperty("getDay", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetDay), 0), true, false, true);
      this.FastAddProperty("getUTCDay", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetUTCDay), 0), true, false, true);
      this.FastAddProperty("getHours", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetHours), 0), true, false, true);
      this.FastAddProperty("getUTCHours", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetUTCHours), 0), true, false, true);
      this.FastAddProperty("getMinutes", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetMinutes), 0), true, false, true);
      this.FastAddProperty("getUTCMinutes", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetUTCMinutes), 0), true, false, true);
      this.FastAddProperty("getSeconds", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetSeconds), 0), true, false, true);
      this.FastAddProperty("getUTCSeconds", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetUTCSeconds), 0), true, false, true);
      this.FastAddProperty("getMilliseconds", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetMilliseconds), 0), true, false, true);
      this.FastAddProperty("getUTCMilliseconds", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetUTCMilliseconds), 0), true, false, true);
      this.FastAddProperty("getTimezoneOffset", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetTimezoneOffset), 0), true, false, true);
      this.FastAddProperty("setTime", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.SetTime), 1), true, false, true);
      this.FastAddProperty("setMilliseconds", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.SetMilliseconds), 1), true, false, true);
      this.FastAddProperty("setUTCMilliseconds", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.SetUTCMilliseconds), 1), true, false, true);
      this.FastAddProperty("setSeconds", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.SetSeconds), 2), true, false, true);
      this.FastAddProperty("setUTCSeconds", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.SetUTCSeconds), 2), true, false, true);
      this.FastAddProperty("setMinutes", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.SetMinutes), 3), true, false, true);
      this.FastAddProperty("setUTCMinutes", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.SetUTCMinutes), 3), true, false, true);
      this.FastAddProperty("setHours", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.SetHours), 4), true, false, true);
      this.FastAddProperty("setUTCHours", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.SetUTCHours), 4), true, false, true);
      this.FastAddProperty("setDate", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.SetDate), 1), true, false, true);
      this.FastAddProperty("setUTCDate", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.SetUTCDate), 1), true, false, true);
      this.FastAddProperty("setMonth", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.SetMonth), 2), true, false, true);
      this.FastAddProperty("setUTCMonth", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.SetUTCMonth), 2), true, false, true);
      this.FastAddProperty("setFullYear", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.SetFullYear), 3), true, false, true);
      this.FastAddProperty("setYear", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.SetYear), 1), true, false, true);
      this.FastAddProperty("setUTCFullYear", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.SetUTCFullYear), 3), true, false, true);
      this.FastAddProperty("toUTCString", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToUtcString), 0), true, false, true);
      this.FastAddProperty("toISOString", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToISOString), 0), true, false, true);
      this.FastAddProperty("toJSON", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToJSON), 1), true, false, true);
    }

    private JsValue ValueOf(JsValue thisObj, JsValue[] arguments)
    {
      return (JsValue) this.EnsureDateInstance(thisObj).PrimitiveValue;
    }

    private DateInstance EnsureDateInstance(JsValue thisObj)
    {
      return thisObj.TryCast<DateInstance>((Action<JsValue>) (value =>
      {
        throw new JavaScriptException(this.Engine.TypeError, "Invalid Date");
      }));
    }

    public JsValue ToString(JsValue thisObj, JsValue[] arg2)
    {
      return (JsValue) this.ToLocalTime(this.EnsureDateInstance(thisObj).ToDateTime()).ToString("ddd MMM dd yyyy HH:mm:ss 'GMT'K", (IFormatProvider) CultureInfo.InvariantCulture);
    }

    private JsValue ToDateString(JsValue thisObj, JsValue[] arguments)
    {
      return (JsValue) this.ToLocalTime(this.EnsureDateInstance(thisObj).ToDateTime()).ToString("ddd MMM dd yyyy", (IFormatProvider) CultureInfo.InvariantCulture);
    }

    private JsValue ToTimeString(JsValue thisObj, JsValue[] arguments)
    {
      return (JsValue) this.ToLocalTime(this.EnsureDateInstance(thisObj).ToDateTime()).ToString("HH:mm:ss 'GMT'K", (IFormatProvider) CultureInfo.InvariantCulture);
    }

    private JsValue ToLocaleString(JsValue thisObj, JsValue[] arguments)
    {
      return (JsValue) this.ToLocalTime(this.EnsureDateInstance(thisObj).ToDateTime()).ToString("F", (IFormatProvider) this.Engine.Options._Culture);
    }

    private JsValue ToLocaleDateString(JsValue thisObj, JsValue[] arguments)
    {
      return (JsValue) this.ToLocalTime(this.EnsureDateInstance(thisObj).ToDateTime()).ToString("D", (IFormatProvider) this.Engine.Options._Culture);
    }

    private JsValue ToLocaleTimeString(JsValue thisObj, JsValue[] arguments)
    {
      return (JsValue) this.ToLocalTime(this.EnsureDateInstance(thisObj).ToDateTime()).ToString("T", (IFormatProvider) this.Engine.Options._Culture);
    }

    private JsValue GetTime(JsValue thisObj, JsValue[] arguments)
    {
      return double.IsNaN(this.EnsureDateInstance(thisObj).PrimitiveValue) ? (JsValue) double.NaN : (JsValue) this.EnsureDateInstance(thisObj).PrimitiveValue;
    }

    private JsValue GetFullYear(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      return double.IsNaN(primitiveValue) ? (JsValue) double.NaN : (JsValue) DatePrototype.YearFromTime(this.LocalTime(primitiveValue));
    }

    private JsValue GetYear(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      return double.IsNaN(primitiveValue) ? (JsValue) double.NaN : (JsValue) (DatePrototype.YearFromTime(this.LocalTime(primitiveValue)) - 1900.0);
    }

    private JsValue GetUTCFullYear(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      return double.IsNaN(primitiveValue) ? (JsValue) double.NaN : (JsValue) DatePrototype.YearFromTime(primitiveValue);
    }

    private JsValue GetMonth(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      return double.IsNaN(primitiveValue) ? (JsValue) double.NaN : (JsValue) DatePrototype.MonthFromTime(this.LocalTime(primitiveValue));
    }

    private JsValue GetUTCMonth(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      return double.IsNaN(primitiveValue) ? (JsValue) double.NaN : (JsValue) DatePrototype.MonthFromTime(primitiveValue);
    }

    private JsValue GetDate(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      return double.IsNaN(primitiveValue) ? (JsValue) double.NaN : (JsValue) DatePrototype.DateFromTime(this.LocalTime(primitiveValue));
    }

    private JsValue GetUTCDate(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      return double.IsNaN(primitiveValue) ? (JsValue) double.NaN : (JsValue) DatePrototype.DateFromTime(primitiveValue);
    }

    private JsValue GetDay(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      return double.IsNaN(primitiveValue) ? (JsValue) double.NaN : (JsValue) DatePrototype.WeekDay(this.LocalTime(primitiveValue));
    }

    private JsValue GetUTCDay(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      return double.IsNaN(primitiveValue) ? (JsValue) double.NaN : (JsValue) DatePrototype.WeekDay(primitiveValue);
    }

    private JsValue GetHours(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      return double.IsNaN(primitiveValue) ? (JsValue) double.NaN : (JsValue) DatePrototype.HourFromTime(this.LocalTime(primitiveValue));
    }

    private JsValue GetUTCHours(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      return double.IsNaN(primitiveValue) ? (JsValue) double.NaN : (JsValue) DatePrototype.HourFromTime(primitiveValue);
    }

    private JsValue GetMinutes(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      return double.IsNaN(primitiveValue) ? (JsValue) double.NaN : (JsValue) DatePrototype.MinFromTime(this.LocalTime(primitiveValue));
    }

    private JsValue GetUTCMinutes(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      return double.IsNaN(primitiveValue) ? (JsValue) double.NaN : (JsValue) DatePrototype.MinFromTime(primitiveValue);
    }

    private JsValue GetSeconds(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = thisObj.TryCast<DateInstance>().PrimitiveValue;
      return double.IsNaN(primitiveValue) ? (JsValue) double.NaN : (JsValue) DatePrototype.SecFromTime(this.LocalTime(primitiveValue));
    }

    private JsValue GetUTCSeconds(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      return double.IsNaN(primitiveValue) ? (JsValue) double.NaN : (JsValue) DatePrototype.SecFromTime(primitiveValue);
    }

    private JsValue GetMilliseconds(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      return double.IsNaN(primitiveValue) ? (JsValue) double.NaN : (JsValue) DatePrototype.MsFromTime(this.LocalTime(primitiveValue));
    }

    private JsValue GetUTCMilliseconds(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      return double.IsNaN(primitiveValue) ? (JsValue) double.NaN : (JsValue) DatePrototype.MsFromTime(primitiveValue);
    }

    private JsValue GetTimezoneOffset(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      return double.IsNaN(primitiveValue) ? (JsValue) double.NaN : (JsValue) ((primitiveValue - this.LocalTime(primitiveValue)) / 60000.0);
    }

    private JsValue SetTime(JsValue thisObj, JsValue[] arguments)
    {
      return (JsValue) (this.EnsureDateInstance(thisObj).PrimitiveValue = DatePrototype.TimeClip(TypeConverter.ToNumber(arguments.At(0))));
    }

    private JsValue SetMilliseconds(JsValue thisObj, JsValue[] arguments)
    {
      double t = this.LocalTime(this.EnsureDateInstance(thisObj).PrimitiveValue);
      double time = DatePrototype.MakeTime(DatePrototype.HourFromTime(t), DatePrototype.MinFromTime(t), DatePrototype.SecFromTime(t), TypeConverter.ToNumber(arguments.At(0)));
      double num = DatePrototype.TimeClip(this.Utc(DatePrototype.MakeDate(DatePrototype.Day(t), time)));
      thisObj.As<DateInstance>().PrimitiveValue = num;
      return (JsValue) num;
    }

    private JsValue SetUTCMilliseconds(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      double time = DatePrototype.MakeTime(DatePrototype.HourFromTime(primitiveValue), DatePrototype.MinFromTime(primitiveValue), DatePrototype.SecFromTime(primitiveValue), TypeConverter.ToNumber(arguments.At(0)));
      double num = DatePrototype.TimeClip(DatePrototype.MakeDate(DatePrototype.Day(primitiveValue), time));
      thisObj.As<DateInstance>().PrimitiveValue = num;
      return (JsValue) num;
    }

    private JsValue SetSeconds(JsValue thisObj, JsValue[] arguments)
    {
      double t = this.LocalTime(this.EnsureDateInstance(thisObj).PrimitiveValue);
      double number = TypeConverter.ToNumber(arguments.At(0));
      double ms = arguments.Length <= 1 ? DatePrototype.MsFromTime(t) : TypeConverter.ToNumber(arguments.At(1));
      double num = DatePrototype.TimeClip(this.Utc(DatePrototype.MakeDate(DatePrototype.Day(t), DatePrototype.MakeTime(DatePrototype.HourFromTime(t), DatePrototype.MinFromTime(t), number, ms))));
      thisObj.As<DateInstance>().PrimitiveValue = num;
      return (JsValue) num;
    }

    private JsValue SetUTCSeconds(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      double number = TypeConverter.ToNumber(arguments.At(0));
      double ms = arguments.Length <= 1 ? DatePrototype.MsFromTime(primitiveValue) : TypeConverter.ToNumber(arguments.At(1));
      double num = DatePrototype.TimeClip(DatePrototype.MakeDate(DatePrototype.Day(primitiveValue), DatePrototype.MakeTime(DatePrototype.HourFromTime(primitiveValue), DatePrototype.MinFromTime(primitiveValue), number, ms)));
      thisObj.As<DateInstance>().PrimitiveValue = num;
      return (JsValue) num;
    }

    private JsValue SetMinutes(JsValue thisObj, JsValue[] arguments)
    {
      double t = this.LocalTime(this.EnsureDateInstance(thisObj).PrimitiveValue);
      double number = TypeConverter.ToNumber(arguments.At(0));
      double sec = arguments.Length <= 1 ? DatePrototype.SecFromTime(t) : TypeConverter.ToNumber(arguments.At(1));
      double ms = arguments.Length <= 2 ? DatePrototype.MsFromTime(t) : TypeConverter.ToNumber(arguments.At(2));
      double num = DatePrototype.TimeClip(this.Utc(DatePrototype.MakeDate(DatePrototype.Day(t), DatePrototype.MakeTime(DatePrototype.HourFromTime(t), number, sec, ms))));
      thisObj.As<DateInstance>().PrimitiveValue = num;
      return (JsValue) num;
    }

    private JsValue SetUTCMinutes(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      double number = TypeConverter.ToNumber(arguments.At(0));
      double sec = arguments.Length <= 1 ? DatePrototype.SecFromTime(primitiveValue) : TypeConverter.ToNumber(arguments.At(1));
      double ms = arguments.Length <= 2 ? DatePrototype.MsFromTime(primitiveValue) : TypeConverter.ToNumber(arguments.At(2));
      double num = DatePrototype.TimeClip(DatePrototype.MakeDate(DatePrototype.Day(primitiveValue), DatePrototype.MakeTime(DatePrototype.HourFromTime(primitiveValue), number, sec, ms)));
      thisObj.As<DateInstance>().PrimitiveValue = num;
      return (JsValue) num;
    }

    private JsValue SetHours(JsValue thisObj, JsValue[] arguments)
    {
      double t = this.LocalTime(this.EnsureDateInstance(thisObj).PrimitiveValue);
      double number = TypeConverter.ToNumber(arguments.At(0));
      double min = arguments.Length <= 1 ? DatePrototype.MinFromTime(t) : TypeConverter.ToNumber(arguments.At(1));
      double sec = arguments.Length <= 2 ? DatePrototype.SecFromTime(t) : TypeConverter.ToNumber(arguments.At(2));
      double ms = arguments.Length <= 3 ? DatePrototype.MsFromTime(t) : TypeConverter.ToNumber(arguments.At(3));
      double num = DatePrototype.TimeClip(this.Utc(DatePrototype.MakeDate(DatePrototype.Day(t), DatePrototype.MakeTime(number, min, sec, ms))));
      thisObj.As<DateInstance>().PrimitiveValue = num;
      return (JsValue) num;
    }

    private JsValue SetUTCHours(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      double number = TypeConverter.ToNumber(arguments.At(0));
      double min = arguments.Length <= 1 ? DatePrototype.MinFromTime(primitiveValue) : TypeConverter.ToNumber(arguments.At(1));
      double sec = arguments.Length <= 2 ? DatePrototype.SecFromTime(primitiveValue) : TypeConverter.ToNumber(arguments.At(2));
      double ms = arguments.Length <= 3 ? DatePrototype.MsFromTime(primitiveValue) : TypeConverter.ToNumber(arguments.At(3));
      double num = DatePrototype.TimeClip(DatePrototype.MakeDate(DatePrototype.Day(primitiveValue), DatePrototype.MakeTime(number, min, sec, ms)));
      thisObj.As<DateInstance>().PrimitiveValue = num;
      return (JsValue) num;
    }

    private JsValue SetDate(JsValue thisObj, JsValue[] arguments)
    {
      double t = this.LocalTime(this.EnsureDateInstance(thisObj).PrimitiveValue);
      double number = TypeConverter.ToNumber(arguments.At(0));
      double num = DatePrototype.TimeClip(this.Utc(DatePrototype.MakeDate(DatePrototype.MakeDay(DatePrototype.YearFromTime(t), DatePrototype.MonthFromTime(t), number), DatePrototype.TimeWithinDay(t))));
      thisObj.As<DateInstance>().PrimitiveValue = num;
      return (JsValue) num;
    }

    private JsValue SetUTCDate(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      double number = TypeConverter.ToNumber(arguments.At(0));
      double num = DatePrototype.TimeClip(DatePrototype.MakeDate(DatePrototype.MakeDay(DatePrototype.YearFromTime(primitiveValue), DatePrototype.MonthFromTime(primitiveValue), number), DatePrototype.TimeWithinDay(primitiveValue)));
      thisObj.As<DateInstance>().PrimitiveValue = num;
      return (JsValue) num;
    }

    private JsValue SetMonth(JsValue thisObj, JsValue[] arguments)
    {
      double t = this.LocalTime(this.EnsureDateInstance(thisObj).PrimitiveValue);
      double number = TypeConverter.ToNumber(arguments.At(0));
      double date = arguments.Length <= 1 ? DatePrototype.DateFromTime(t) : TypeConverter.ToNumber(arguments.At(1));
      double num = DatePrototype.TimeClip(this.Utc(DatePrototype.MakeDate(DatePrototype.MakeDay(DatePrototype.YearFromTime(t), number, date), DatePrototype.TimeWithinDay(t))));
      thisObj.As<DateInstance>().PrimitiveValue = num;
      return (JsValue) num;
    }

    private JsValue SetUTCMonth(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      double number = TypeConverter.ToNumber(arguments.At(0));
      double date = arguments.Length <= 1 ? DatePrototype.DateFromTime(primitiveValue) : TypeConverter.ToNumber(arguments.At(1));
      double num = DatePrototype.TimeClip(DatePrototype.MakeDate(DatePrototype.MakeDay(DatePrototype.YearFromTime(primitiveValue), number, date), DatePrototype.TimeWithinDay(primitiveValue)));
      thisObj.As<DateInstance>().PrimitiveValue = num;
      return (JsValue) num;
    }

    private JsValue SetFullYear(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      double t = double.IsNaN(primitiveValue) ? 0.0 : this.LocalTime(primitiveValue);
      double number = TypeConverter.ToNumber(arguments.At(0));
      double num1 = arguments.Length <= 1 ? DatePrototype.MonthFromTime(t) : TypeConverter.ToNumber(arguments.At(1));
      double num2 = arguments.Length <= 2 ? DatePrototype.DateFromTime(t) : TypeConverter.ToNumber(arguments.At(2));
      double month = num1;
      double date = num2;
      double num3 = DatePrototype.TimeClip(this.Utc(DatePrototype.MakeDate(DatePrototype.MakeDay(number, month, date), DatePrototype.TimeWithinDay(t))));
      thisObj.As<DateInstance>().PrimitiveValue = num3;
      return (JsValue) num3;
    }

    private JsValue SetYear(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      double t = double.IsNaN(primitiveValue) ? 0.0 : this.LocalTime(primitiveValue);
      double number = TypeConverter.ToNumber(arguments.At(0));
      if (double.IsNaN(number))
      {
        this.EnsureDateInstance(thisObj).PrimitiveValue = double.NaN;
        return (JsValue) double.NaN;
      }
      double integer = TypeConverter.ToInteger((JsValue) number);
      if (number >= 0.0 && number <= 99.0)
        integer += 1900.0;
      double time = this.Utc(DatePrototype.MakeDate(DatePrototype.MakeDay(integer, DatePrototype.MonthFromTime(t), DatePrototype.DateFromTime(t)), DatePrototype.TimeWithinDay(t)));
      this.EnsureDateInstance(thisObj).PrimitiveValue = DatePrototype.TimeClip(time);
      return (JsValue) time;
    }

    private JsValue SetUTCFullYear(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = this.EnsureDateInstance(thisObj).PrimitiveValue;
      double t = double.IsNaN(primitiveValue) ? 0.0 : primitiveValue;
      double number = TypeConverter.ToNumber(arguments.At(0));
      double num1 = arguments.Length <= 1 ? DatePrototype.MonthFromTime(t) : TypeConverter.ToNumber(arguments.At(1));
      double num2 = arguments.Length <= 2 ? DatePrototype.DateFromTime(t) : TypeConverter.ToNumber(arguments.At(2));
      double month = num1;
      double date = num2;
      double num3 = DatePrototype.TimeClip(DatePrototype.MakeDate(DatePrototype.MakeDay(number, month, date), DatePrototype.TimeWithinDay(t)));
      thisObj.As<DateInstance>().PrimitiveValue = num3;
      return (JsValue) num3;
    }

    private JsValue ToUtcString(JsValue thisObj, JsValue[] arguments)
    {
      DateTime dateTime = thisObj.TryCast<DateInstance>((Action<JsValue>) (x =>
      {
        throw new JavaScriptException(this.Engine.TypeError);
      })).ToDateTime();
      dateTime = dateTime.ToUniversalTime();
      return (JsValue) dateTime.ToString("ddd MMM dd yyyy HH:mm:ss 'GMT'", (IFormatProvider) CultureInfo.InvariantCulture);
    }

    private JsValue ToISOString(JsValue thisObj, JsValue[] arguments)
    {
      double primitiveValue = thisObj.TryCast<DateInstance>((Action<JsValue>) (x =>
      {
        throw new JavaScriptException(this.Engine.TypeError);
      })).PrimitiveValue;
      double num1 = !double.IsInfinity(primitiveValue) && !double.IsNaN(primitiveValue) ? DatePrototype.HourFromTime(primitiveValue) : throw new JavaScriptException(this.Engine.RangeError);
      double num2 = DatePrototype.MinFromTime(primitiveValue);
      double num3 = DatePrototype.SecFromTime(primitiveValue);
      double num4 = DatePrototype.MsFromTime(primitiveValue);
      if (num1 < 0.0)
        num1 += 24.0;
      if (num2 < 0.0)
        num2 += 60.0;
      if (num3 < 0.0)
        num3 += 60.0;
      if (num4 < 0.0)
        num4 += 1000.0;
      return (JsValue) string.Format("{0:0000}-{1:00}-{2:00}T{3:00}:{4:00}:{5:00}.{6:000}Z", (object) DatePrototype.YearFromTime(primitiveValue), (object) (DatePrototype.MonthFromTime(primitiveValue) + 1.0), (object) DatePrototype.DateFromTime(primitiveValue), (object) num1, (object) num2, (object) num3, (object) num4);
    }

    private JsValue ToJSON(JsValue thisObj, JsValue[] arguments)
    {
      ObjectInstance objectInstance = TypeConverter.ToObject(this.Engine, thisObj);
      JsValue primitive = TypeConverter.ToPrimitive((JsValue) objectInstance, Types.Number);
      if (primitive.IsNumber() && double.IsInfinity(primitive.AsNumber()))
        return JsValue.Null;
      JsValue jsValue = objectInstance.Get("toISOString");
      if (!jsValue.Is<ICallable>())
        throw new JavaScriptException(this.Engine.TypeError);
      return jsValue.TryCast<ICallable>().Call((JsValue) objectInstance, Arguments.Empty);
    }

    public static double Day(double t) => Math.Floor(t / 86400000.0);

    public static double TimeWithinDay(double t)
    {
      return t < 0.0 ? t % 86400000.0 + 86400000.0 : t % 86400000.0;
    }

    public static double DaysInYear(double y)
    {
      return !(y % 4.0).Equals(0.0) || (!(y % 4.0).Equals(0.0) || (y % 100.0).Equals(0.0)) && ((y % 100.0).Equals(0.0) && !(y % 400.0).Equals(0.0) || !(y % 400.0).Equals(0.0)) ? 365.0 : 366.0;
    }

    public static double DayFromYear(double y)
    {
      return 365.0 * (y - 1970.0) + Math.Floor((y - 1969.0) / 4.0) - Math.Floor((y - 1901.0) / 100.0) + Math.Floor((y - 1601.0) / 400.0);
    }

    public static double TimeFromYear(double y) => 86400000.0 * DatePrototype.DayFromYear(y);

    public static double YearFromTime(double t)
    {
      if (!DatePrototype.AreFinite(t))
        return double.NaN;
      int num1 = t < 0.0 ? -1 : 1;
      int y = num1 < 0 ? 1969 : 1970;
      double num2 = t;
      while (true)
      {
        double num3 = DatePrototype.DaysInYear((double) y) * 86400000.0;
        num2 -= (double) num1 * num3;
        if (num1 < 0)
        {
          if ((double) num1 * num2 > 0.0)
            y += num1;
          else
            break;
        }
        else if ((double) num1 * num2 >= 0.0)
          y += num1;
        else
          break;
      }
      return (double) y;
    }

    public static double InLeapYear(double t)
    {
      double num = DatePrototype.DaysInYear(DatePrototype.YearFromTime(t));
      if (num.Equals(365.0))
        return 0.0;
      if (num.Equals(366.0))
        return 1.0;
      throw new ArgumentException();
    }

    public static double MonthFromTime(double t)
    {
      double num1 = DatePrototype.DayWithinYear(t);
      double num2 = DatePrototype.InLeapYear(t);
      if (num1 < 31.0)
        return 0.0;
      if (num1 < 59.0 + num2)
        return 1.0;
      if (num1 < 90.0 + num2)
        return 2.0;
      if (num1 < 120.0 + num2)
        return 3.0;
      if (num1 < 151.0 + num2)
        return 4.0;
      if (num1 < 181.0 + num2)
        return 5.0;
      if (num1 < 212.0 + num2)
        return 6.0;
      if (num1 < 243.0 + num2)
        return 7.0;
      if (num1 < 273.0 + num2)
        return 8.0;
      if (num1 < 304.0 + num2)
        return 9.0;
      if (num1 < 334.0 + num2)
        return 10.0;
      if (num1 < 365.0 + num2)
        return 11.0;
      throw new InvalidOperationException();
    }

    public static double DayWithinYear(double t)
    {
      return DatePrototype.Day(t) - DatePrototype.DayFromYear(DatePrototype.YearFromTime(t));
    }

    public static double DateFromTime(double t)
    {
      double num1 = DatePrototype.MonthFromTime(t);
      double num2 = DatePrototype.DayWithinYear(t);
      if (num1.Equals(0.0))
        return num2 + 1.0;
      if (num1.Equals(1.0))
        return num2 - 30.0;
      if (num1.Equals(2.0))
        return num2 - 58.0 - DatePrototype.InLeapYear(t);
      if (num1.Equals(3.0))
        return num2 - 89.0 - DatePrototype.InLeapYear(t);
      if (num1.Equals(4.0))
        return num2 - 119.0 - DatePrototype.InLeapYear(t);
      if (num1.Equals(5.0))
        return num2 - 150.0 - DatePrototype.InLeapYear(t);
      if (num1.Equals(6.0))
        return num2 - 180.0 - DatePrototype.InLeapYear(t);
      if (num1.Equals(7.0))
        return num2 - 211.0 - DatePrototype.InLeapYear(t);
      if (num1.Equals(8.0))
        return num2 - 242.0 - DatePrototype.InLeapYear(t);
      if (num1.Equals(9.0))
        return num2 - 272.0 - DatePrototype.InLeapYear(t);
      if (num1.Equals(10.0))
        return num2 - 303.0 - DatePrototype.InLeapYear(t);
      if (num1.Equals(11.0))
        return num2 - 333.0 - DatePrototype.InLeapYear(t);
      throw new InvalidOperationException();
    }

    public static double WeekDay(double t) => (DatePrototype.Day(t) + 4.0) % 7.0;

    public double LocalTza => this.Engine.Options._LocalTimeZone.BaseUtcOffset.TotalMilliseconds;

    public double DaylightSavingTa(double t)
    {
      double d = t - DatePrototype.TimeFromYear(DatePrototype.YearFromTime(t));
      if (double.IsInfinity(d) || double.IsNaN(d))
        return 0.0;
      double year = DatePrototype.YearFromTime(t);
      if (year >= 9999.0 || year <= -9999.0)
        year = DatePrototype.InLeapYear(t).Equals(1.0) ? 2000.0 : 1999.0;
      return !this.Engine.Options._LocalTimeZone.IsDaylightSavingTime(new DateTime((int) year, 1, 1).AddMilliseconds(d)) ? 0.0 : 3600000.0;
    }

    public DateTimeOffset ToLocalTime(DateTime t)
    {
      switch (t.Kind)
      {
        case DateTimeKind.Utc:
          return new DateTimeOffset(TimeZoneInfo.ConvertTime(t, this.Engine.Options._LocalTimeZone), this.Engine.Options._LocalTimeZone.GetUtcOffset(t));
        case DateTimeKind.Local:
          return new DateTimeOffset(TimeZoneInfo.ConvertTime(t.ToUniversalTime(), this.Engine.Options._LocalTimeZone), this.Engine.Options._LocalTimeZone.GetUtcOffset(t));
        default:
          return (DateTimeOffset) t;
      }
    }

    public double LocalTime(double t) => t + this.LocalTza + this.DaylightSavingTa(t);

    public double Utc(double t) => t - this.LocalTza - this.DaylightSavingTa(t - this.LocalTza);

    public static double HourFromTime(double t)
    {
      double num = Math.Floor(t / 3600000.0) % 24.0;
      if (num < 0.0)
        num += 24.0;
      return num;
    }

    public static double MinFromTime(double t)
    {
      double num = Math.Floor(t / 60000.0) % 60.0;
      if (num < 0.0)
        num += 60.0;
      return num;
    }

    public static double SecFromTime(double t)
    {
      double num = Math.Floor(t / 1000.0) % 60.0;
      if (num < 0.0)
        num += 60.0;
      return num;
    }

    public static double MsFromTime(double t)
    {
      double num = t % 1000.0;
      if (num < 0.0)
        num += 1000.0;
      return num;
    }

    public static double DayFromMonth(double year, double month)
    {
      double num1 = month * 30.0;
      double num2 = month < 7.0 ? (month < 2.0 ? num1 + month : num1 + ((month - 1.0) / 2.0 - 1.0)) : num1 + (month / 2.0 - 1.0);
      if (month >= 2.0 && DatePrototype.InLeapYear(year).Equals(1.0))
        ++num2;
      return num2;
    }

    public static double DaysInMonth(double month, double leap)
    {
      month %= 12.0;
      long num = (long) month;
      if ((ulong) num <= 11UL)
      {
        switch ((uint) num)
        {
          case 0:
          case 2:
          case 4:
          case 6:
          case 7:
          case 9:
          case 11:
            return 31.0;
          case 1:
            return 28.0 + leap;
          case 3:
          case 5:
          case 8:
          case 10:
            return 30.0;
        }
      }
      throw new ArgumentOutOfRangeException(nameof (month));
    }

    public static double MakeTime(double hour, double min, double sec, double ms)
    {
      return !DatePrototype.AreFinite(hour, min, sec, ms) ? double.NaN : (double) (long) hour * 3600000.0 + (double) (long) min * 60000.0 + (double) (long) sec * 1000.0 + (double) (long) ms;
    }

    public static double MakeDay(double year, double month, double date)
    {
      if (!DatePrototype.AreFinite(year, month, date))
        return double.NaN;
      year = TypeConverter.ToInteger((JsValue) year);
      month = TypeConverter.ToInteger((JsValue) month);
      date = TypeConverter.ToInteger((JsValue) date);
      int num = year < 1970.0 ? -1 : 1;
      double t = year < 1970.0 ? 1.0 : 0.0;
      if (num == -1)
      {
        for (int y = 1969; (double) y >= year; y += num)
          t += (double) num * DatePrototype.DaysInYear((double) y) * 86400000.0;
      }
      else
      {
        for (int y = 1970; (double) y < year; y += num)
          t += (double) num * DatePrototype.DaysInYear((double) y) * 86400000.0;
      }
      for (int month1 = 0; (double) month1 < month; ++month1)
        t += DatePrototype.DaysInMonth((double) month1, DatePrototype.InLeapYear(t)) * 86400000.0;
      return DatePrototype.Day(t) + date - 1.0;
    }

    public static double MakeDate(double day, double time)
    {
      return !DatePrototype.AreFinite(day, time) ? double.NaN : day * 86400000.0 + time;
    }

    public static double TimeClip(double time)
    {
      return !DatePrototype.AreFinite(time) || Math.Abs(time) > 8.64E+15 ? double.NaN : (double) (long) time;
    }

    private static bool AreFinite(params double[] values)
    {
      for (int index = 0; index < values.Length; ++index)
      {
        double d = values[index];
        if (double.IsNaN(d) || double.IsInfinity(d))
          return false;
      }
      return true;
    }
  }
}
