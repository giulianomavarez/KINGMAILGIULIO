﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Date.DateConstructor
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Function;
using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Environments;
using Jint.Runtime.Interop;
using System;
using System.Globalization;

#nullable disable
namespace Jint.Native.Date
{
  public sealed class DateConstructor(Engine engine) : FunctionInstance(engine, (string[]) null, (LexicalEnvironment) null, false), IConstructor
  {
    internal static readonly DateTime Epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);

    public static DateConstructor CreateDateConstructor(Engine engine)
    {
      DateConstructor dateConstructor = new DateConstructor(engine);
      dateConstructor.Extensible = true;
      dateConstructor.Prototype = (ObjectInstance) engine.Function.PrototypeObject;
      dateConstructor.PrototypeObject = DatePrototype.CreatePrototypeObject(engine, dateConstructor);
      dateConstructor.FastAddProperty("length", (JsValue) 7.0, false, false, false);
      dateConstructor.FastAddProperty("prototype", (JsValue) (ObjectInstance) dateConstructor.PrototypeObject, false, false, false);
      return dateConstructor;
    }

    public void Configure()
    {
      this.FastAddProperty("parse", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Parse), 1), true, false, true);
      this.FastAddProperty("UTC", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Utc), 7), true, false, true);
      this.FastAddProperty("now", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Now), 0), true, false, true);
    }

    private JsValue Parse(JsValue thisObj, JsValue[] arguments)
    {
      string s = TypeConverter.ToString(arguments.At(0));
      DateTime result;
      if (!DateTime.TryParseExact(s, new string[6]
      {
        "yyyy-MM-ddTHH:mm:ss.FFF",
        "yyyy-MM-ddTHH:mm:ss",
        "yyyy-MM-ddTHH:mm",
        "yyyy-MM-dd",
        "yyyy-MM",
        "yyyy"
      }, (IFormatProvider) CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal, out result))
      {
        if (!DateTime.TryParseExact(s, new string[24]
        {
          "ddd MMM dd yyyy HH:mm:ss 'GMT'K",
          "ddd MMM dd yyyy",
          "HH:mm:ss 'GMT'K",
          "yyyy-M-dTH:m:s.FFFK",
          "yyyy/M/dTH:m:s.FFFK",
          "yyyy-M-dTH:m:sK",
          "yyyy/M/dTH:m:sK",
          "yyyy-M-dTH:mK",
          "yyyy/M/dTH:mK",
          "yyyy-M-d H:m:s.FFFK",
          "yyyy/M/d H:m:s.FFFK",
          "yyyy-M-d H:m:sK",
          "yyyy/M/d H:m:sK",
          "yyyy-M-d H:mK",
          "yyyy/M/d H:mK",
          "yyyy-M-dK",
          "yyyy/M/dK",
          "yyyy-MK",
          "yyyy/MK",
          "yyyyK",
          "THH:mm:ss.FFFK",
          "THH:mm:ssK",
          "THH:mmK",
          "THHK"
        }, (IFormatProvider) CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal, out result) && !DateTime.TryParse(s, (IFormatProvider) this.Engine.Options._Culture, DateTimeStyles.AdjustToUniversal, out result) && !DateTime.TryParse(s, (IFormatProvider) CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal, out result))
          return (JsValue) double.NaN;
      }
      return (JsValue) this.FromDateTime(result);
    }

    private JsValue Utc(JsValue thisObj, JsValue[] arguments)
    {
      return (JsValue) DateConstructor.TimeClip(this.ConstructTimeValue(arguments, true));
    }

    private JsValue Now(JsValue thisObj, JsValue[] arguments)
    {
      return (JsValue) Math.Floor((DateTime.UtcNow - DateConstructor.Epoch).TotalMilliseconds);
    }

    public override JsValue Call(JsValue thisObject, JsValue[] arguments)
    {
      return this.PrototypeObject.ToString((JsValue) this.Construct(Arguments.Empty), Arguments.Empty);
    }

    public ObjectInstance Construct(JsValue[] arguments)
    {
      if (arguments.Length == 0)
        return (ObjectInstance) this.Construct(DateTime.UtcNow);
      if (arguments.Length != 1)
        return (ObjectInstance) this.Construct(this.ConstructTimeValue(arguments, false));
      JsValue primitive = TypeConverter.ToPrimitive(arguments[0]);
      if (!primitive.IsString())
        return (ObjectInstance) this.Construct(TypeConverter.ToNumber(primitive));
      return (ObjectInstance) this.Construct(this.Parse(Undefined.Instance, Arguments.From(primitive)).AsNumber());
    }

    private double ConstructTimeValue(JsValue[] arguments, bool useUtc)
    {
      double num = arguments.Length >= 2 ? TypeConverter.ToNumber(arguments[0]) : throw new ArgumentOutOfRangeException(nameof (arguments), "There must be at least two arguments.");
      int integer1 = (int) TypeConverter.ToInteger(arguments[1]);
      int date = arguments.Length > 2 ? (int) TypeConverter.ToInteger(arguments[2]) : 1;
      int integer2 = arguments.Length > 3 ? (int) TypeConverter.ToInteger(arguments[3]) : 0;
      int integer3 = arguments.Length > 4 ? (int) TypeConverter.ToInteger(arguments[4]) : 0;
      int integer4 = arguments.Length > 5 ? (int) TypeConverter.ToInteger(arguments[5]) : 0;
      int integer5 = arguments.Length > 6 ? (int) TypeConverter.ToInteger(arguments[6]) : 0;
      for (int index = 2; index < arguments.Length; ++index)
      {
        if (double.IsNaN(TypeConverter.ToNumber(arguments[index])))
          return double.NaN;
      }
      if (!double.IsNaN(num) && 0.0 <= TypeConverter.ToInteger((JsValue) num) && TypeConverter.ToInteger((JsValue) num) <= 99.0)
        num += 1900.0;
      double t = DatePrototype.MakeDate(DatePrototype.MakeDay(num, (double) integer1, (double) date), DatePrototype.MakeTime((double) integer2, (double) integer3, (double) integer4, (double) integer5));
      return DateConstructor.TimeClip(useUtc ? t : this.PrototypeObject.Utc(t));
    }

    public DatePrototype PrototypeObject { get; private set; }

    public DateInstance Construct(DateTimeOffset value) => this.Construct(value.UtcDateTime);

    public DateInstance Construct(DateTime value)
    {
      DateInstance dateInstance = new DateInstance(this.Engine);
      dateInstance.Prototype = (ObjectInstance) this.PrototypeObject;
      dateInstance.PrimitiveValue = this.FromDateTime(value);
      dateInstance.Extensible = true;
      return dateInstance;
    }

    public DateInstance Construct(double time)
    {
      DateInstance dateInstance = new DateInstance(this.Engine);
      dateInstance.Prototype = (ObjectInstance) this.PrototypeObject;
      dateInstance.PrimitiveValue = DateConstructor.TimeClip(time);
      dateInstance.Extensible = true;
      return dateInstance;
    }

    public static double TimeClip(double time)
    {
      return double.IsInfinity(time) || double.IsNaN(time) || Math.Abs(time) > 8.64E+15 ? double.NaN : TypeConverter.ToInteger((JsValue) time);
    }

    public double FromDateTime(DateTime dt)
    {
      int num1 = dt.Kind == DateTimeKind.Unspecified ? 1 : 0;
      double num2 = ((dt.Kind == DateTimeKind.Local ? dt.ToUniversalTime() : DateTime.SpecifyKind(dt, DateTimeKind.Utc)) - DateConstructor.Epoch).TotalMilliseconds;
      if (num1 != 0)
        num2 = this.PrototypeObject.Utc(num2);
      return Math.Floor(num2);
    }
  }
}
