﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Date.DateInstance
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Object;
using Jint.Runtime;
using System;

#nullable disable
namespace Jint.Native.Date
{
  public class DateInstance(Engine engine) : ObjectInstance(engine)
  {
    internal static readonly double Max = (DateTime.MaxValue - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds;
    internal static readonly double Min = -(new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc) - DateTime.MinValue).TotalMilliseconds;

    public override string Class => "Date";

    public DateTime ToDateTime()
    {
      if (double.IsNaN(this.PrimitiveValue) || this.PrimitiveValue > DateInstance.Max || this.PrimitiveValue < DateInstance.Min)
        throw new JavaScriptException(this.Engine.RangeError);
      return DateConstructor.Epoch.AddMilliseconds(this.PrimitiveValue);
    }

    public double PrimitiveValue { get; set; }
  }
}
