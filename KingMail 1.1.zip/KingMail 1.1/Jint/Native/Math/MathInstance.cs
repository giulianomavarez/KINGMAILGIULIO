﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Math.MathInstance
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Number;
using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Interop;
using System;

#nullable disable
namespace Jint.Native.Math
{
  public sealed class MathInstance : ObjectInstance
  {
    private static System.Random _random = new System.Random();

    private MathInstance(Engine engine)
      : base(engine)
    {
    }

    public override string Class => "Math";

    public static MathInstance CreateMathObject(Engine engine)
    {
      MathInstance mathObject = new MathInstance(engine);
      mathObject.Extensible = true;
      mathObject.Prototype = (ObjectInstance) engine.Object.PrototypeObject;
      return mathObject;
    }

    public void Configure()
    {
      this.FastAddProperty("abs", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(MathInstance.Abs)), true, false, true);
      this.FastAddProperty("acos", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(MathInstance.Acos)), true, false, true);
      this.FastAddProperty("asin", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(MathInstance.Asin)), true, false, true);
      this.FastAddProperty("atan", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(MathInstance.Atan)), true, false, true);
      this.FastAddProperty("atan2", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(MathInstance.Atan2)), true, false, true);
      this.FastAddProperty("ceil", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(MathInstance.Ceil)), true, false, true);
      this.FastAddProperty("cos", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(MathInstance.Cos)), true, false, true);
      this.FastAddProperty("exp", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(MathInstance.Exp)), true, false, true);
      this.FastAddProperty("floor", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(MathInstance.Floor)), true, false, true);
      this.FastAddProperty("log", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(MathInstance.Log)), true, false, true);
      this.FastAddProperty("max", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(MathInstance.Max), 2), true, false, true);
      this.FastAddProperty("min", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(MathInstance.Min), 2), true, false, true);
      this.FastAddProperty("pow", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(MathInstance.Pow), 2), true, false, true);
      this.FastAddProperty("random", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(MathInstance.Random)), true, false, true);
      this.FastAddProperty("round", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(MathInstance.Round)), true, false, true);
      this.FastAddProperty("sin", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(MathInstance.Sin)), true, false, true);
      this.FastAddProperty("sqrt", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(MathInstance.Sqrt)), true, false, true);
      this.FastAddProperty("tan", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(MathInstance.Tan)), true, false, true);
      this.FastAddProperty("E", (JsValue) System.Math.E, false, false, false);
      this.FastAddProperty("LN10", (JsValue) System.Math.Log(10.0), false, false, false);
      this.FastAddProperty("LN2", (JsValue) System.Math.Log(2.0), false, false, false);
      this.FastAddProperty("LOG2E", (JsValue) System.Math.Log(System.Math.E, 2.0), false, false, false);
      this.FastAddProperty("LOG10E", (JsValue) System.Math.Log(System.Math.E, 10.0), false, false, false);
      this.FastAddProperty("PI", (JsValue) System.Math.PI, false, false, false);
      this.FastAddProperty("SQRT1_2", (JsValue) System.Math.Sqrt(0.5), false, false, false);
      this.FastAddProperty("SQRT2", (JsValue) System.Math.Sqrt(2.0), false, false, false);
    }

    private static JsValue Abs(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) System.Math.Abs(TypeConverter.ToNumber(arguments.At(0)));
    }

    private static JsValue Acos(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) System.Math.Acos(TypeConverter.ToNumber(arguments.At(0)));
    }

    private static JsValue Asin(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) System.Math.Asin(TypeConverter.ToNumber(arguments.At(0)));
    }

    private static JsValue Atan(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) System.Math.Atan(TypeConverter.ToNumber(arguments.At(0)));
    }

    private static JsValue Atan2(JsValue thisObject, JsValue[] arguments)
    {
      double number1 = TypeConverter.ToNumber(arguments.At(0));
      double number2 = TypeConverter.ToNumber(arguments.At(1));
      if (double.IsNaN(number2) || double.IsNaN(number1))
        return (JsValue) double.NaN;
      if (number1 > 0.0 && number2.Equals(0.0))
        return (JsValue) (System.Math.PI / 2.0);
      if (NumberInstance.IsPositiveZero(number1))
      {
        if (number2 > 0.0)
          return (JsValue) 0.0;
        if (NumberInstance.IsPositiveZero(number2))
          return (JsValue) 0.0;
        if (NumberInstance.IsNegativeZero(number2))
          return (JsValue) System.Math.PI;
        if (number2 < 0.0)
          return (JsValue) System.Math.PI;
      }
      if (NumberInstance.IsNegativeZero(number1))
      {
        if (number2 > 0.0)
          return (JsValue) 0.0;
        if (NumberInstance.IsPositiveZero(number2))
          return (JsValue) 0.0;
        if (NumberInstance.IsNegativeZero(number2))
          return (JsValue) (-1.0 * System.Math.PI);
        if (number2 < 0.0)
          return (JsValue) (-1.0 * System.Math.PI);
      }
      if (number1 < 0.0 && number2.Equals(0.0))
        return (JsValue) (-1.0 * System.Math.PI / 2.0);
      if (number1 > 0.0 && !double.IsInfinity(number1))
      {
        if (double.IsPositiveInfinity(number2))
          return (JsValue) 0.0;
        if (double.IsNegativeInfinity(number2))
          return (JsValue) System.Math.PI;
      }
      if (number1 < 0.0 && !double.IsInfinity(number1))
      {
        if (double.IsPositiveInfinity(number2))
          return (JsValue) 0.0;
        if (double.IsNegativeInfinity(number2))
          return (JsValue) (-1.0 * System.Math.PI);
      }
      if (double.IsPositiveInfinity(number1) && !double.IsInfinity(number2))
        return (JsValue) (System.Math.PI / 2.0);
      if (double.IsNegativeInfinity(number1) && !double.IsInfinity(number2))
        return (JsValue) (-1.0 * System.Math.PI / 2.0);
      if (double.IsPositiveInfinity(number1) && double.IsPositiveInfinity(number2))
        return (JsValue) (System.Math.PI / 4.0);
      if (double.IsPositiveInfinity(number1) && double.IsNegativeInfinity(number2))
        return (JsValue) (3.0 * System.Math.PI / 4.0);
      if (double.IsNegativeInfinity(number1) && double.IsPositiveInfinity(number2))
        return (JsValue) (-1.0 * System.Math.PI / 4.0);
      return double.IsNegativeInfinity(number1) && double.IsNegativeInfinity(number2) ? (JsValue) (-3.0 * System.Math.PI / 4.0) : (JsValue) System.Math.Atan2(number1, number2);
    }

    private static JsValue Ceil(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) System.Math.Ceiling(TypeConverter.ToNumber(arguments.At(0)));
    }

    private static JsValue Cos(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) System.Math.Cos(TypeConverter.ToNumber(arguments.At(0)));
    }

    private static JsValue Exp(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) System.Math.Exp(TypeConverter.ToNumber(arguments.At(0)));
    }

    private static JsValue Floor(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) System.Math.Floor(TypeConverter.ToNumber(arguments.At(0)));
    }

    private static JsValue Log(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) System.Math.Log(TypeConverter.ToNumber(arguments.At(0)));
    }

    private static JsValue Max(JsValue thisObject, JsValue[] arguments)
    {
      if (arguments.Length == 0)
        return (JsValue) double.NegativeInfinity;
      double val1 = TypeConverter.ToNumber(arguments.At(0));
      for (int index = 0; index < arguments.Length; ++index)
        val1 = System.Math.Max(val1, TypeConverter.ToNumber(arguments[index]));
      return (JsValue) val1;
    }

    private static JsValue Min(JsValue thisObject, JsValue[] arguments)
    {
      if (arguments.Length == 0)
        return (JsValue) double.PositiveInfinity;
      double val1 = TypeConverter.ToNumber(arguments.At(0));
      for (int index = 0; index < arguments.Length; ++index)
        val1 = System.Math.Min(val1, TypeConverter.ToNumber(arguments[index]));
      return (JsValue) val1;
    }

    private static JsValue Pow(JsValue thisObject, JsValue[] arguments)
    {
      double number1 = TypeConverter.ToNumber(arguments.At(0));
      double number2 = TypeConverter.ToNumber(arguments.At(1));
      if (double.IsNaN(number2))
        return (JsValue) double.NaN;
      if (number2.Equals(0.0))
        return (JsValue) 1.0;
      if (double.IsNaN(number1) && !number2.Equals(0.0))
        return (JsValue) double.NaN;
      if (System.Math.Abs(number1) > 1.0)
      {
        if (double.IsPositiveInfinity(number2))
          return (JsValue) double.PositiveInfinity;
        if (double.IsNegativeInfinity(number2))
          return (JsValue) 0.0;
      }
      if (System.Math.Abs(number1).Equals(1.0) && double.IsInfinity(number2))
        return (JsValue) double.NaN;
      if (System.Math.Abs(number1) < 1.0)
      {
        if (double.IsPositiveInfinity(number2))
          return (JsValue) 0.0;
        if (double.IsNegativeInfinity(number2))
          return (JsValue) double.PositiveInfinity;
      }
      if (double.IsPositiveInfinity(number1))
      {
        if (number2 > 0.0)
          return (JsValue) double.PositiveInfinity;
        if (number2 < 0.0)
          return (JsValue) 0.0;
      }
      if (double.IsNegativeInfinity(number1))
      {
        if (number2 > 0.0)
          return System.Math.Abs(number2 % 2.0).Equals(1.0) ? (JsValue) double.NegativeInfinity : (JsValue) double.PositiveInfinity;
        if (number2 < 0.0)
        {
          System.Math.Abs(number2 % 2.0).Equals(1.0);
          return (JsValue) 0.0;
        }
      }
      if (NumberInstance.IsPositiveZero(number1))
      {
        if (number2 > 0.0)
          return (JsValue) 0.0;
        if (number2 < 0.0)
          return (JsValue) double.PositiveInfinity;
      }
      if (NumberInstance.IsNegativeZero(number1))
      {
        if (number2 > 0.0)
        {
          System.Math.Abs(number2 % 2.0).Equals(1.0);
          return (JsValue) 0.0;
        }
        if (number2 < 0.0)
          return System.Math.Abs(number2 % 2.0).Equals(1.0) ? (JsValue) double.NegativeInfinity : (JsValue) double.PositiveInfinity;
      }
      return number1 < 0.0 && !double.IsInfinity(number1) && !double.IsInfinity(number2) && !number2.Equals((double) (int) number2) ? (JsValue) double.NaN : (JsValue) System.Math.Pow(number1, number2);
    }

    private static JsValue Random(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) MathInstance._random.NextDouble();
    }

    private static JsValue Round(JsValue thisObject, JsValue[] arguments)
    {
      double number = TypeConverter.ToNumber(arguments.At(0));
      double num = System.Math.Round(number);
      return num.Equals(number - 0.5) ? (JsValue) (num + 1.0) : (JsValue) num;
    }

    private static JsValue Sin(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) System.Math.Sin(TypeConverter.ToNumber(arguments.At(0)));
    }

    private static JsValue Sqrt(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) System.Math.Sqrt(TypeConverter.ToNumber(arguments.At(0)));
    }

    private static JsValue Tan(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) System.Math.Tan(TypeConverter.ToNumber(arguments.At(0)));
    }
  }
}
