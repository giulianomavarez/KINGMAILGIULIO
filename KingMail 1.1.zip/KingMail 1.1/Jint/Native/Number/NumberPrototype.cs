﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Number.NumberPrototype
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Number.Dtoa;
using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Interop;
using System;
using System.Globalization;
using System.Text;

#nullable disable
namespace Jint.Native.Number
{
  public sealed class NumberPrototype : NumberInstance
  {
    private const double Ten21 = 1E+21;

    private NumberPrototype(Engine engine)
      : base(engine)
    {
    }

    public static NumberPrototype CreatePrototypeObject(
      Engine engine,
      NumberConstructor numberConstructor)
    {
      NumberPrototype prototypeObject = new NumberPrototype(engine);
      prototypeObject.Prototype = (ObjectInstance) engine.Object.PrototypeObject;
      prototypeObject.PrimitiveValue = (JsValue) 0.0;
      prototypeObject.Extensible = true;
      prototypeObject.FastAddProperty("constructor", (JsValue) (ObjectInstance) numberConstructor, true, false, true);
      return prototypeObject;
    }

    public void Configure()
    {
      this.FastAddProperty("toString", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToNumberString)), true, false, true);
      this.FastAddProperty("toLocaleString", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToLocaleString)), true, false, true);
      this.FastAddProperty("valueOf", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ValueOf)), true, false, true);
      this.FastAddProperty("toFixed", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToFixed), 1), true, false, true);
      this.FastAddProperty("toExponential", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToExponential)), true, false, true);
      this.FastAddProperty("toPrecision", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToPrecision)), true, false, true);
    }

    private JsValue ToLocaleString(JsValue thisObject, JsValue[] arguments)
    {
      double d = thisObject.IsNumber() || thisObject.TryCast<NumberInstance>() != null ? TypeConverter.ToNumber(thisObject) : throw new JavaScriptException(this.Engine.TypeError);
      if (double.IsNaN(d))
        return (JsValue) "NaN";
      if (d.Equals(0.0))
        return (JsValue) "0";
      if (d < 0.0)
        return (JsValue) ("-" + (object) this.ToLocaleString((JsValue) -d, arguments));
      if (double.IsPositiveInfinity(d) || d >= double.MaxValue)
        return (JsValue) "Infinity";
      return double.IsNegativeInfinity(d) || d <= double.MinValue ? (JsValue) "-Infinity" : (JsValue) d.ToString("n", (IFormatProvider) this.Engine.Options._Culture);
    }

    private JsValue ValueOf(JsValue thisObj, JsValue[] arguments)
    {
      return (thisObj.TryCast<NumberInstance>() ?? throw new JavaScriptException(this.Engine.TypeError)).PrimitiveValue;
    }

    private JsValue ToFixed(JsValue thisObj, JsValue[] arguments)
    {
      int integer = (int) TypeConverter.ToInteger(arguments.At(0, (JsValue) 0.0));
      if (integer < 0 || integer > 20)
        throw new JavaScriptException(this.Engine.RangeError, "fractionDigits argument must be between 0 and 20");
      double number = TypeConverter.ToNumber(thisObj);
      if (double.IsNaN(number))
        return (JsValue) "NaN";
      return number >= 1E+21 ? (JsValue) NumberPrototype.ToNumberString(number) : (JsValue) number.ToString("f" + (object) integer, (IFormatProvider) CultureInfo.InvariantCulture);
    }

    private JsValue ToExponential(JsValue thisObj, JsValue[] arguments)
    {
      int integer = (int) TypeConverter.ToInteger(arguments.At(0, (JsValue) 16.0));
      if (integer < 0 || integer > 20)
        throw new JavaScriptException(this.Engine.RangeError, "fractionDigits argument must be between 0 and 20");
      double number = TypeConverter.ToNumber(thisObj);
      if (double.IsNaN(number))
        return (JsValue) "NaN";
      string format = "#." + new string('0', integer) + "e+0";
      return (JsValue) number.ToString(format, (IFormatProvider) CultureInfo.InvariantCulture);
    }

    private JsValue ToPrecision(JsValue thisObj, JsValue[] arguments)
    {
      double number = TypeConverter.ToNumber(thisObj);
      if (arguments.At(0) == Undefined.Instance)
        return (JsValue) TypeConverter.ToString((JsValue) number);
      double integer = TypeConverter.ToInteger(arguments.At(0));
      if (double.IsInfinity(number) || double.IsNaN(number))
        return (JsValue) TypeConverter.ToString((JsValue) number);
      if (integer < 1.0 || integer > 21.0)
        throw new JavaScriptException(this.Engine.RangeError, "precision must be between 1 and 21");
      string str = number.ToString("e23", (IFormatProvider) CultureInfo.InvariantCulture);
      int num1 = str.IndexOfAny(new char[2]{ '.', 'e' });
      int num2 = num1 == -1 ? str.Length : num1;
      double num3 = integer - (double) num2;
      double num4 = num3 < 1.0 ? 1.0 : num3;
      return (JsValue) number.ToString("f" + (object) num4, (IFormatProvider) CultureInfo.InvariantCulture);
    }

    private JsValue ToNumberString(JsValue thisObject, JsValue[] arguments)
    {
      if (!thisObject.IsNumber() && thisObject.TryCast<NumberInstance>() == null)
        throw new JavaScriptException(this.Engine.TypeError);
      int radix = arguments.At(0) == JsValue.Undefined ? 10 : (int) TypeConverter.ToInteger(arguments.At(0));
      if (radix < 2 || radix > 36)
        throw new JavaScriptException(this.Engine.RangeError, "radix must be between 2 and 36");
      double number = TypeConverter.ToNumber(thisObject);
      if (double.IsNaN(number))
        return (JsValue) "NaN";
      if (number.Equals(0.0))
        return (JsValue) "0";
      if (double.IsPositiveInfinity(number) || number >= double.MaxValue)
        return (JsValue) "Infinity";
      if (number < 0.0)
        return (JsValue) ("-" + (object) this.ToNumberString((JsValue) -number, arguments));
      if (radix == 10)
        return (JsValue) NumberPrototype.ToNumberString(number);
      long n1 = (long) number;
      double n2 = number - (double) n1;
      string numberString = NumberPrototype.ToBase(n1, radix);
      if (!n2.Equals(0.0))
        numberString = numberString + "." + NumberPrototype.ToFractionBase(n2, radix);
      return (JsValue) numberString;
    }

    public static string ToBase(long n, int radix)
    {
      if (n == 0L)
        return "0";
      StringBuilder stringBuilder = new StringBuilder();
      while (n > 0L)
      {
        int index = (int) (n % (long) radix);
        n /= (long) radix;
        stringBuilder.Insert(0, "0123456789abcdefghijklmnopqrstuvwxyz"[index].ToString());
      }
      return stringBuilder.ToString();
    }

    public static string ToFractionBase(double n, int radix)
    {
      if (n.Equals(0.0))
        return "0";
      StringBuilder stringBuilder = new StringBuilder();
      while (n > 0.0 && stringBuilder.Length < 50)
      {
        int index;
        n = (double) (index = (int) (n * (double) radix)) - (double) index;
        stringBuilder.Append("0123456789abcdefghijklmnopqrstuvwxyz"[index].ToString());
      }
      return stringBuilder.ToString();
    }

    public static string ToNumberString(double m)
    {
      if (double.IsNaN(m))
        return "NaN";
      if (m.Equals(0.0))
        return "0";
      if (double.IsPositiveInfinity(m) || m >= double.MaxValue)
        return "Infinity";
      if (m < 0.0)
        return "-" + NumberPrototype.ToNumberString(-m);
      string numberString = FastDtoa.NumberToString(m);
      if (numberString != null)
        return numberString;
      string str1 = (string) null;
      string str2 = m.ToString("r", (IFormatProvider) CultureInfo.InvariantCulture);
      if (str2.IndexOf("e", StringComparison.OrdinalIgnoreCase) == -1)
        str1 = str2.Replace(".", "").TrimStart('0').TrimEnd('0');
      string[] strArray = m.ToString("0.00000000000000000e0", (IFormatProvider) CultureInfo.InvariantCulture).Split('e');
      if (str1 == null)
        str1 = strArray[0].TrimEnd('0').Replace(".", "");
      int num = int.Parse(strArray[1]) + 1;
      int length = str1.Length;
      if (length <= num && num <= 21)
        return str1 + new string('0', num - length);
      if (0 < num && num <= 21)
        return str1.Substring(0, num) + "." + str1.Substring(num);
      if (-6 < num && num <= 0)
        return "0." + new string('0', -num) + str1;
      return length == 1 ? str1 + "e" + (num - 1 < 0 ? (object) "-" : (object) "+") + (object) Math.Abs(num - 1) : str1.Substring(0, 1) + "." + str1.Substring(1) + "e" + (num - 1 < 0 ? (object) "-" : (object) "+") + (object) Math.Abs(num - 1);
    }
  }
}
