﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Number.NumberConstructor
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Function;
using Jint.Native.Object;
using Jint.Runtime;
using Jint.Runtime.Environments;

#nullable disable
namespace Jint.Native.Number
{
  public sealed class NumberConstructor(Engine engine) : FunctionInstance(engine, (string[]) null, (LexicalEnvironment) null, false), IConstructor
  {
    public static NumberConstructor CreateNumberConstructor(Engine engine)
    {
      NumberConstructor numberConstructor = new NumberConstructor(engine);
      numberConstructor.Extensible = true;
      numberConstructor.Prototype = (ObjectInstance) engine.Function.PrototypeObject;
      numberConstructor.PrototypeObject = NumberPrototype.CreatePrototypeObject(engine, numberConstructor);
      numberConstructor.FastAddProperty("length", (JsValue) 1.0, false, false, false);
      numberConstructor.FastAddProperty("prototype", (JsValue) (ObjectInstance) numberConstructor.PrototypeObject, false, false, false);
      return numberConstructor;
    }

    public void Configure()
    {
      this.FastAddProperty("MAX_VALUE", (JsValue) double.MaxValue, false, false, false);
      this.FastAddProperty("MIN_VALUE", (JsValue) double.Epsilon, false, false, false);
      this.FastAddProperty("NaN", (JsValue) double.NaN, false, false, false);
      this.FastAddProperty("NEGATIVE_INFINITY", (JsValue) double.NegativeInfinity, false, false, false);
      this.FastAddProperty("POSITIVE_INFINITY", (JsValue) double.PositiveInfinity, false, false, false);
    }

    public override JsValue Call(JsValue thisObject, JsValue[] arguments)
    {
      return arguments.Length == 0 ? (JsValue) 0.0 : (JsValue) TypeConverter.ToNumber(arguments[0]);
    }

    public ObjectInstance Construct(JsValue[] arguments)
    {
      return (ObjectInstance) this.Construct(arguments.Length != 0 ? TypeConverter.ToNumber(arguments[0]) : 0.0);
    }

    public NumberPrototype PrototypeObject { get; private set; }

    public NumberInstance Construct(double value)
    {
      NumberInstance numberInstance = new NumberInstance(this.Engine);
      numberInstance.Prototype = (ObjectInstance) this.PrototypeObject;
      numberInstance.PrimitiveValue = (JsValue) value;
      numberInstance.Extensible = true;
      return numberInstance;
    }
  }
}
