﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Number.NumberInstance
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Object;
using Jint.Runtime;
using System;

#nullable disable
namespace Jint.Native.Number
{
  public class NumberInstance(Engine engine) : ObjectInstance(engine), IPrimitiveInstance
  {
    private static readonly long NegativeZeroBits = BitConverter.DoubleToInt64Bits(-0.0);

    public override string Class => "Number";

    Types IPrimitiveInstance.Type => Types.Number;

    JsValue IPrimitiveInstance.PrimitiveValue => this.PrimitiveValue;

    public JsValue PrimitiveValue { get; set; }

    public static bool IsNegativeZero(double x)
    {
      return x == 0.0 && BitConverter.DoubleToInt64Bits(x) == NumberInstance.NegativeZeroBits;
    }

    public static bool IsPositiveZero(double x)
    {
      return x == 0.0 && BitConverter.DoubleToInt64Bits(x) != NumberInstance.NegativeZeroBits;
    }
  }
}
