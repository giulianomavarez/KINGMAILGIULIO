﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Number.Dtoa.DoubleHelper
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

#nullable disable
namespace Jint.Native.Number.Dtoa
{
  public class DoubleHelper
  {
    private const long KExponentMask = 9218868437227405312;
    private const long KSignificandMask = 4503599627370495;
    private const long KHiddenBit = 4503599627370496;
    private const int KSignificandSize = 52;
    private const int KExponentBias = 1075;
    private const int KDenormalExponent = -1074;

    private static DiyFp AsDiyFp(long d64)
    {
      return new DiyFp(DoubleHelper.Significand(d64), DoubleHelper.Exponent(d64));
    }

    internal static DiyFp AsNormalizedDiyFp(long d64)
    {
      long num1 = DoubleHelper.Significand(d64);
      int num2 = DoubleHelper.Exponent(d64);
      while ((num1 & 4503599627370496L) == 0L)
      {
        num1 <<= 1;
        --num2;
      }
      return new DiyFp(num1 << 11, num2 - 11);
    }

    private static int Exponent(long d64)
    {
      return DoubleHelper.IsDenormal(d64) ? -1074 : (int) ((d64 & 9218868437227405312L).UnsignedShift(52) & (long) uint.MaxValue) - 1075;
    }

    private static long Significand(long d64)
    {
      long num = d64 & 4503599627370495L;
      return !DoubleHelper.IsDenormal(d64) ? num + 4503599627370496L : num;
    }

    private static bool IsDenormal(long d64) => (d64 & 9218868437227405312L) == 0L;

    private static bool IsSpecial(long d64) => (d64 & 9218868437227405312L) == 9218868437227405312L;

    internal static void NormalizedBoundaries(long d64, DiyFp mMinus, DiyFp mPlus)
    {
      DiyFp diyFp = DoubleHelper.AsDiyFp(d64);
      int num = diyFp.F == 4503599627370496L ? 1 : 0;
      mPlus.F = (diyFp.F << 1) + 1L;
      mPlus.E = diyFp.E - 1;
      mPlus.Normalize();
      if (num != 0 && diyFp.E != -1074)
      {
        mMinus.F = (diyFp.F << 2) - 1L;
        mMinus.E = diyFp.E - 2;
      }
      else
      {
        mMinus.F = (diyFp.F << 1) - 1L;
        mMinus.E = diyFp.E - 1;
      }
      mMinus.F <<= mMinus.E - mPlus.E;
      mMinus.E = mPlus.E;
    }
  }
}
