﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Number.Dtoa.DiyFp
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

#nullable disable
namespace Jint.Native.Number.Dtoa
{
  internal class DiyFp
  {
    internal const int KSignificandSize = 64;
    private const ulong KUint64MSB = 9223372036854775808;

    internal DiyFp()
    {
      this.F = 0L;
      this.E = 0;
    }

    internal DiyFp(long f, int e)
    {
      this.F = f;
      this.E = e;
    }

    public long F { get; set; }

    public int E { get; set; }

    private static bool Uint64Gte(long a, long b) => a == b || a > b ^ a < 0L ^ b < 0L;

    private void Subtract(DiyFp other) => this.F -= other.F;

    internal static DiyFp Minus(DiyFp a, DiyFp b)
    {
      DiyFp diyFp = new DiyFp(a.F, a.E);
      diyFp.Subtract(b);
      return diyFp;
    }

    private void Multiply(DiyFp other)
    {
      long num1 = this.F.UnsignedShift(32);
      long num2 = this.F & (long) uint.MaxValue;
      long num3 = other.F.UnsignedShift(32);
      long num4 = other.F & (long) uint.MaxValue;
      long num5 = num1 * num3;
      long l1 = num2 * num3;
      long l2 = num1 * num4;
      long l3 = (num2 * num4).UnsignedShift(32) + (l2 & (long) uint.MaxValue) + (l1 & (long) uint.MaxValue) + 2147483648L;
      long num6 = num5 + l2.UnsignedShift(32) + l1.UnsignedShift(32) + l3.UnsignedShift(32);
      this.E += other.E + 64;
      this.F = num6;
    }

    internal static DiyFp Times(DiyFp a, DiyFp b)
    {
      DiyFp diyFp = new DiyFp(a.F, a.E);
      diyFp.Multiply(b);
      return diyFp;
    }

    internal void Normalize()
    {
      long f = this.F;
      int e = this.E;
      while ((f & -18014398509481984L) == 0L)
      {
        f <<= 10;
        e -= 10;
      }
      while ((f & long.MinValue) == 0L)
      {
        f <<= 1;
        --e;
      }
      this.F = f;
      this.E = e;
    }

    public override string ToString()
    {
      return "[DiyFp f:" + (object) this.F + ", e:" + (object) this.E + "]";
    }
  }
}
