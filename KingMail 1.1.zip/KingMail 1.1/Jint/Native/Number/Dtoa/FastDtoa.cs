﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Number.Dtoa.FastDtoa
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using System;

#nullable disable
namespace Jint.Native.Number.Dtoa
{
  public class FastDtoa
  {
    public const int KFastDtoaMaximalLength = 17;
    private const int MinimalTargetExponent = -60;
    private const int MaximalTargetExponent = -32;
    private const int KTen4 = 10000;
    private const int KTen5 = 100000;
    private const int KTen6 = 1000000;
    private const int KTen7 = 10000000;
    private const int KTen8 = 100000000;
    private const int KTen9 = 1000000000;

    private static bool RoundWeed(
      FastDtoaBuilder buffer,
      long distanceTooHighW,
      long unsafeInterval,
      long rest,
      long tenKappa,
      long unit)
    {
      long num1 = distanceTooHighW - unit;
      long num2 = distanceTooHighW + unit;
      for (; rest < num1 && unsafeInterval - rest >= tenKappa && (rest + tenKappa < num1 || num1 - rest >= rest + tenKappa - num1); rest += tenKappa)
        buffer.DecreaseLast();
      return (rest >= num2 || unsafeInterval - rest < tenKappa || rest + tenKappa >= num2 && num2 - rest <= rest + tenKappa - num2) && 2L * unit <= rest && rest <= unsafeInterval - 4L * unit;
    }

    private static long BiggestPowerTen(int number, int numberBits)
    {
      int num1;
      int num2;
      switch (numberBits)
      {
        case 0:
          num1 = 0;
          num2 = -1;
          break;
        case 1:
        case 2:
        case 3:
          if (1 <= number)
          {
            num1 = 1;
            num2 = 0;
            break;
          }
          goto case 0;
        case 4:
        case 5:
        case 6:
          if (10 <= number)
          {
            num1 = 10;
            num2 = 1;
            break;
          }
          goto case 1;
        case 7:
        case 8:
        case 9:
          if (100 <= number)
          {
            num1 = 100;
            num2 = 2;
            break;
          }
          goto case 4;
        case 10:
        case 11:
        case 12:
        case 13:
          if (1000 <= number)
          {
            num1 = 1000;
            num2 = 3;
            break;
          }
          goto case 7;
        case 14:
        case 15:
        case 16:
          if (10000 <= number)
          {
            num1 = 10000;
            num2 = 4;
            break;
          }
          goto case 10;
        case 17:
        case 18:
        case 19:
          if (100000 <= number)
          {
            num1 = 100000;
            num2 = 5;
            break;
          }
          goto case 14;
        case 20:
        case 21:
        case 22:
        case 23:
          if (1000000 <= number)
          {
            num1 = 1000000;
            num2 = 6;
            break;
          }
          goto case 17;
        case 24:
        case 25:
        case 26:
          if (10000000 <= number)
          {
            num1 = 10000000;
            num2 = 7;
            break;
          }
          goto case 20;
        case 27:
        case 28:
        case 29:
          if (100000000 <= number)
          {
            num1 = 100000000;
            num2 = 8;
            break;
          }
          goto case 24;
        case 30:
        case 31:
        case 32:
          if (1000000000 <= number)
          {
            num1 = 1000000000;
            num2 = 9;
            break;
          }
          goto case 27;
        default:
          num1 = 0;
          num2 = 0;
          break;
      }
      return (long) num1 << 32 | (long) uint.MaxValue & (long) num2;
    }

    private static bool DigitGen(DiyFp low, DiyFp w, DiyFp high, FastDtoaBuilder buffer, int mk)
    {
      long unit = 1;
      DiyFp b = new DiyFp(low.F - unit, low.E);
      DiyFp a = new DiyFp(high.F + unit, high.E);
      DiyFp diyFp1 = DiyFp.Minus(a, b);
      DiyFp diyFp2 = new DiyFp(1L << -w.E, w.E);
      int number = (int) (a.F.UnsignedShift(-diyFp2.E) & (long) uint.MaxValue);
      long rest1 = a.F & diyFp2.F - 1L;
      long l1 = FastDtoa.BiggestPowerTen(number, 64 - -diyFp2.E);
      int num1 = (int) (l1.UnsignedShift(32) & (long) uint.MaxValue);
      int num2 = (int) (l1 & (long) uint.MaxValue) + 1;
      while (num2 > 0)
      {
        int num3 = number / num1;
        buffer.Append((char) (48 + num3));
        number %= num1;
        --num2;
        long rest2 = ((long) number << -diyFp2.E) + rest1;
        if (rest2 < diyFp1.F)
        {
          buffer.Point = buffer.End - mk + num2;
          return FastDtoa.RoundWeed(buffer, DiyFp.Minus(a, w).F, diyFp1.F, rest2, (long) num1 << -diyFp2.E, unit);
        }
        num1 /= 10;
      }
      do
      {
        long l2 = rest1 * 5L;
        unit *= 5L;
        diyFp1.F *= 5L;
        ++diyFp1.E;
        diyFp2.F = diyFp2.F.UnsignedShift(1);
        ++diyFp2.E;
        int num4 = (int) (l2.UnsignedShift(-diyFp2.E) & (long) uint.MaxValue);
        buffer.Append((char) (48 + num4));
        rest1 = l2 & diyFp2.F - 1L;
        --num2;
      }
      while (rest1 >= diyFp1.F);
      buffer.Point = buffer.End - mk + num2;
      return FastDtoa.RoundWeed(buffer, DiyFp.Minus(a, w).F * unit, diyFp1.F, rest1, diyFp2.F, unit);
    }

    private static bool Grisu3(double v, FastDtoaBuilder buffer)
    {
      long int64Bits = BitConverter.DoubleToInt64Bits(v);
      DiyFp a = DoubleHelper.AsNormalizedDiyFp(int64Bits);
      DiyFp diyFp1 = new DiyFp();
      DiyFp diyFp2 = new DiyFp();
      DoubleHelper.NormalizedBoundaries(int64Bits, diyFp1, diyFp2);
      DiyFp diyFp3 = new DiyFp();
      int cachedPower = CachedPowers.GetCachedPower(a.E + 64, -60, -32, diyFp3);
      DiyFp diyFp4 = DiyFp.Times(a, diyFp3);
      DiyFp low = DiyFp.Times(diyFp1, diyFp3);
      DiyFp diyFp5 = DiyFp.Times(diyFp2, diyFp3);
      DiyFp w = diyFp4;
      DiyFp high = diyFp5;
      FastDtoaBuilder buffer1 = buffer;
      int mk = cachedPower;
      return FastDtoa.DigitGen(low, w, high, buffer1, mk);
    }

    public static bool Dtoa(double v, FastDtoaBuilder buffer) => FastDtoa.Grisu3(v, buffer);

    public static string NumberToString(double v)
    {
      FastDtoaBuilder buffer = new FastDtoaBuilder();
      return !FastDtoa.NumberToString(v, buffer) ? (string) null : buffer.Format();
    }

    public static bool NumberToString(double v, FastDtoaBuilder buffer)
    {
      buffer.Reset();
      if (v < 0.0)
      {
        buffer.Append('-');
        v = -v;
      }
      return FastDtoa.Dtoa(v, buffer);
    }
  }
}
