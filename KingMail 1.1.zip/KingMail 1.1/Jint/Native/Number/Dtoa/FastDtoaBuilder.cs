﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Number.Dtoa.FastDtoaBuilder
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using System;

#nullable disable
namespace Jint.Native.Number.Dtoa
{
  public class FastDtoaBuilder
  {
    private readonly char[] _chars = new char[25];
    internal int End;
    internal int Point;
    private bool _formatted;
    private static readonly char[] Digits = new char[10]
    {
      '0',
      '1',
      '2',
      '3',
      '4',
      '5',
      '6',
      '7',
      '8',
      '9'
    };

    internal void Append(char c) => this._chars[this.End++] = c;

    internal void DecreaseLast() => --this._chars[this.End - 1];

    public void Reset()
    {
      this.End = 0;
      this._formatted = false;
    }

    public override string ToString()
    {
      return "[chars:" + new string(this._chars, 0, this.End) + ", point:" + (object) this.Point + "]";
    }

    public string Format()
    {
      if (!this._formatted)
      {
        int firstDigit = this._chars[0] == '-' ? 1 : 0;
        int decPoint = this.Point - firstDigit;
        if (decPoint < -5 || decPoint > 21)
          this.ToExponentialFormat(firstDigit, decPoint);
        else
          this.ToFixedFormat(firstDigit, decPoint);
        this._formatted = true;
      }
      return new string(this._chars, 0, this.End);
    }

    private void ToFixedFormat(int firstDigit, int decPoint)
    {
      if (this.Point < this.End)
      {
        if (decPoint > 0)
        {
          Array.Copy((Array) this._chars, this.Point, (Array) this._chars, this.Point + 1, this.End - this.Point);
          this._chars[this.Point] = '.';
          ++this.End;
        }
        else
        {
          int num = firstDigit + 2 - decPoint;
          Array.Copy((Array) this._chars, firstDigit, (Array) this._chars, num, this.End - firstDigit);
          this._chars[firstDigit] = '0';
          this._chars[firstDigit + 1] = '.';
          if (decPoint < 0)
            this.Fill<char>(this._chars, firstDigit + 2, num, '0');
          this.End += 2 - decPoint;
        }
      }
      else
      {
        if (this.Point <= this.End)
          return;
        this.Fill<char>(this._chars, this.End, this.Point, '0');
        this.End += this.Point - this.End;
      }
    }

    private void ToExponentialFormat(int firstDigit, int decPoint)
    {
      if (this.End - firstDigit > 1)
      {
        int sourceIndex = firstDigit + 1;
        Array.Copy((Array) this._chars, sourceIndex, (Array) this._chars, sourceIndex + 1, this.End - sourceIndex);
        this._chars[sourceIndex] = '.';
        ++this.End;
      }
      this._chars[this.End++] = 'e';
      char ch = '+';
      int num1 = decPoint - 1;
      if (num1 < 0)
      {
        ch = '-';
        num1 = -num1;
      }
      this._chars[this.End++] = ch;
      int num2 = num1 > 99 ? this.End + 2 : (num1 > 9 ? this.End + 1 : this.End);
      this.End = num2 + 1;
      do
      {
        int index = num1 % 10;
        this._chars[num2--] = FastDtoaBuilder.Digits[index];
        num1 /= 10;
      }
      while (num1 != 0);
    }

    private void Fill<T>(T[] array, int fromIndex, int toIndex, T val)
    {
      for (int index = fromIndex; index < toIndex; ++index)
        array[index] = val;
    }
  }
}
