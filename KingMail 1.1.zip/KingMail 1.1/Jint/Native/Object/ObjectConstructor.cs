﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Object.ObjectConstructor
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Native.Function;
using Jint.Native.String;
using Jint.Runtime;
using Jint.Runtime.Descriptors;
using Jint.Runtime.Environments;
using Jint.Runtime.Interop;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace Jint.Native.Object
{
  public sealed class ObjectConstructor : FunctionInstance, IConstructor
  {
    private readonly Engine _engine;

    private ObjectConstructor(Engine engine)
      : base(engine, (string[]) null, (LexicalEnvironment) null, false)
    {
      this._engine = engine;
    }

    public static ObjectConstructor CreateObjectConstructor(Engine engine)
    {
      ObjectConstructor objectConstructor = new ObjectConstructor(engine);
      objectConstructor.Extensible = true;
      objectConstructor.PrototypeObject = ObjectPrototype.CreatePrototypeObject(engine, objectConstructor);
      objectConstructor.FastAddProperty("length", (JsValue) 1.0, false, false, false);
      objectConstructor.FastAddProperty("prototype", (JsValue) (ObjectInstance) objectConstructor.PrototypeObject, false, false, false);
      return objectConstructor;
    }

    public void Configure()
    {
      this.Prototype = (ObjectInstance) this.Engine.Function.PrototypeObject;
      this.FastAddProperty("getPrototypeOf", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetPrototypeOf), 1), true, false, true);
      this.FastAddProperty("getOwnPropertyDescriptor", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetOwnPropertyDescriptor), 2), true, false, true);
      this.FastAddProperty("getOwnPropertyNames", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.GetOwnPropertyNames), 1), true, false, true);
      this.FastAddProperty("create", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Create), 2), true, false, true);
      this.FastAddProperty("defineProperty", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.DefineProperty), 3), true, false, true);
      this.FastAddProperty("defineProperties", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.DefineProperties), 2), true, false, true);
      this.FastAddProperty("seal", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Seal), 1), true, false, true);
      this.FastAddProperty("freeze", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Freeze), 1), true, false, true);
      this.FastAddProperty("preventExtensions", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.PreventExtensions), 1), true, false, true);
      this.FastAddProperty("isSealed", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.IsSealed), 1), true, false, true);
      this.FastAddProperty("isFrozen", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.IsFrozen), 1), true, false, true);
      this.FastAddProperty("isExtensible", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.IsExtensible), 1), true, false, true);
      this.FastAddProperty("keys", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.Keys), 1), true, false, true);
    }

    public ObjectPrototype PrototypeObject { get; private set; }

    public override JsValue Call(JsValue thisObject, JsValue[] arguments)
    {
      if (arguments.Length == 0)
        return (JsValue) this.Construct(arguments);
      return arguments[0] == Null.Instance || arguments[0] == Undefined.Instance ? (JsValue) this.Construct(arguments) : (JsValue) TypeConverter.ToObject(this._engine, arguments[0]);
    }

    public ObjectInstance Construct(JsValue[] arguments)
    {
      if (arguments.Length != 0)
      {
        JsValue jsValue = arguments[0];
        ObjectInstance objectInstance = jsValue.TryCast<ObjectInstance>();
        if (objectInstance != null)
          return objectInstance;
        switch (jsValue.Type)
        {
          case Types.Boolean:
          case Types.String:
          case Types.Number:
            return TypeConverter.ToObject(this._engine, jsValue);
        }
      }
      return new ObjectInstance(this._engine)
      {
        Extensible = true,
        Prototype = (ObjectInstance) this.Engine.Object.PrototypeObject
      };
    }

    public JsValue GetPrototypeOf(JsValue thisObject, JsValue[] arguments)
    {
      ObjectInstance prototype = (arguments.At(0).TryCast<ObjectInstance>() ?? throw new JavaScriptException(this.Engine.TypeError)).Prototype;
      return prototype == null ? Null.Instance : (JsValue) prototype;
    }

    public JsValue GetOwnPropertyDescriptor(JsValue thisObject, JsValue[] arguments)
    {
      return PropertyDescriptor.FromPropertyDescriptor(this.Engine, (arguments.At(0).TryCast<ObjectInstance>() ?? throw new JavaScriptException(this.Engine.TypeError)).GetOwnProperty(TypeConverter.ToString(arguments.At(1))));
    }

    public JsValue GetOwnPropertyNames(JsValue thisObject, JsValue[] arguments)
    {
      ObjectInstance objectInstance = arguments.At(0).TryCast<ObjectInstance>();
      if (objectInstance == null)
        throw new JavaScriptException(this.Engine.TypeError);
      ObjectInstance ownPropertyNames = this.Engine.Array.Construct(Arguments.Empty);
      int num = 0;
      if (objectInstance is StringInstance stringInstance)
      {
        for (int index = 0; index < stringInstance.PrimitiveValue.AsString().Length; ++index)
        {
          ownPropertyNames.DefineOwnProperty(num.ToString(), new PropertyDescriptor((JsValue) index.ToString(), new bool?(true), new bool?(true), new bool?(true)), false);
          ++num;
        }
      }
      foreach (KeyValuePair<string, PropertyDescriptor> ownProperty in objectInstance.GetOwnProperties())
      {
        ownPropertyNames.DefineOwnProperty(num.ToString(), new PropertyDescriptor((JsValue) ownProperty.Key, new bool?(true), new bool?(true), new bool?(true)), false);
        ++num;
      }
      return (JsValue) ownPropertyNames;
    }

    public JsValue Create(JsValue thisObject, JsValue[] arguments)
    {
      JsValue jsValue1 = arguments.At(0);
      ObjectInstance objectInstance1 = jsValue1.TryCast<ObjectInstance>();
      if (objectInstance1 == null && jsValue1 != Null.Instance)
        throw new JavaScriptException(this.Engine.TypeError);
      ObjectInstance objectInstance2 = this.Engine.Object.Construct(Arguments.Empty);
      objectInstance2.Prototype = objectInstance1;
      JsValue jsValue2 = arguments.At(1);
      if (jsValue2 != Undefined.Instance)
        this.DefineProperties(thisObject, new JsValue[2]
        {
          (JsValue) objectInstance2,
          jsValue2
        });
      return (JsValue) objectInstance2;
    }

    public JsValue DefineProperty(JsValue thisObject, JsValue[] arguments)
    {
      ObjectInstance objectInstance = arguments.At(0).TryCast<ObjectInstance>();
      if (objectInstance == null)
        throw new JavaScriptException(this.Engine.TypeError);
      objectInstance.DefineOwnProperty(TypeConverter.ToString(arguments.At(1)), PropertyDescriptor.ToPropertyDescriptor(this.Engine, arguments.At(2)), true);
      return (JsValue) objectInstance;
    }

    public JsValue DefineProperties(JsValue thisObject, JsValue[] arguments)
    {
      ObjectInstance objectInstance1 = arguments.At(0).TryCast<ObjectInstance>();
      if (objectInstance1 == null)
        throw new JavaScriptException(this.Engine.TypeError);
      ObjectInstance objectInstance2 = TypeConverter.ToObject(this.Engine, arguments.At(1));
      List<KeyValuePair<string, PropertyDescriptor>> keyValuePairList = new List<KeyValuePair<string, PropertyDescriptor>>();
      foreach (KeyValuePair<string, PropertyDescriptor> ownProperty in objectInstance2.GetOwnProperties())
      {
        bool? enumerable = ownProperty.Value.Enumerable;
        if (enumerable.HasValue)
        {
          enumerable = ownProperty.Value.Enumerable;
          if (enumerable.Value)
          {
            PropertyDescriptor propertyDescriptor = PropertyDescriptor.ToPropertyDescriptor(this.Engine, objectInstance2.Get(ownProperty.Key));
            keyValuePairList.Add(new KeyValuePair<string, PropertyDescriptor>(ownProperty.Key, propertyDescriptor));
          }
        }
      }
      foreach (KeyValuePair<string, PropertyDescriptor> keyValuePair in keyValuePairList)
        objectInstance1.DefineOwnProperty(keyValuePair.Key, keyValuePair.Value, true);
      return (JsValue) objectInstance1;
    }

    public JsValue Seal(JsValue thisObject, JsValue[] arguments)
    {
      ObjectInstance objectInstance = arguments.At(0).TryCast<ObjectInstance>();
      if (objectInstance == null)
        throw new JavaScriptException(this.Engine.TypeError);
      foreach (KeyValuePair<string, PropertyDescriptor> ownProperty in objectInstance.GetOwnProperties())
      {
        bool? configurable = ownProperty.Value.Configurable;
        if (configurable.HasValue)
        {
          configurable = ownProperty.Value.Configurable;
          if (configurable.Value)
            ownProperty.Value.Configurable = new bool?(false);
        }
        objectInstance.DefineOwnProperty(ownProperty.Key, ownProperty.Value, true);
      }
      objectInstance.Extensible = false;
      return (JsValue) objectInstance;
    }

    public JsValue Freeze(JsValue thisObject, JsValue[] arguments)
    {
      ObjectInstance objectInstance = arguments.At(0).TryCast<ObjectInstance>();
      if (objectInstance == null)
        throw new JavaScriptException(this.Engine.TypeError);
      foreach (string propertyName in objectInstance.GetOwnProperties().Select<KeyValuePair<string, PropertyDescriptor>, string>((Func<KeyValuePair<string, PropertyDescriptor>, string>) (x => x.Key)))
      {
        PropertyDescriptor ownProperty = objectInstance.GetOwnProperty(propertyName);
        if (ownProperty.IsDataDescriptor() && ownProperty.Writable.HasValue && ownProperty.Writable.Value)
          ownProperty.Writable = new bool?(false);
        if (ownProperty.Configurable.HasValue && ownProperty.Configurable.Value)
          ownProperty.Configurable = new bool?(false);
        objectInstance.DefineOwnProperty(propertyName, ownProperty, true);
      }
      objectInstance.Extensible = false;
      return (JsValue) objectInstance;
    }

    public JsValue PreventExtensions(JsValue thisObject, JsValue[] arguments)
    {
      ObjectInstance objectInstance = arguments.At(0).TryCast<ObjectInstance>();
      if (objectInstance == null)
        throw new JavaScriptException(this.Engine.TypeError);
      objectInstance.Extensible = false;
      return (JsValue) objectInstance;
    }

    public JsValue IsSealed(JsValue thisObject, JsValue[] arguments)
    {
      ObjectInstance objectInstance = arguments.At(0).TryCast<ObjectInstance>();
      if (objectInstance == null)
        throw new JavaScriptException(this.Engine.TypeError);
      foreach (KeyValuePair<string, PropertyDescriptor> ownProperty in objectInstance.GetOwnProperties())
      {
        if (ownProperty.Value.Configurable.Value)
          return (JsValue) false;
      }
      return !objectInstance.Extensible ? (JsValue) true : (JsValue) false;
    }

    public JsValue IsFrozen(JsValue thisObject, JsValue[] arguments)
    {
      ObjectInstance objectInstance = arguments.At(0).TryCast<ObjectInstance>();
      if (objectInstance == null)
        throw new JavaScriptException(this.Engine.TypeError);
      foreach (string propertyName in objectInstance.GetOwnProperties().Select<KeyValuePair<string, PropertyDescriptor>, string>((Func<KeyValuePair<string, PropertyDescriptor>, string>) (x => x.Key)))
      {
        PropertyDescriptor ownProperty = objectInstance.GetOwnProperty(propertyName);
        if (ownProperty.IsDataDescriptor() && ownProperty.Writable.HasValue && ownProperty.Writable.Value)
          return (JsValue) false;
        if (ownProperty.Configurable.HasValue && ownProperty.Configurable.Value)
          return (JsValue) false;
      }
      return !objectInstance.Extensible ? (JsValue) true : (JsValue) false;
    }

    public JsValue IsExtensible(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) (arguments.At(0).TryCast<ObjectInstance>() ?? throw new JavaScriptException(this.Engine.TypeError)).Extensible;
    }

    public JsValue Keys(JsValue thisObject, JsValue[] arguments)
    {
      KeyValuePair<string, PropertyDescriptor>[] array = (arguments.At(0).TryCast<ObjectInstance>() ?? throw new JavaScriptException(this.Engine.TypeError)).GetOwnProperties().Where<KeyValuePair<string, PropertyDescriptor>>((Func<KeyValuePair<string, PropertyDescriptor>, bool>) (x => x.Value.Enumerable.HasValue && x.Value.Enumerable.Value)).ToArray<KeyValuePair<string, PropertyDescriptor>>();
      ObjectInstance objectInstance = this.Engine.Array.Construct(new JsValue[1]
      {
        (JsValue) (double) array.Length
      });
      int o = 0;
      foreach (KeyValuePair<string, PropertyDescriptor> keyValuePair in array)
      {
        string key = keyValuePair.Key;
        objectInstance.DefineOwnProperty(TypeConverter.ToString((JsValue) (double) o), new PropertyDescriptor((JsValue) key, new bool?(true), new bool?(true), new bool?(true)), false);
        ++o;
      }
      return (JsValue) objectInstance;
    }
  }
}
