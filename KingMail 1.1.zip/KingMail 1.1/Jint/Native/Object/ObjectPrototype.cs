﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Object.ObjectPrototype
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Runtime;
using Jint.Runtime.Descriptors;
using Jint.Runtime.Interop;
using System;

#nullable disable
namespace Jint.Native.Object
{
  public sealed class ObjectPrototype : ObjectInstance
  {
    private ObjectPrototype(Engine engine)
      : base(engine)
    {
    }

    public static ObjectPrototype CreatePrototypeObject(
      Engine engine,
      ObjectConstructor objectConstructor)
    {
      ObjectPrototype prototypeObject = new ObjectPrototype(engine);
      prototypeObject.Extensible = true;
      prototypeObject.FastAddProperty("constructor", (JsValue) (ObjectInstance) objectConstructor, true, false, true);
      return prototypeObject;
    }

    public void Configure()
    {
      this.FastAddProperty("toString", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToObjectString)), true, false, true);
      this.FastAddProperty("toLocaleString", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ToLocaleString)), true, false, true);
      this.FastAddProperty("valueOf", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.ValueOf)), true, false, true);
      this.FastAddProperty("hasOwnProperty", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.HasOwnProperty), 1), true, false, true);
      this.FastAddProperty("isPrototypeOf", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.IsPrototypeOf), 1), true, false, true);
      this.FastAddProperty("propertyIsEnumerable", (JsValue) (ObjectInstance) new ClrFunctionInstance(this.Engine, new Func<JsValue, JsValue[], JsValue>(this.PropertyIsEnumerable), 1), true, false, true);
    }

    private JsValue PropertyIsEnumerable(JsValue thisObject, JsValue[] arguments)
    {
      string propertyName = TypeConverter.ToString(arguments[0]);
      PropertyDescriptor ownProperty = TypeConverter.ToObject(this.Engine, thisObject).GetOwnProperty(propertyName);
      return ownProperty == PropertyDescriptor.Undefined ? (JsValue) false : (JsValue) (ownProperty.Enumerable.HasValue && ownProperty.Enumerable.Value);
    }

    private JsValue ValueOf(JsValue thisObject, JsValue[] arguments)
    {
      return (JsValue) TypeConverter.ToObject(this.Engine, thisObject);
    }

    private JsValue IsPrototypeOf(JsValue thisObject, JsValue[] arguments)
    {
      JsValue jsValue = arguments[0];
      if (!jsValue.IsObject())
        return (JsValue) false;
      ObjectInstance objectInstance1 = jsValue.AsObject();
      ObjectInstance objectInstance2 = TypeConverter.ToObject(this.Engine, thisObject);
      do
      {
        objectInstance1 = objectInstance1.Prototype;
        if (objectInstance1 == null)
          return (JsValue) false;
      }
      while (objectInstance2 != objectInstance1);
      return (JsValue) true;
    }

    private JsValue ToLocaleString(JsValue thisObject, JsValue[] arguments)
    {
      ObjectInstance thisObject1 = TypeConverter.ToObject(this.Engine, thisObject);
      return thisObject1.Get("toString").TryCast<ICallable>((Action<JsValue>) (x =>
      {
        throw new JavaScriptException(this.Engine.TypeError);
      })).Call((JsValue) thisObject1, Arguments.Empty);
    }

    public JsValue ToObjectString(JsValue thisObject, JsValue[] arguments)
    {
      if (thisObject == Undefined.Instance)
        return (JsValue) "[object Undefined]";
      return thisObject == Null.Instance ? (JsValue) "[object Null]" : (JsValue) ("[object " + TypeConverter.ToObject(this.Engine, thisObject).Class + "]");
    }

    public JsValue HasOwnProperty(JsValue thisObject, JsValue[] arguments)
    {
      string propertyName = TypeConverter.ToString(arguments[0]);
      return (JsValue) (TypeConverter.ToObject(this.Engine, thisObject).GetOwnProperty(propertyName) != PropertyDescriptor.Undefined);
    }
  }
}
