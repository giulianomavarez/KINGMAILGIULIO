﻿// Decompiled with JetBrains decompiler
// Type: Jint.Native.Object.ObjectInstance
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using Jint.Runtime;
using Jint.Runtime.Descriptors;
using System.Collections.Generic;

#nullable disable
namespace Jint.Native.Object
{
  public class ObjectInstance
  {
    public ObjectInstance(Engine engine)
    {
      this.Engine = engine;
      this.Properties = (IDictionary<string, PropertyDescriptor>) new MruPropertyCache2<string, PropertyDescriptor>();
    }

    public Engine Engine { get; set; }

    protected IDictionary<string, PropertyDescriptor> Properties { get; private set; }

    public ObjectInstance Prototype { get; set; }

    public bool Extensible { get; set; }

    public virtual string Class => "Object";

    public virtual IEnumerable<KeyValuePair<string, PropertyDescriptor>> GetOwnProperties()
    {
      this.EnsureInitialized();
      return (IEnumerable<KeyValuePair<string, PropertyDescriptor>>) this.Properties;
    }

    public virtual bool HasOwnProperty(string p)
    {
      this.EnsureInitialized();
      return this.Properties.ContainsKey(p);
    }

    public virtual void RemoveOwnProperty(string p)
    {
      this.EnsureInitialized();
      this.Properties.Remove(p);
    }

    public virtual JsValue Get(string propertyName)
    {
      PropertyDescriptor property = this.GetProperty(propertyName);
      if (property == PropertyDescriptor.Undefined)
        return JsValue.Undefined;
      if (property.IsDataDescriptor())
      {
        JsValue jsValue = property.Value;
        return !(jsValue != (JsValue) null) ? Undefined.Instance : jsValue;
      }
      JsValue jsValue1 = property.Get != (JsValue) null ? property.Get : Undefined.Instance;
      return jsValue1.IsUndefined() ? Undefined.Instance : jsValue1.TryCast<ICallable>().Call((JsValue) this, Arguments.Empty);
    }

    public virtual PropertyDescriptor GetOwnProperty(string propertyName)
    {
      this.EnsureInitialized();
      PropertyDescriptor propertyDescriptor;
      return this.Properties.TryGetValue(propertyName, out propertyDescriptor) ? propertyDescriptor : PropertyDescriptor.Undefined;
    }

    protected virtual void SetOwnProperty(string propertyName, PropertyDescriptor desc)
    {
      this.EnsureInitialized();
      this.Properties[propertyName] = desc;
    }

    public PropertyDescriptor GetProperty(string propertyName)
    {
      PropertyDescriptor ownProperty = this.GetOwnProperty(propertyName);
      if (ownProperty != PropertyDescriptor.Undefined)
        return ownProperty;
      return this.Prototype == null ? PropertyDescriptor.Undefined : this.Prototype.GetProperty(propertyName);
    }

    public virtual void Put(string propertyName, JsValue value, bool throwOnError)
    {
      if (!this.CanPut(propertyName))
      {
        if (throwOnError)
          throw new JavaScriptException(this.Engine.TypeError);
      }
      else
      {
        PropertyDescriptor ownProperty = this.GetOwnProperty(propertyName);
        if (ownProperty.IsDataDescriptor())
        {
          ownProperty.Value = value;
        }
        else
        {
          PropertyDescriptor property = this.GetProperty(propertyName);
          if (property.IsAccessorDescriptor())
          {
            property.Set.TryCast<ICallable>().Call(new JsValue(this), new JsValue[1]
            {
              value
            });
          }
          else
          {
            PropertyDescriptor desc = new PropertyDescriptor(value, new bool?(true), new bool?(true), new bool?(true));
            this.DefineOwnProperty(propertyName, desc, throwOnError);
          }
        }
      }
    }

    public bool CanPut(string propertyName)
    {
      PropertyDescriptor ownProperty = this.GetOwnProperty(propertyName);
      if (ownProperty != PropertyDescriptor.Undefined)
      {
        if (ownProperty.IsAccessorDescriptor())
          return !(ownProperty.Set == (JsValue) null) && !ownProperty.Set.IsUndefined();
        bool? writable = ownProperty.Writable;
        if (!writable.HasValue)
          return false;
        writable = ownProperty.Writable;
        return writable.Value;
      }
      if (this.Prototype == null)
        return this.Extensible;
      PropertyDescriptor property = this.Prototype.GetProperty(propertyName);
      if (property == PropertyDescriptor.Undefined)
        return this.Extensible;
      if (property.IsAccessorDescriptor())
        return !(property.Set == (JsValue) null) && !property.Set.IsUndefined();
      if (!this.Extensible)
        return false;
      bool? writable1 = property.Writable;
      if (!writable1.HasValue)
        return false;
      writable1 = property.Writable;
      return writable1.Value;
    }

    public bool HasProperty(string propertyName)
    {
      return this.GetProperty(propertyName) != PropertyDescriptor.Undefined;
    }

    public virtual bool Delete(string propertyName, bool throwOnError)
    {
      PropertyDescriptor ownProperty = this.GetOwnProperty(propertyName);
      if (ownProperty == PropertyDescriptor.Undefined)
        return true;
      bool? configurable = ownProperty.Configurable;
      if (configurable.HasValue)
      {
        configurable = ownProperty.Configurable;
        if (configurable.Value)
        {
          this.RemoveOwnProperty(propertyName);
          return true;
        }
      }
      if (throwOnError)
        throw new JavaScriptException(this.Engine.TypeError);
      return false;
    }

    public JsValue DefaultValue(Types hint)
    {
      this.EnsureInitialized();
      if (hint == Types.String || hint == Types.None && this.Class == "Date")
      {
        ICallable callable = this.Get("toString").TryCast<ICallable>();
        if (callable != null)
        {
          JsValue jsValue = callable.Call(new JsValue(this), Arguments.Empty);
          if (jsValue.IsPrimitive())
            return jsValue;
        }
        JsValue jsValue1 = (this.Get("valueOf").TryCast<ICallable>() ?? throw new JavaScriptException(this.Engine.TypeError)).Call(new JsValue(this), Arguments.Empty);
        if (jsValue1.IsPrimitive())
          return jsValue1;
      }
      else if (hint == Types.Number || hint == Types.None)
      {
        ICallable callable = this.Get("valueOf").TryCast<ICallable>();
        if (callable != null)
        {
          JsValue jsValue = callable.Call(new JsValue(this), Arguments.Empty);
          if (jsValue.IsPrimitive())
            return jsValue;
        }
        JsValue jsValue2 = (this.Get("toString").TryCast<ICallable>() ?? throw new JavaScriptException(this.Engine.TypeError)).Call(new JsValue(this), Arguments.Empty);
        if (jsValue2.IsPrimitive())
          return jsValue2;
      }
      else
        return (JsValue) this.ToString();
    }

    public virtual bool DefineOwnProperty(
      string propertyName,
      PropertyDescriptor desc,
      bool throwOnError)
    {
      PropertyDescriptor propertyDescriptor = this.GetOwnProperty(propertyName);
      if (propertyDescriptor == desc)
        return true;
      if (propertyDescriptor == PropertyDescriptor.Undefined)
      {
        if (!this.Extensible)
        {
          if (throwOnError)
            throw new JavaScriptException(this.Engine.TypeError);
          return false;
        }
        if (desc.IsGenericDescriptor() || desc.IsDataDescriptor())
        {
          string propertyName1 = propertyName;
          PropertyDescriptor desc1 = new PropertyDescriptor(desc);
          desc1.Value = desc.Value != (JsValue) null ? desc.Value : JsValue.Undefined;
          bool? nullable;
          int num1;
          if (!desc.Writable.HasValue)
          {
            num1 = 0;
          }
          else
          {
            nullable = desc.Writable;
            num1 = nullable.Value ? 1 : 0;
          }
          desc1.Writable = new bool?(num1 != 0);
          nullable = desc.Enumerable;
          int num2;
          if (!nullable.HasValue)
          {
            num2 = 0;
          }
          else
          {
            nullable = desc.Enumerable;
            num2 = nullable.Value ? 1 : 0;
          }
          desc1.Enumerable = new bool?(num2 != 0);
          nullable = desc.Configurable;
          int num3;
          if (!nullable.HasValue)
          {
            num3 = 0;
          }
          else
          {
            nullable = desc.Configurable;
            num3 = nullable.Value ? 1 : 0;
          }
          desc1.Configurable = new bool?(num3 != 0);
          this.SetOwnProperty(propertyName1, desc1);
        }
        else
        {
          string propertyName2 = propertyName;
          PropertyDescriptor desc2 = new PropertyDescriptor(desc);
          desc2.Get = desc.Get;
          desc2.Set = desc.Set;
          bool? nullable = desc.Enumerable;
          desc2.Enumerable = nullable.HasValue ? desc.Enumerable : new bool?(false);
          nullable = desc.Configurable;
          desc2.Configurable = nullable.HasValue ? desc.Configurable : new bool?(false);
          this.SetOwnProperty(propertyName2, desc2);
        }
        return true;
      }
      bool? nullable1 = propertyDescriptor.Configurable;
      if (!nullable1.HasValue)
      {
        nullable1 = propertyDescriptor.Enumerable;
        if (!nullable1.HasValue)
        {
          nullable1 = propertyDescriptor.Writable;
          if (!nullable1.HasValue && propertyDescriptor.Get == (JsValue) null && propertyDescriptor.Set == (JsValue) null && propertyDescriptor.Value == (JsValue) null)
            return true;
        }
      }
      nullable1 = propertyDescriptor.Configurable;
      bool? nullable2 = desc.Configurable;
      if ((nullable1.GetValueOrDefault() == nullable2.GetValueOrDefault() ? (nullable1.HasValue == nullable2.HasValue ? 1 : 0) : 0) != 0)
      {
        nullable2 = propertyDescriptor.Writable;
        nullable1 = desc.Writable;
        if ((nullable2.GetValueOrDefault() == nullable1.GetValueOrDefault() ? (nullable2.HasValue == nullable1.HasValue ? 1 : 0) : 0) != 0)
        {
          nullable1 = propertyDescriptor.Enumerable;
          nullable2 = desc.Enumerable;
          if ((nullable1.GetValueOrDefault() == nullable2.GetValueOrDefault() ? (nullable1.HasValue == nullable2.HasValue ? 1 : 0) : 0) != 0 && (propertyDescriptor.Get == (JsValue) null && desc.Get == (JsValue) null || propertyDescriptor.Get != (JsValue) null && desc.Get != (JsValue) null && ExpressionInterpreter.SameValue(propertyDescriptor.Get, desc.Get)) && (propertyDescriptor.Set == (JsValue) null && desc.Set == (JsValue) null || propertyDescriptor.Set != (JsValue) null && desc.Set != (JsValue) null && ExpressionInterpreter.SameValue(propertyDescriptor.Set, desc.Set)) && (propertyDescriptor.Value == (JsValue) null && desc.Value == (JsValue) null || propertyDescriptor.Value != (JsValue) null && desc.Value != (JsValue) null && ExpressionInterpreter.StrictlyEqual(propertyDescriptor.Value, desc.Value)))
            return true;
        }
      }
      nullable2 = propertyDescriptor.Configurable;
      if (nullable2.HasValue)
      {
        nullable2 = propertyDescriptor.Configurable;
        if (nullable2.Value)
          goto label_41;
      }
      nullable2 = desc.Configurable;
      if (nullable2.HasValue)
      {
        nullable2 = desc.Configurable;
        if (nullable2.Value)
        {
          if (throwOnError)
            throw new JavaScriptException(this.Engine.TypeError);
          return false;
        }
      }
      nullable2 = desc.Enumerable;
      if (nullable2.HasValue)
      {
        nullable2 = propertyDescriptor.Enumerable;
        if (nullable2.HasValue)
        {
          nullable2 = desc.Enumerable;
          int num4 = nullable2.Value ? 1 : 0;
          nullable2 = propertyDescriptor.Enumerable;
          int num5 = nullable2.Value ? 1 : 0;
          if (num4 == num5)
            goto label_41;
        }
        if (throwOnError)
          throw new JavaScriptException(this.Engine.TypeError);
        return false;
      }
label_41:
      if (!desc.IsGenericDescriptor())
      {
        if (propertyDescriptor.IsDataDescriptor() != desc.IsDataDescriptor())
        {
          nullable2 = propertyDescriptor.Configurable;
          if (nullable2.HasValue)
          {
            nullable2 = propertyDescriptor.Configurable;
            if (nullable2.Value)
            {
              if (propertyDescriptor.IsDataDescriptor())
              {
                this.SetOwnProperty(propertyName, propertyDescriptor = new PropertyDescriptor(Undefined.Instance, Undefined.Instance, propertyDescriptor.Enumerable, propertyDescriptor.Configurable));
                goto label_72;
              }
              else
              {
                string propertyName3 = propertyName;
                JsValue instance = Undefined.Instance;
                nullable2 = new bool?();
                bool? writable = nullable2;
                bool? enumerable = propertyDescriptor.Enumerable;
                bool? configurable = propertyDescriptor.Configurable;
                PropertyDescriptor desc3;
                propertyDescriptor = desc3 = new PropertyDescriptor(instance, writable, enumerable, configurable);
                this.SetOwnProperty(propertyName3, desc3);
                goto label_72;
              }
            }
          }
          if (throwOnError)
            throw new JavaScriptException(this.Engine.TypeError);
          return false;
        }
        if (propertyDescriptor.IsDataDescriptor() && desc.IsDataDescriptor())
        {
          nullable2 = propertyDescriptor.Configurable;
          if (nullable2.HasValue)
          {
            nullable2 = propertyDescriptor.Configurable;
            if (nullable2.Value)
              goto label_72;
          }
          nullable2 = propertyDescriptor.Writable;
          if (nullable2.HasValue)
          {
            nullable2 = propertyDescriptor.Writable;
            if (!nullable2.Value)
            {
              nullable2 = desc.Writable;
              if (nullable2.HasValue)
              {
                nullable2 = desc.Writable;
                if (nullable2.Value)
                  goto label_58;
              }
            }
            nullable2 = propertyDescriptor.Writable;
            if (!nullable2.Value && desc.Value != (JsValue) null && !ExpressionInterpreter.SameValue(desc.Value, propertyDescriptor.Value))
            {
              if (throwOnError)
                throw new JavaScriptException(this.Engine.TypeError);
              return false;
            }
            goto label_72;
          }
label_58:
          if (throwOnError)
            throw new JavaScriptException(this.Engine.TypeError);
          return false;
        }
        if (propertyDescriptor.IsAccessorDescriptor() && desc.IsAccessorDescriptor())
        {
          nullable2 = propertyDescriptor.Configurable;
          if (nullable2.HasValue)
          {
            nullable2 = propertyDescriptor.Configurable;
            if (nullable2.Value)
              goto label_72;
          }
          if (desc.Set != (JsValue) null && !ExpressionInterpreter.SameValue(desc.Set, propertyDescriptor.Set != (JsValue) null ? propertyDescriptor.Set : Undefined.Instance) || desc.Get != (JsValue) null && !ExpressionInterpreter.SameValue(desc.Get, propertyDescriptor.Get != (JsValue) null ? propertyDescriptor.Get : Undefined.Instance))
          {
            if (throwOnError)
              throw new JavaScriptException(this.Engine.TypeError);
            return false;
          }
        }
      }
label_72:
      if (desc.Value != (JsValue) null)
        propertyDescriptor.Value = desc.Value;
      nullable2 = desc.Writable;
      if (nullable2.HasValue)
        propertyDescriptor.Writable = desc.Writable;
      nullable2 = desc.Enumerable;
      if (nullable2.HasValue)
        propertyDescriptor.Enumerable = desc.Enumerable;
      nullable2 = desc.Configurable;
      if (nullable2.HasValue)
        propertyDescriptor.Configurable = desc.Configurable;
      if (desc.Get != (JsValue) null)
        propertyDescriptor.Get = desc.Get;
      if (desc.Set != (JsValue) null)
        propertyDescriptor.Set = desc.Set;
      return true;
    }

    public void FastAddProperty(
      string name,
      JsValue value,
      bool writable,
      bool enumerable,
      bool configurable)
    {
      this.SetOwnProperty(name, new PropertyDescriptor(value, new bool?(writable), new bool?(enumerable), new bool?(configurable)));
    }

    public void FastSetProperty(string name, PropertyDescriptor value)
    {
      this.SetOwnProperty(name, value);
    }

    protected virtual void EnsureInitialized()
    {
    }

    public override string ToString() => TypeConverter.ToString((JsValue) this);
  }
}
