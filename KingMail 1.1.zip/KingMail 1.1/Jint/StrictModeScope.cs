﻿// Decompiled with JetBrains decompiler
// Type: Jint.StrictModeScope
// Assembly: Jint, Version=0.0.0.0, Culture=neutral, PublicKeyToken=2e92ba9c8d81157f
// MVID: F19D215D-E131-4151-B077-7F85EF6AFE48
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Jint.dll

using System;

#nullable disable
namespace Jint
{
  public class StrictModeScope : IDisposable
  {
    private readonly bool _strict;
    private readonly bool _force;
    private readonly int _forcedRefCount;
    [ThreadStatic]
    private static int _refCount;

    public StrictModeScope(bool strict = true, bool force = false)
    {
      this._strict = strict;
      this._force = force;
      if (this._force)
      {
        this._forcedRefCount = StrictModeScope._refCount;
        StrictModeScope._refCount = 0;
      }
      if (!this._strict)
        return;
      ++StrictModeScope._refCount;
    }

    public void Dispose()
    {
      if (this._strict)
        --StrictModeScope._refCount;
      if (!this._force)
        return;
      StrictModeScope._refCount = this._forcedRefCount;
    }

    public static bool IsStrictModeCode => StrictModeScope._refCount > 0;

    public static int RefCount
    {
      get => StrictModeScope._refCount;
      set => StrictModeScope._refCount = value;
    }
  }
}
