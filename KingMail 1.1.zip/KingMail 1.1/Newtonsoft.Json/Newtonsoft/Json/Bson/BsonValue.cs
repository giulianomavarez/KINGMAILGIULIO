﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Bson.BsonValue
// Assembly: Newtonsoft.Json, Version=13.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed
// MVID: F5C45804-81DF-4375-9EBF-446D5FFB33C1
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Newtonsoft.Json.dll

#nullable disable
namespace Newtonsoft.Json.Bson
{
  internal class BsonValue : BsonToken
  {
    private readonly object _value;
    private readonly BsonType _type;

    public BsonValue(object value, BsonType type)
    {
      this._value = value;
      this._type = type;
    }

    public object Value => this._value;

    public override BsonType Type => this._type;
  }
}
