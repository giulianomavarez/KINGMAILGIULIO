﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.JsonToken
// Assembly: Newtonsoft.Json, Version=13.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed
// MVID: F5C45804-81DF-4375-9EBF-446D5FFB33C1
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Newtonsoft.Json.dll

#nullable disable
namespace Newtonsoft.Json
{
  public enum JsonToken
  {
    None,
    StartObject,
    StartArray,
    StartConstructor,
    PropertyName,
    Comment,
    Raw,
    Integer,
    Float,
    String,
    Boolean,
    Null,
    Undefined,
    EndObject,
    EndArray,
    EndConstructor,
    Date,
    Bytes,
  }
}
