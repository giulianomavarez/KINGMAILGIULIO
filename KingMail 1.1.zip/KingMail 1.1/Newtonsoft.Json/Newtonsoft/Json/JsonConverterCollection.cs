﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.JsonConverterCollection
// Assembly: Newtonsoft.Json, Version=13.0.0.0, Culture=neutral, PublicKeyToken=30ad4fe6b2a6aeed
// MVID: F5C45804-81DF-4375-9EBF-446D5FFB33C1
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Newtonsoft.Json.dll

using System.Collections.ObjectModel;

#nullable enable
namespace Newtonsoft.Json
{
  public class JsonConverterCollection : Collection<JsonConverter>
  {
  }
}
