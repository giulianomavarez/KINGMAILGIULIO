﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.FileContent
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System;
using System.IO;

#nullable disable
namespace Leaf.xNet
{
  public class FileContent : StreamContent
  {
    public FileContent(string pathToContent, int bufferSize = 32768)
    {
      switch (pathToContent)
      {
        case null:
          throw new ArgumentNullException(nameof (pathToContent));
        case "":
          throw ExceptionHelper.EmptyString(nameof (pathToContent));
        default:
          if (bufferSize < 1)
            throw ExceptionHelper.CanNotBeLess<int>(nameof (bufferSize), 1);
          this.ContentStream = (Stream) new FileStream(pathToContent, FileMode.Open, FileAccess.Read);
          this.BufferSize = bufferSize;
          this.InitialStreamPosition = 0L;
          this.MimeContentType = Http.DetermineMediaType(Path.GetExtension(pathToContent));
          break;
      }
    }
  }
}
