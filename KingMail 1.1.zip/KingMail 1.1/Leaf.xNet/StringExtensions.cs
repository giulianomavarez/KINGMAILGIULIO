﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.StringExtensions
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

#nullable disable
namespace Leaf.xNet
{
  public static class StringExtensions
  {
    public const string HttpProto = "http://";
    public const string HttpsProto = "https://";
    private static NumberFormatInfo _thousandNumberFormatInfo;

    public static string[] BetweensOrEmpty(
      this string self,
      string left,
      string right,
      int startIndex = 0,
      StringComparison comparison = StringComparison.Ordinal,
      int limit = 0)
    {
      if (string.IsNullOrEmpty(self))
        return new string[0];
      if (string.IsNullOrEmpty(left))
        throw new ArgumentNullException(nameof (left));
      if (string.IsNullOrEmpty(right))
        throw new ArgumentNullException(nameof (right));
      if (startIndex < 0 || startIndex >= self.Length)
        throw new ArgumentOutOfRangeException(nameof (startIndex), "Wrong start index");
      int startIndex1 = startIndex;
      int num1 = limit;
      List<string> stringList = new List<string>();
      while (true)
      {
        if (limit > 0)
        {
          --num1;
          if (num1 < 0)
            break;
        }
        int num2 = self.IndexOf(left, startIndex1, comparison);
        if (num2 != -1)
        {
          int startIndex2 = num2 + left.Length;
          int num3 = self.IndexOf(right, startIndex2, comparison);
          if (num3 != -1)
          {
            int length = num3 - startIndex2;
            stringList.Add(self.Substring(startIndex2, length));
            startIndex1 = num3 + right.Length;
          }
          else
            break;
        }
        else
          break;
      }
      return stringList.ToArray();
    }

    public static string[] Betweens(
      this string self,
      string left,
      string right,
      int startIndex = 0,
      StringComparison comparison = StringComparison.Ordinal,
      int limit = 0)
    {
      string[] strArray = self.BetweensOrEmpty(left, right, startIndex, comparison, limit);
      return strArray.Length == 0 ? (string[]) null : strArray;
    }

    public static string[] BetweensEx(
      this string self,
      string left,
      string right,
      int startIndex = 0,
      StringComparison comparison = StringComparison.Ordinal,
      int limit = 0)
    {
      string[] strArray = self.BetweensOrEmpty(left, right, startIndex, comparison, limit);
      return strArray.Length != 0 ? strArray : throw new SubstringException("StringBetweens not found. Left: \"" + left + "\". Right: \"" + right + "\".");
    }

    public static string Between(
      this string self,
      string left,
      string right,
      int startIndex = 0,
      StringComparison comparison = StringComparison.Ordinal,
      string notFoundValue = null)
    {
      if (string.IsNullOrEmpty(self) || string.IsNullOrEmpty(left) || string.IsNullOrEmpty(right) || startIndex < 0 || startIndex >= self.Length)
        return notFoundValue;
      int num1 = self.IndexOf(left, startIndex, comparison);
      if (num1 == -1)
        return notFoundValue;
      int startIndex1 = num1 + left.Length;
      int num2 = self.IndexOf(right, startIndex1, comparison);
      return num2 == -1 ? notFoundValue : self.Substring(startIndex1, num2 - startIndex1);
    }

    public static string BetweenOrEmpty(
      this string self,
      string left,
      string right,
      int startIndex = 0,
      StringComparison comparison = StringComparison.Ordinal)
    {
      return self.Between(left, right, startIndex, comparison, string.Empty);
    }

    public static string BetweenEx(
      this string self,
      string left,
      string right,
      int startIndex = 0,
      StringComparison comparison = StringComparison.Ordinal)
    {
      return self.Between(left, right, startIndex, comparison) ?? throw new SubstringException("StringBetween not found. Left: \"" + left + "\". Right: \"" + right + "\".");
    }

    public static string BetweenLast(
      this string self,
      string right,
      string left,
      int startIndex = -1,
      StringComparison comparison = StringComparison.Ordinal,
      string notFoundValue = null)
    {
      if (string.IsNullOrEmpty(self) || string.IsNullOrEmpty(right) || string.IsNullOrEmpty(left) || startIndex < -1 || startIndex >= self.Length)
        return notFoundValue;
      if (startIndex == -1)
        startIndex = self.Length - 1;
      int num1 = self.LastIndexOf(right, startIndex, comparison);
      switch (num1)
      {
        case -1:
        case 0:
          return notFoundValue;
        default:
          int num2 = self.LastIndexOf(left, num1 - 1, comparison);
          if (num2 == -1 || num1 - num2 == 1)
            return notFoundValue;
          int startIndex1 = num2 + left.Length;
          return self.Substring(startIndex1, num1 - startIndex1);
      }
    }

    public static string BetweenLastOrEmpty(
      this string self,
      string right,
      string left,
      int startIndex = -1,
      StringComparison comparison = StringComparison.Ordinal)
    {
      return self.BetweenLast(right, left, startIndex, comparison, string.Empty);
    }

    public static string BetweenLastEx(
      this string self,
      string right,
      string left,
      int startIndex = -1,
      StringComparison comparison = StringComparison.Ordinal)
    {
      return self.BetweenLast(right, left, startIndex, comparison) ?? throw new SubstringException("StringBetween not found. Right: \"" + right + "\". Left: \"" + left + "\".");
    }

    public static string EncodeJsonUnicode(this string value)
    {
      StringBuilder stringBuilder = new StringBuilder();
      foreach (char ch in value)
      {
        if (ch <= '\u007F')
        {
          stringBuilder.Append(ch);
        }
        else
        {
          stringBuilder.Append("\\u");
          stringBuilder.Append(((int) ch).ToString("x4"));
        }
      }
      return stringBuilder.ToString();
    }

    public static string DecodeJsonUnicode(this string value)
    {
      return string.IsNullOrEmpty(value) ? string.Empty : Regex.Replace(value, "\\\\u([\\dA-Fa-f]{4})", (MatchEvaluator) (v => ((char) Convert.ToInt32(v.Groups[1].Value, 16)).ToString()));
    }

    public static string Win1251ToUTF8(this string source)
    {
      Encoding encoding = Encoding.GetEncoding("Windows-1251");
      byte[] bytes1 = encoding.GetBytes(source);
      byte[] bytes2 = Encoding.Convert(Encoding.UTF8, encoding, bytes1);
      return encoding.GetString(bytes2);
    }

    public static string After(
      this string self,
      string input,
      int startIndex = 0,
      StringComparison comparison = StringComparison.Ordinal,
      string notFoundValue = null)
    {
      if (string.IsNullOrEmpty(self) || string.IsNullOrEmpty(input) || startIndex < 0 || startIndex >= self.Length)
        return notFoundValue;
      int num = self.IndexOf(input, startIndex, comparison);
      if (num == -1)
        return notFoundValue;
      int startIndex1 = num + input.Length;
      return self.Substring(startIndex1, self.Length - startIndex1);
    }

    public static string AfterOrEmpty(
      this string self,
      string input,
      int startIndex = 0,
      StringComparison comparison = StringComparison.Ordinal)
    {
      return self.After(input, startIndex, comparison, string.Empty);
    }

    public static string AfterEx(
      this string self,
      string input,
      int startIndex = 0,
      StringComparison comparison = StringComparison.Ordinal)
    {
      return self.After(input, startIndex, comparison) ?? throw new SubstringException("string.After not found. Input: \"" + input + "\".");
    }

    public static string Before(
      this string self,
      string input,
      int startIndex = 0,
      StringComparison comparison = StringComparison.Ordinal,
      string notFoundValue = null)
    {
      if (string.IsNullOrEmpty(self) || string.IsNullOrEmpty(input) || startIndex < 0 || startIndex >= self.Length)
        return notFoundValue;
      int length = self.IndexOf(input, startIndex, comparison);
      return length != -1 ? self.Substring(0, length) : notFoundValue;
    }

    public static string BeforeOrEmpty(
      this string self,
      string input,
      int startIndex = 0,
      StringComparison comparison = StringComparison.Ordinal)
    {
      return self.Before(input, startIndex, comparison, string.Empty);
    }

    public static string BeforeEx(
      this string self,
      string input,
      int startIndex = 0,
      StringComparison comparison = StringComparison.Ordinal)
    {
      return self.Before(input, startIndex, comparison) ?? throw new SubstringException("string.Before not found. Input: \"" + input + "\".");
    }

    public static bool IsWebLink(this string self, bool trim = false)
    {
      string str = self;
      if (trim)
        str = str.Trim();
      return str.StartsWith("http://") || str.StartsWith("https://");
    }

    public static string NullOnEmpty(this string self)
    {
      return !(self == string.Empty) ? self : (string) null;
    }

    public static bool NullOrEmpty(this string self) => string.IsNullOrEmpty(self);

    public static bool NotNullNotEmpty(this string self) => !string.IsNullOrEmpty(self);

    public static bool HasContent(this string self) => !string.IsNullOrWhiteSpace(self);

    public static bool ContainsIgnoreCase(this string str, string value)
    {
      return str.IndexOf(value, StringComparison.OrdinalIgnoreCase) != -1;
    }

    public static bool Contains(
      this IReadOnlyList<string> self,
      string value,
      StringComparison comparison = StringComparison.Ordinal)
    {
      for (int index = 0; index < self.Count; ++index)
      {
        if (self[index].Equals(value, comparison))
          return true;
      }
      return false;
    }

    public static string ToUpperFirst(this string s, bool useToLower = true)
    {
      if (string.IsNullOrEmpty(s))
        return string.Empty;
      char upper = char.ToUpper(s[0]);
      string str = s.Substring(1);
      if (useToLower)
        str = str.ToLower();
      return upper.ToString() + str;
    }

    public static string GetJsonValue(this string json, string key, string endsWith = ",\"")
    {
      if (!(endsWith != "\""))
        return json.Between("\"" + key + "\":\"", "\"");
      return json.Between("\"" + key + "\":", endsWith)?.Trim('"', '\r', '\n', '\t');
    }

    public static string GetJsonValueEx(this string json, string key, string ending = ",\"")
    {
      return json.GetJsonValue(key, ending) ?? throw new SubstringException("Не найдено значение JSON ключа \"" + key + "\". Ответ: " + json);
    }

    public static byte[] HexStringToBytes(this string hexString)
    {
      int length = hexString.Length;
      byte[] bytes = new byte[length / 2];
      for (int startIndex = 0; startIndex < length; startIndex += 2)
        bytes[startIndex / 2] = Convert.ToByte(hexString.Substring(startIndex, 2), 16);
      return bytes;
    }

    public static string EscapeJsonData(this string jsonData, bool escapeUnicode)
    {
      string str = jsonData.Replace("\\", "\\\\").Replace("\"", "\\\"");
      if (escapeUnicode)
        str = str.EncodeJsonUnicode();
      return str;
    }

    public static NumberFormatInfo ThousandNumberFormatInfo
    {
      get
      {
        if (StringExtensions._thousandNumberFormatInfo == null)
        {
          StringExtensions._thousandNumberFormatInfo = (NumberFormatInfo) CultureInfo.InvariantCulture.NumberFormat.Clone();
          StringExtensions._thousandNumberFormatInfo.NumberGroupSeparator = " ";
        }
        return StringExtensions._thousandNumberFormatInfo;
      }
    }

    public static string InnerHtmlByClass(
      this string self,
      string className,
      int startIndex = 0,
      StringComparison comparison = StringComparison.Ordinal,
      string notFoundValue = null)
    {
      string result = notFoundValue;
      StringExtensions.GetInnerHtmlByClass(self, className, ref result, startIndex, comparison);
      return result;
    }

    public static string InnerHtmlByAttribute(
      this string self,
      string attribute,
      string value,
      int startIndex = 0,
      StringComparison comparison = StringComparison.Ordinal,
      string notFoundValue = null)
    {
      string result = notFoundValue;
      StringExtensions.GetInnerHtmlByAttribute(self, attribute, value, ref result, startIndex, comparison);
      return result;
    }

    public static string[] InnerHtmlByClassAll(
      this string self,
      string className,
      int startIndex = 0,
      bool trim = false,
      StringComparison comparison = StringComparison.Ordinal)
    {
      int startIndex1 = startIndex;
      string result = string.Empty;
      List<string> stringList = new List<string>();
      for (; (startIndex1 = StringExtensions.GetInnerHtmlByClass(self, className, ref result, startIndex1, comparison)) != -1; result = string.Empty)
      {
        if (trim)
          result = result.Trim();
        stringList.Add(result);
      }
      return stringList.ToArray();
    }

    private static bool HasSubstring(
      this string self,
      string left,
      string right,
      out string substring,
      out int beginSubstringIndex,
      int startIndex = 0,
      StringComparison comparison = StringComparison.Ordinal)
    {
      substring = (string) null;
      beginSubstringIndex = -1;
      if (string.IsNullOrEmpty(self) || string.IsNullOrEmpty(left) || string.IsNullOrEmpty(right) || startIndex < 0 || startIndex >= self.Length)
        return false;
      int num1 = self.IndexOf(left, startIndex, comparison);
      if (num1 == -1)
        return false;
      int startIndex1 = num1 + left.Length;
      int num2 = self.IndexOf(right, startIndex1, comparison);
      if (num2 == -1)
        return false;
      substring = self.Substring(startIndex1, num2 - startIndex1);
      beginSubstringIndex = num1;
      return true;
    }

    private static int GetInnerHtmlByAttribute(
      string self,
      string attribute,
      string value,
      ref string result,
      int startIndex = 0,
      StringComparison comparison = StringComparison.Ordinal)
    {
      string substring;
      int beginSubstringIndex;
      while (self.HasSubstring(attribute + "=\"", "\"", out substring, out beginSubstringIndex, startIndex, comparison))
      {
        startIndex += attribute.Length + value.Length + 1;
        substring = substring.Trim();
        if (!(value == string.Empty))
        {
          if (((IReadOnlyList<string>) substring.Split(new char[3]
          {
            '\n',
            '\t',
            ' '
          }, StringSplitOptions.RemoveEmptyEntries)).Contains(value, comparison))
          {
            int num1 = self.LastIndexOf("<", beginSubstringIndex - 1, StringComparison.Ordinal);
            if (num1 != -1)
            {
              string str = self.Substring(num1 + 1, beginSubstringIndex - num1 - 2).Split(new char[3]
              {
                ' ',
                '\t',
                '\n'
              }, 2)[0];
              if (!string.IsNullOrEmpty(str))
              {
                int length = str.Length;
                int num2 = self.IndexOf(">", beginSubstringIndex + attribute.Length + value.Length + 1, StringComparison.InvariantCulture);
                if (num2 != -1)
                {
                  int startIndex1 = num2 + 1;
                  int num3 = 0;
                  int num4 = self.Length - 1;
                  for (int index = startIndex1; index < num4; ++index)
                  {
                    if (self[index] == '<')
                    {
                      int num5 = index + 1;
                      int num6;
                      if (self[num5] == '/')
                      {
                        ++num5;
                        num6 = -1;
                      }
                      else
                        num6 = 1;
                      if (num5 + length <= num4)
                      {
                        if ((int) self[num5] == (int) str[0] && !(str != self.Substring(num5, length)))
                        {
                          num3 += num6;
                          if (num3 == -1)
                          {
                            result = self.Substring(startIndex1, index - startIndex1);
                            int num7 = beginSubstringIndex + result.Length;
                            return num7 < self.Length ? num7 : -1;
                          }
                        }
                      }
                      else
                        break;
                    }
                  }
                }
              }
            }
          }
        }
      }
      return -1;
    }

    private static int GetInnerHtmlByClass(
      string self,
      string className,
      ref string result,
      int startIndex = 0,
      StringComparison comparison = StringComparison.Ordinal)
    {
      return StringExtensions.GetInnerHtmlByAttribute(self, "class", className, ref result, startIndex, comparison);
    }
  }
}
