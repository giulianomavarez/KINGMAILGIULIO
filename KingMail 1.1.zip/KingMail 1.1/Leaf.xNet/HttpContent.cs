﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.HttpContent
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System;
using System.IO;

#nullable disable
namespace Leaf.xNet
{
  public abstract class HttpContent : IDisposable
  {
    protected string MimeContentType = string.Empty;

    public string ContentType
    {
      get => this.MimeContentType;
      set => this.MimeContentType = value ?? string.Empty;
    }

    public abstract long CalculateContentLength();

    public abstract void WriteTo(Stream stream);

    public void Dispose() => this.Dispose(true);

    protected virtual void Dispose(bool disposing)
    {
    }
  }
}
