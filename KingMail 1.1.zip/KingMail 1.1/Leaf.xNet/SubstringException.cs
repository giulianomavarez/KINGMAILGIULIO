﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.SubstringException
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System;

#nullable disable
namespace Leaf.xNet
{
  public class SubstringException : Exception
  {
    public SubstringException()
    {
    }

    public SubstringException(string message)
      : base(message)
    {
    }

    public SubstringException(string message, Exception innerException)
      : base(message, innerException)
    {
    }
  }
}
