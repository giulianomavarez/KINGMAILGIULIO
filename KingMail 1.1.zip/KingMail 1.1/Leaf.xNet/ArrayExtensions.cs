﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.ArrayExtensions
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace Leaf.xNet
{
  public static class ArrayExtensions
  {
    public static T[] Shuffle<T>(this T[] self)
    {
      if (self == null || self.Length <= 1)
        return self;
      T[] objArray;
      do
      {
        objArray = new T[self.Length];
        Array.Copy((Array) self, (Array) objArray, self.Length);
        int length = objArray.Length;
        while (length > 1)
        {
          int index = Randomizer.Instance.Next(length);
          --length;
          T obj = objArray[length];
          objArray[length] = objArray[index];
          objArray[index] = obj;
        }
      }
      while (((IEnumerable<T>) objArray).SequenceEqual<T>((IEnumerable<T>) self));
      return objArray;
    }
  }
}
