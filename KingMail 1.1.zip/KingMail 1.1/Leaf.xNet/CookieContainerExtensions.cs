﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.CookieContainerExtensions
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Reflection;

#nullable disable
namespace Leaf.xNet
{
  public static class CookieContainerExtensions
  {
    public static Cookie Get(this CookieContainer self, string name, StringComparison comparison = StringComparison.Ordinal)
    {
      return string.IsNullOrEmpty(name) ? (Cookie) null : self.Find((Predicate<Cookie>) (c => c.Name.Equals(name, comparison)));
    }

    public static Cookie Get(
      this CookieContainer self,
      Uri uri,
      string name,
      StringComparison comparison = StringComparison.Ordinal)
    {
      if (uri == (Uri) null || string.IsNullOrEmpty(name))
        return (Cookie) null;
      foreach (Cookie cookie in self.GetCookies(uri))
      {
        if (cookie.Name.Equals(name, comparison))
          return cookie;
      }
      return (Cookie) null;
    }

    public static Cookie Get(
      this CookieContainer self,
      string url,
      string name,
      StringComparison comparison = StringComparison.Ordinal)
    {
      if (string.IsNullOrEmpty(url) || string.IsNullOrEmpty(name))
        return (Cookie) null;
      Uri result;
      return !Uri.TryCreate(url, UriKind.RelativeOrAbsolute, out result) ? (Cookie) null : self.Get(result, name, comparison);
    }

    public static HashSet<Cookie> GetAll(this CookieContainer self)
    {
      HashSet<Cookie> cookies = new HashSet<Cookie>();
      self.ForEach((Action<Cookie>) (cookie => cookies.Add(cookie)));
      return cookies;
    }

    public static CookieCollection GetAll(this CookieContainer self, Uri uri)
    {
      return !(uri != (Uri) null) ? new CookieCollection() : self.GetCookies(uri);
    }

    public static bool Contains(
      this CookieContainer self,
      string name,
      StringComparison comparison = StringComparison.Ordinal)
    {
      return self.Get(name, comparison) != null;
    }

    public static bool Contains(
      this CookieContainer self,
      Uri uri,
      string name,
      StringComparison comparison = StringComparison.Ordinal)
    {
      return self.Get(uri, name, comparison) != null;
    }

    public static bool Contains(
      this CookieContainer self,
      string url,
      string name,
      StringComparison comparison = StringComparison.Ordinal)
    {
      return self.Get(url, name, comparison) != null;
    }

    public static Cookie Find(this CookieContainer self, Predicate<Cookie> predicate)
    {
      Hashtable hashtable = (Hashtable) self.GetType().InvokeMember("m_domainTable", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.GetField, (Binder) null, (object) self, new object[0]);
      foreach (object key in (IEnumerable) hashtable.Keys)
      {
        object obj = hashtable[key];
        ICollection collection = (ICollection) obj.GetType().GetProperty("Values")?.GetGetMethod().Invoke(obj, (object[]) null);
        if (collection != null)
        {
          foreach (CookieCollection cookieCollection in (IEnumerable) collection)
          {
            foreach (Cookie cookie in cookieCollection)
            {
              if (predicate(cookie))
                return cookie;
            }
          }
        }
      }
      return (Cookie) null;
    }

    public static Cookie Find(this CookieContainer self, Uri uri, Predicate<Cookie> predicate)
    {
      if (uri == (Uri) null)
        return (Cookie) null;
      foreach (Cookie cookie in self.GetCookies(uri))
      {
        if (predicate(cookie))
          return cookie;
      }
      return (Cookie) null;
    }

    public static Cookie Find(this CookieContainer self, string url, Predicate<Cookie> predicate)
    {
      if (string.IsNullOrEmpty(url))
        return (Cookie) null;
      Uri result;
      return !Uri.TryCreate(url, UriKind.RelativeOrAbsolute, out result) ? (Cookie) null : self.Find(result, predicate);
    }

    public static bool Exists(this CookieContainer self, Predicate<Cookie> predicate)
    {
      return self.Find(predicate) != null;
    }

    public static bool Exists(this CookieContainer self, Uri uri, Predicate<Cookie> predicate)
    {
      return self.Find(uri, predicate) != null;
    }

    public static bool Exists(this CookieContainer self, string url, Predicate<Cookie> predicate)
    {
      return self.Find(url, predicate) != null;
    }

    public static HashSet<Cookie> FindAll(this CookieContainer self, Predicate<Cookie> predicate)
    {
      HashSet<Cookie> cookies = new HashSet<Cookie>();
      self.ForEach((Action<Cookie>) (cookie =>
      {
        if (!predicate(cookie))
          return;
        cookies.Add(cookie);
      }));
      return cookies;
    }

    public static HashSet<Cookie> FindAll(
      this CookieContainer self,
      Uri uri,
      Predicate<Cookie> predicate)
    {
      HashSet<Cookie> all = new HashSet<Cookie>();
      if (uri == (Uri) null)
        return all;
      foreach (Cookie cookie in self.GetCookies(uri))
      {
        if (predicate(cookie))
          all.Add(cookie);
      }
      return all;
    }

    public static HashSet<Cookie> FindAll(
      this CookieContainer self,
      string url,
      Predicate<Cookie> predicate)
    {
      Uri result;
      return string.IsNullOrEmpty(url) || !Uri.TryCreate(url, UriKind.RelativeOrAbsolute, out result) ? new HashSet<Cookie>() : self.FindAll(result, predicate);
    }

    public static void ForEach(this CookieContainer self, Action<Cookie> action)
    {
      HashSet<Cookie> cookieSet = new HashSet<Cookie>();
      Hashtable hashtable = (Hashtable) self.GetType().InvokeMember("m_domainTable", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.GetField, (Binder) null, (object) self, new object[0]);
      foreach (object key in (IEnumerable) hashtable.Keys)
      {
        object obj = hashtable[key];
        ICollection collection = (ICollection) obj.GetType().GetProperty("Values")?.GetGetMethod().Invoke(obj, (object[]) null);
        if (collection != null)
        {
          foreach (CookieCollection cookieCollection in (IEnumerable) collection)
          {
            foreach (Cookie cookie in cookieCollection)
            {
              if (!cookieSet.Contains(cookie))
              {
                action(cookie);
                cookieSet.Add(cookie);
              }
            }
          }
        }
      }
    }

    public static void ForEach(this CookieContainer self, Uri uri, Action<Cookie> action)
    {
      if (uri == (Uri) null)
        return;
      foreach (Cookie cookie in self.GetCookies(uri))
        action(cookie);
    }

    public static void ForEach(this CookieContainer self, string url, Action<Cookie> action)
    {
      Uri result;
      if (string.IsNullOrEmpty(url) || !Uri.TryCreate(url, UriKind.RelativeOrAbsolute, out result))
        return;
      self.ForEach(result, action);
    }

    public static bool Set(this CookieContainer self, Uri uri, Cookie cookie)
    {
      if (uri == (Uri) null || cookie == null || string.IsNullOrEmpty(cookie.Name))
        return false;
      foreach (Cookie cookie1 in self.GetCookies(uri))
      {
        if (!(cookie1.Name != cookie.Name))
        {
          cookie1.Expired = true;
          break;
        }
      }
      if (cookie.Value == null)
        cookie.Value = string.Empty;
      self.Add(uri, cookie);
      return true;
    }

    public static bool Set(this CookieContainer self, Uri uri, string name, string value)
    {
      return !(uri == (Uri) null) && !string.IsNullOrEmpty(name) && self.Set(uri, new Cookie(name, value ?? string.Empty));
    }

    public static bool Set(this CookieContainer self, string url, string name, string value)
    {
      Uri result;
      return !string.IsNullOrEmpty(url) && Uri.TryCreate(url, UriKind.RelativeOrAbsolute, out result) && self.Set(result, name, value);
    }

    public static void Clear(this CookieContainer self)
    {
      self.ForEach((Action<Cookie>) (c => c.Expired = true));
    }

    public static void Clear(this CookieContainer self, Uri uri)
    {
      if (uri == (Uri) null)
        return;
      foreach (Cookie cookie in self.GetCookies(uri))
        cookie.Expired = true;
    }

    public static void Clear(this CookieContainer self, string url)
    {
      Uri result;
      if (string.IsNullOrEmpty(url) || !Uri.TryCreate(url, UriKind.RelativeOrAbsolute, out result))
        return;
      self.Clear(result);
    }

    public static bool Remove(
      this CookieContainer self,
      Uri uri,
      string name,
      StringComparison comparison = StringComparison.Ordinal)
    {
      if (uri == (Uri) null || string.IsNullOrEmpty(name))
        return false;
      foreach (Cookie cookie in self.GetCookies(uri))
      {
        if (cookie.Name.Equals(name, comparison))
        {
          cookie.Expired = true;
          return true;
        }
      }
      return false;
    }

    public static bool Remove(
      this CookieContainer self,
      string url,
      string name,
      StringComparison comparison = StringComparison.Ordinal)
    {
      Uri result;
      return !string.IsNullOrEmpty(url) && Uri.TryCreate(url, UriKind.RelativeOrAbsolute, out result) && self.Remove(result, name, comparison);
    }

    public static uint Remove(this CookieContainer self, string name, StringComparison comparison = StringComparison.Ordinal)
    {
      uint deleted = 0;
      self.ForEach((Action<Cookie>) (cookie =>
      {
        if (!cookie.Name.Equals(name, comparison))
          return;
        cookie.Expired = true;
        ++deleted;
      }));
      return deleted;
    }

    public static uint RemoveByValue(
      this CookieContainer self,
      string value,
      StringComparison comparison = StringComparison.Ordinal)
    {
      uint deleted = 0;
      self.ForEach((Action<Cookie>) (cookie =>
      {
        if (!cookie.Value.Equals(value, comparison))
          return;
        cookie.Expired = true;
        ++deleted;
      }));
      return deleted;
    }

    public static uint RemoveByValueContains(
      this CookieContainer self,
      string value,
      StringComparison comparison = StringComparison.OrdinalIgnoreCase)
    {
      uint deleted = 0;
      self.ForEach((Action<Cookie>) (cookie =>
      {
        if (cookie.Value.IndexOf(value, comparison) == -1)
          return;
        cookie.Expired = true;
        ++deleted;
      }));
      return deleted;
    }
  }
}
