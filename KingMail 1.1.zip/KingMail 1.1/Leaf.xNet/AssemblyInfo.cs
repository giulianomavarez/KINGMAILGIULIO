﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: Extension]
[assembly: AssemblyCompany("Kelog")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyCopyright("© 2018-2022 Developed by Grand Silence — Kelog Studio")]
[assembly: AssemblyDescription("Improved xNet for .NET Framework 4.6.1+")]
[assembly: AssemblyFileVersion("7.0.54.0")]
[assembly: AssemblyInformationalVersion("7.0.54")]
[assembly: AssemblyProduct("Leaf")]
[assembly: AssemblyTitle("Leaf.xNet")]
[assembly: AssemblyMetadata("RepositoryUrl", "https://github.com/csharp-leaf/Leaf.xNet")]
[assembly: AssemblyVersion("7.0.54.0")]
