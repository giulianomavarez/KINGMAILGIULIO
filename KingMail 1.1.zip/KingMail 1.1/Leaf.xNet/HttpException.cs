﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.HttpException
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System;
using System.Runtime.Serialization;
using System.Security.Permissions;

#nullable disable
namespace Leaf.xNet
{
  [Serializable]
  public sealed class HttpException : NetException
  {
    public HttpExceptionStatus Status { get; internal set; }

    public HttpStatusCode HttpStatusCode { get; }

    internal bool EmptyMessageBody { get; set; }

    public HttpException()
      : this(Resources.HttpException_Default)
    {
    }

    public HttpException(string message, Exception innerException = null)
      : base(message, innerException)
    {
    }

    public HttpException(
      string message,
      HttpExceptionStatus status,
      HttpStatusCode httpStatusCode = HttpStatusCode.None,
      Exception innerException = null)
      : base(message, innerException)
    {
      this.Status = status;
      this.HttpStatusCode = httpStatusCode;
    }

    public HttpException(SerializationInfo serializationInfo, StreamingContext streamingContext)
      : base(serializationInfo, streamingContext)
    {
      if (serializationInfo == null)
        return;
      this.Status = (HttpExceptionStatus) serializationInfo.GetInt32(nameof (Status));
      this.HttpStatusCode = (HttpStatusCode) serializationInfo.GetInt32(nameof (HttpStatusCode));
    }

    [SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.SerializationFormatter)]
    public override void GetObjectData(
      SerializationInfo serializationInfo,
      StreamingContext streamingContext)
    {
      base.GetObjectData(serializationInfo, streamingContext);
      serializationInfo.AddValue("Status", (int) this.Status);
      serializationInfo.AddValue("HttpStatusCode", (int) this.HttpStatusCode);
      serializationInfo.AddValue("EmptyMessageBody", this.EmptyMessageBody);
    }
  }
}
