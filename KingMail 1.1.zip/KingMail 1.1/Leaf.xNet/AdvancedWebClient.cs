﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.AdvancedWebClient
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

#nullable disable
namespace Leaf.xNet
{
  public class AdvancedWebClient : WebClient
  {
    public int Timeout { get; set; } = 10000;

    public int ReadWriteTimeout { get; set; } = 10000;

    public DecompressionMethods DecompressionMethods { get; set; } = DecompressionMethods.GZip | DecompressionMethods.Deflate;

    public bool ServerCertificateValidation { get; set; }

    protected override WebRequest GetWebRequest(Uri uri)
    {
      WebRequest webRequest = base.GetWebRequest(uri);
      if (webRequest == null)
        throw new NullReferenceException("Null reference: unable to get instance of WebRequest in AdvancedWebClient.");
      webRequest.Timeout = this.Timeout;
      HttpWebRequest httpWebRequest = (HttpWebRequest) webRequest;
      httpWebRequest.ReadWriteTimeout = this.ReadWriteTimeout;
      httpWebRequest.AutomaticDecompression = this.DecompressionMethods;
      if (this.ServerCertificateValidation)
        return webRequest;
      httpWebRequest.ServerCertificateValidationCallback += new RemoteCertificateValidationCallback(AdvancedWebClient.ServerCertificateValidationCallback);
      return webRequest;
    }

    private static bool ServerCertificateValidationCallback(
      object sender,
      X509Certificate certificate,
      X509Chain chain,
      SslPolicyErrors sslpolicyerrors)
    {
      return true;
    }
  }
}
