﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.HttpHeader
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

#nullable disable
namespace Leaf.xNet
{
  public enum HttpHeader
  {
    Accept,
    AcceptCharset,
    AcceptLanguage,
    AcceptDatetime,
    CacheControl,
    ContentType,
    Date,
    Expect,
    From,
    IfMatch,
    IfModifiedSince,
    IfNoneMatch,
    IfRange,
    IfUnmodifiedSince,
    MaxForwards,
    Pragma,
    Range,
    Referer,
    Origin,
    Upgrade,
    UpgradeInsecureRequests,
    UserAgent,
    Via,
    Warning,
    DNT,
    AccessControlAllowOrigin,
    AcceptRanges,
    Age,
    Allow,
    ContentEncoding,
    ContentLanguage,
    ContentLength,
    ContentLocation,
    ContentMD5,
    ContentDisposition,
    ContentRange,
    ETag,
    Expires,
    LastModified,
    Link,
    Location,
    P3P,
    Refresh,
    RetryAfter,
    Server,
    TransferEncoding,
    SecFetchDest,
    SecFetchMode,
    SecFetchSite,
    SecFetchUser,
  }
}
