﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.NetException
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System;
using System.Runtime.Serialization;

#nullable disable
namespace Leaf.xNet
{
  [Serializable]
  public class NetException : Exception
  {
    public NetException()
      : this(Resources.NetException_Default)
    {
    }

    public NetException(string message, Exception innerException = null)
      : base(message, innerException)
    {
    }

    protected NetException(SerializationInfo serializationInfo, StreamingContext streamingContext)
      : base(serializationInfo, streamingContext)
    {
    }
  }
}
