﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.Captcha.RecaptchaArgs
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System;
using System.Globalization;

#nullable disable
namespace Leaf.xNet.Captcha
{
  public class RecaptchaArgs
  {
    public readonly string SiteKey;
    public readonly string SiteUrl;

    public Decimal MinScore { get; set; } = 0.3M;

    public string MinScoreForm
    {
      get => this.MinScore.ToString("0.0", (IFormatProvider) CultureInfo.InvariantCulture);
    }

    public bool Invisible { get; set; }

    public string InvisibleForm => !this.Invisible ? "0" : "1";

    public RecaptchaArgs(string siteKey, string siteUrl)
    {
      this.SiteKey = siteKey;
      this.SiteUrl = siteUrl;
    }

    public virtual void Validate()
    {
      this.MustBeFilled("SiteKey", this.SiteKey);
      this.MustBeFilled("SiteUrl", this.SiteUrl);
    }

    protected void MustBeFilled(string name, string value)
    {
      Type type = this.GetType();
      if (string.IsNullOrEmpty(value))
        throw new ArgumentException(string.Format("Invalid argument: \"{0}\" = {1} when called \"{2}.{3}\"", (object) name, (object) (value ?? "null"), (object) type, (object) "Validate"), name);
    }
  }
}
