﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.Captcha.Classic.CaptchaProxyType
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

#nullable disable
namespace Leaf.xNet.Captcha.Classic
{
  public enum CaptchaProxyType
  {
    HTTP,
    HTTPS,
    SOCKS4,
    SOCKS5,
  }
}
