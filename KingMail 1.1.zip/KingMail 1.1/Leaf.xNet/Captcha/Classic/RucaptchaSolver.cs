﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.Captcha.Classic.RucaptchaSolver
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System.Collections.Specialized;
using System.Text;
using System.Threading;

#nullable disable
namespace Leaf.xNet.Captcha.Classic
{
  public class RucaptchaSolver : BaseClassicCaptchaSolver
  {
    public string Host { get; protected set; } = "rucaptcha.com";

    public CaptchaProxy Proxy { get; set; }

    public string SolveImageFromBase64(
      string imageBase64,
      NameValueCollection parameters,
      CancellationToken cancelToken = default (CancellationToken))
    {
      NameValueCollection data = new NameValueCollection()
      {
        {
          "key",
          this.ApiKey
        },
        {
          "method",
          "base64"
        },
        {
          "body",
          imageBase64
        }
      };
      if (parameters != null)
      {
        parameters.Remove("key");
        parameters.Remove("method");
        parameters.Remove("body");
        data.Add(parameters);
      }
      string message = "unknown";
      bool flag1 = true;
      for (int index = 0; (long) index < (long) this.UploadRetries; ++index)
      {
        cancelToken.ThrowIfCancellationRequested();
        message = Encoding.UTF8.GetString(this.Http.UploadValues("http://" + this.Host + "/in.php", data));
        if (!message.Contains("ERROR_NO_SLOT_AVAILABLE"))
        {
          flag1 = !message.Contains("OK|");
          break;
        }
        this.Delay(this.UploadDelayOnNoSlotAvailable, cancelToken);
      }
      if (flag1)
        throw new CaptchaException(message);
      string str1 = message.Replace("OK|", "").Trim();
      bool flag2 = true;
      this.Delay(this.BeforeStatusCheckingDelay, cancelToken);
      for (int index = 0; (long) index < (long) this.StatusRetries; ++index)
      {
        message = this.Http.DownloadString("http://" + this.Host + "/res.php?key=" + this.ApiKey + "&action=get&id=" + str1);
        if (!message.Contains("CAPCHA_NOT_READY"))
        {
          flag2 = !message.Contains("OK|");
          break;
        }
        this.Delay(this.StatusDelayOnNotReady, cancelToken);
      }
      cancelToken.ThrowIfCancellationRequested();
      if (flag2)
        throw new CaptchaException(message);
      string str2 = message.Replace("OK|", "");
      return !string.IsNullOrEmpty(str2) ? str2 : throw new CaptchaException(CaptchaError.EmptyResponse);
    }

    public override string SolveImageFromBase64(string imageBase64, CancellationToken cancelToken = default (CancellationToken))
    {
      return this.SolveImageFromBase64(imageBase64, (NameValueCollection) null, cancelToken);
    }

    public override string SolveRecaptcha(RecaptchaArgs args, CancellationToken cancelToken = default (CancellationToken))
    {
      this.ThrowIfApiKeyRequiredAndInvalid();
      args.Validate();
      NameValueCollection data = new NameValueCollection()
      {
        {
          "key",
          this.ApiKey
        },
        {
          "method",
          "userrecaptcha"
        },
        {
          "invisible",
          args.InvisibleForm
        },
        {
          "min_score",
          args.MinScoreForm
        },
        {
          "googlekey",
          args.SiteKey
        },
        {
          "pageurl",
          args.SiteUrl
        }
      };
      if (this.Proxy.IsValid)
      {
        data.Add("proxy", this.Proxy.Address);
        data.Add("proxytype", this.Proxy.Type.ToString());
      }
      string message = "unknown";
      bool flag1 = true;
      for (int index = 0; (long) index < (long) this.UploadRetries; ++index)
      {
        cancelToken.ThrowIfCancellationRequested();
        message = Encoding.UTF8.GetString(this.Http.UploadValues("http://" + this.Host + "/in.php", data));
        if (!message.Contains("ERROR_NO_SLOT_AVAILABLE"))
        {
          flag1 = !message.Contains("OK|");
          break;
        }
        this.Delay(this.UploadDelayOnNoSlotAvailable, cancelToken);
      }
      if (flag1)
        throw new CaptchaException(message);
      string str1 = message.Replace("OK|", "").Trim();
      bool flag2 = true;
      this.Delay(this.BeforeStatusCheckingDelay, cancelToken);
      for (int index = 0; (long) index < (long) this.StatusRetries; ++index)
      {
        message = this.Http.DownloadString("http://" + this.Host + "/res.php?key=" + this.ApiKey + "&action=get&id=" + str1);
        if (!message.Contains("CAPCHA_NOT_READY"))
        {
          flag2 = !message.Contains("OK|");
          break;
        }
        this.Delay(this.StatusDelayOnNotReady, cancelToken);
      }
      cancelToken.ThrowIfCancellationRequested();
      if (flag2)
        throw new CaptchaException(message);
      string str2 = message.Replace("OK|", "");
      return !string.IsNullOrEmpty(str2) ? str2 : throw new CaptchaException(CaptchaError.EmptyResponse);
    }

    public override string SolveRecaptchaV3(RecaptchaV3Args args, CancellationToken cancelToken = default (CancellationToken))
    {
      this.ThrowIfApiKeyRequiredAndInvalid();
      args.Validate();
      NameValueCollection data = new NameValueCollection()
      {
        {
          "key",
          this.ApiKey
        },
        {
          "method",
          "userrecaptcha"
        },
        {
          "version",
          "v3"
        },
        {
          "action",
          args.Action
        },
        {
          "invisible",
          args.InvisibleForm
        },
        {
          "min_score",
          args.MinScoreForm
        },
        {
          "googlekey",
          args.SiteKey
        },
        {
          "pageurl",
          args.SiteUrl
        }
      };
      if (this.Proxy.IsValid)
      {
        data.Add("proxy", this.Proxy.Address);
        data.Add("proxytype", this.Proxy.Type.ToString());
      }
      string message = "unknown";
      bool flag1 = true;
      for (int index = 0; (long) index < (long) this.UploadRetries; ++index)
      {
        cancelToken.ThrowIfCancellationRequested();
        message = Encoding.UTF8.GetString(this.Http.UploadValues("http://" + this.Host + "/in.php", data));
        if (!message.Contains("ERROR_NO_SLOT_AVAILABLE"))
        {
          flag1 = !message.Contains("OK|");
          break;
        }
        this.Delay(this.UploadDelayOnNoSlotAvailable, cancelToken);
      }
      if (flag1)
        throw new CaptchaException(message);
      string str1 = message.Replace("OK|", "").Trim();
      bool flag2 = true;
      this.Delay(this.BeforeStatusCheckingDelay, cancelToken);
      for (int index = 0; (long) index < (long) this.StatusRetries; ++index)
      {
        message = this.Http.DownloadString("http://" + this.Host + "/res.php?key=" + this.ApiKey + "&action=get&id=" + str1);
        if (!message.Contains("CAPCHA_NOT_READY"))
        {
          flag2 = !message.Contains("OK|");
          break;
        }
        this.Delay(this.StatusDelayOnNotReady, cancelToken);
      }
      cancelToken.ThrowIfCancellationRequested();
      if (flag2)
        throw new CaptchaException(message);
      string str2 = message.Replace("OK|", "");
      return !string.IsNullOrEmpty(str2) ? str2 : throw new CaptchaException(CaptchaError.EmptyResponse);
    }

    public override string SolveHCaptcha(HCaptchaArgs args, CancellationToken cancelToken = default (CancellationToken))
    {
      this.ThrowIfApiKeyRequiredAndInvalid();
      args.Validate();
      NameValueCollection data = new NameValueCollection()
      {
        {
          "key",
          this.ApiKey
        },
        {
          "method",
          "hcaptcha"
        },
        {
          "sitekey",
          args.SiteKey
        },
        {
          "pageurl",
          args.PageUrl
        }
      };
      if (this.Proxy.IsValid)
      {
        data.Add("proxy", this.Proxy.Address);
        data.Add("proxytype", this.Proxy.Type.ToString());
      }
      string message = "unknown";
      bool flag1 = true;
      for (int index = 0; (long) index < (long) this.UploadRetries; ++index)
      {
        cancelToken.ThrowIfCancellationRequested();
        message = Encoding.UTF8.GetString(this.Http.UploadValues("http://" + this.Host + "/in.php", data));
        if (!message.Contains("ERROR_NO_SLOT_AVAILABLE"))
        {
          flag1 = !message.Contains("OK|");
          break;
        }
        this.Delay(this.UploadDelayOnNoSlotAvailable, cancelToken);
      }
      if (flag1)
        throw new CaptchaException(message);
      string str1 = message.Replace("OK|", "").Trim();
      bool flag2 = true;
      this.Delay(this.BeforeStatusCheckingDelay, cancelToken);
      for (int index = 0; (long) index < (long) this.StatusRetries; ++index)
      {
        message = this.Http.DownloadString("http://" + this.Host + "/res.php?key=" + this.ApiKey + "&action=get&id=" + str1);
        if (!message.Contains("CAPCHA_NOT_READY"))
        {
          flag2 = !message.Contains("OK|");
          break;
        }
        this.Delay(this.StatusDelayOnNotReady, cancelToken);
      }
      cancelToken.ThrowIfCancellationRequested();
      if (flag2)
        throw new CaptchaException(message);
      string str2 = message.Replace("OK|", "");
      return !string.IsNullOrEmpty(str2) ? str2 : throw new CaptchaException(CaptchaError.EmptyResponse);
    }
  }
}
