﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.Captcha.Classic.CaptchaException
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System;

#nullable disable
namespace Leaf.xNet.Captcha.Classic
{
  public class CaptchaException : Exception
  {
    public readonly CaptchaError Error;
    private new readonly string _message;

    public override string Message
    {
      get => this.Error != CaptchaError.CustomMessage ? this.Error.ToString() : this._message;
    }

    public CaptchaException(string message)
    {
      if (string.IsNullOrEmpty(message))
      {
        this.Error = CaptchaError.Unknown;
      }
      else
      {
        this._message = message;
        this.Error = CaptchaError.CustomMessage;
      }
    }

    public CaptchaException(CaptchaError error) => this.Error = error;
  }
}
