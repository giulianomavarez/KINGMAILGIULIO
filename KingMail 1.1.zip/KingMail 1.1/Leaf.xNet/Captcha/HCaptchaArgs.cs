﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.Captcha.HCaptchaArgs
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System;

#nullable disable
namespace Leaf.xNet.Captcha
{
  public class HCaptchaArgs
  {
    public readonly string SiteKey;
    public readonly string PageUrl;

    public HCaptchaArgs(string siteKey, string pageUrl)
    {
      this.SiteKey = siteKey;
      this.PageUrl = pageUrl;
    }

    public virtual void Validate()
    {
      this.MustBeFilled("SiteKey", this.SiteKey);
      this.MustBeFilled("PageUrl", this.PageUrl);
    }

    protected void MustBeFilled(string name, string value)
    {
      Type type = this.GetType();
      if (string.IsNullOrEmpty(value))
        throw new ArgumentException(string.Format("Invalid argument: \"{0}\" = {1} when called \"{2}.{3}\"", (object) name, (object) (value ?? "null"), (object) type, (object) "Validate"), name);
    }
  }
}
