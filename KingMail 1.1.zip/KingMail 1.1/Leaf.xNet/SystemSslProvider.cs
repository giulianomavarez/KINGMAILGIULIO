﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.SystemSslProvider
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System;
using System.IO;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;

#nullable disable
namespace Leaf.xNet
{
  public class SystemSslProvider : ISslProvider
  {
    public bool Disposable => true;

    public RemoteCertificateValidationCallback SslCertificateValidatorCallback { get; set; }

    public string Host { get; set; }

    public SslProtocols SslProtocols { get; set; } = SslProtocols.Tls | SslProtocols.Tls11 | SslProtocols.Tls12;

    public X509CertificateCollection ClientCertificates { get; set; }

    public Stream Initialize(Uri address, NetworkStream networkStream)
    {
      SslStream sslStream = new SslStream((Stream) networkStream, false, this.SslCertificateValidatorCallback ?? Http.AcceptAllCertificationsCallback, (LocalCertificateSelectionCallback) null);
      string targetHost = (!string.IsNullOrEmpty(this.Host) ? this.Host : address.Host).TrimEnd('.');
      sslStream.AuthenticateAsClient(targetHost, this.ClientCertificates, this.SslProtocols, false);
      return (Stream) sslStream;
    }
  }
}
