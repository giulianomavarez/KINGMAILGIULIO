﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.ProxyException
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System;
using System.Runtime.Serialization;

#nullable disable
namespace Leaf.xNet
{
  [Serializable]
  public sealed class ProxyException : NetException
  {
    public ProxyClient ProxyClient { get; }

    public ProxyException()
      : this(Resources.ProxyException_Default)
    {
    }

    public ProxyException(string message, Exception innerException = null)
      : base(message, innerException)
    {
    }

    public ProxyException(string message, ProxyClient proxyClient, Exception innerException = null)
      : base(message, innerException)
    {
      this.ProxyClient = proxyClient;
    }

    public ProxyException(SerializationInfo serializationInfo, StreamingContext streamingContext)
      : base(serializationInfo, streamingContext)
    {
    }
  }
}
