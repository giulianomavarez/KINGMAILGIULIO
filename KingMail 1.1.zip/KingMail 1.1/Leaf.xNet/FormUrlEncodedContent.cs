﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.FormUrlEncodedContent
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System;
using System.Collections.Generic;
using System.Text;

#nullable disable
namespace Leaf.xNet
{
  public class FormUrlEncodedContent : BytesContent
  {
    public FormUrlEncodedContent(
      IEnumerable<KeyValuePair<string, string>> content,
      bool valuesUnescaped = false,
      bool keysUnescaped = false)
    {
      if (content == null)
        throw new ArgumentNullException(nameof (content));
      this.Init(Http.ToQueryString(content, valuesUnescaped, keysUnescaped));
    }

    public FormUrlEncodedContent(RequestParams rp)
    {
      if (rp == null)
        throw new ArgumentNullException(nameof (rp));
      this.Init(rp.Query);
    }

    private void Init(string content)
    {
      this.Content = Encoding.ASCII.GetBytes(content);
      this.Offset = 0;
      this.Count = this.Content.Length;
      this.MimeContentType = "application/x-www-form-urlencoded";
    }
  }
}
