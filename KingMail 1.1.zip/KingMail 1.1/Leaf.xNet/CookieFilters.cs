﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.CookieFilters
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System;

#nullable disable
namespace Leaf.xNet
{
  public static class CookieFilters
  {
    public static bool Enabled { get; set; } = true;

    public static bool Trim { get; set; } = true;

    public static bool Path { get; set; } = true;

    public static bool CommaEndingValue { get; set; } = true;

    public static string Filter(string rawCookie)
    {
      return CookieFilters.Enabled ? rawCookie.TrimWhitespace().FilterPath().FilterInvalidExpireYear().FilterCommaEndingValue() : rawCookie;
    }

    public static string FilterDomain(string domain)
    {
      if (string.IsNullOrWhiteSpace(domain))
        return (string) null;
      domain = domain.Trim('\t', '\n', '\r', ' ');
      return ((domain.Length <= 1 ? 0 : (domain[0] == '.' ? 1 : 0)) & (domain.IndexOf('.', 1) == -1 ? 1 : 0)) == 0 ? domain : domain.Substring(1);
    }

    private static string TrimWhitespace(this string rawCookie)
    {
      return CookieFilters.Trim ? rawCookie.Trim() : rawCookie;
    }

    public static string NormalizePathValue(string cookiePathValue)
    {
      if (string.IsNullOrEmpty(cookiePathValue))
        return cookiePathValue;
      string str = cookiePathValue.Trim();
      int length = str.Length;
      switch (length)
      {
        case 0:
          return string.Empty;
        case 1:
          return str;
        default:
          char ch1 = str[0];
          char ch2 = str[length - 1];
          if (ch1 == '"' && ch2 == '"')
            return str.Trim('"');
          if (ch1 != '\'' || ch2 != '\'')
            return str;
          return str.Trim('\'');
      }
    }

    private static string FilterPath(this string rawCookie)
    {
      if (!CookieFilters.Path)
        return rawCookie;
      int num1 = rawCookie.IndexOf("path=/", 0, StringComparison.OrdinalIgnoreCase);
      if (num1 == -1)
        return rawCookie;
      int num2 = num1 + "path=/".Length;
      if (num2 >= rawCookie.Length - 1 || rawCookie[num2] == ';')
        return rawCookie;
      int num3 = rawCookie.IndexOf(';', num2);
      if (num3 == -1)
        num3 = rawCookie.Length;
      return rawCookie.Remove(num2, num3 - num2);
    }

    private static string FilterCommaEndingValue(this string rawCookie)
    {
      if (!CookieFilters.CommaEndingValue)
        return rawCookie;
      int num1 = rawCookie.IndexOf('=');
      if (num1 == -1 || num1 >= rawCookie.Length - 1)
        return rawCookie;
      int num2 = rawCookie.IndexOf(';', num1 + 1);
      if (num2 == -1)
        num2 = rawCookie.Length - 1;
      int num3 = num2 - 1;
      return rawCookie[num3] == ',' ? rawCookie.Remove(num3, 1).Insert(num3, "%2C") : rawCookie;
    }

    private static string FilterInvalidExpireYear(this string rawCookie)
    {
      int num1 = rawCookie.IndexOf("expires=", StringComparison.OrdinalIgnoreCase);
      if (num1 == -1)
        return rawCookie;
      int startIndex1 = num1 + "expires=".Length;
      int num2 = rawCookie.IndexOf(';', startIndex1);
      if (num2 == -1)
        num2 = rawCookie.Length;
      int num3 = rawCookie.Substring(startIndex1, num2 - startIndex1).IndexOf("9999", StringComparison.Ordinal);
      if (num3 == -1)
        return rawCookie;
      int startIndex2 = num3 + (startIndex1 + "9999".Length - 1);
      return rawCookie.Remove(startIndex2, 1).Insert(startIndex2, "8");
    }
  }
}
