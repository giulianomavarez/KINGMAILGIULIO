﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.Socks4ProxyClient
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;

#nullable disable
namespace Leaf.xNet
{
  public class Socks4ProxyClient : ProxyClient
  {
    protected const int DefaultPort = 1080;
    protected const byte VersionNumber = 4;
    private const byte CommandConnect = 1;
    protected const byte CommandReplyRequestGranted = 90;
    private const byte CommandReplyRequestRejectedOrFailed = 91;
    private const byte CommandReplyRequestRejectedCannotConnectToIdentd = 92;
    private const byte CommandReplyRequestRejectedDifferentIdentd = 93;

    public Socks4ProxyClient()
      : this((string) null)
    {
    }

    public Socks4ProxyClient(string host, int port = 1080)
      : this(host, port, string.Empty)
    {
    }

    public Socks4ProxyClient(string host, int port, string username)
      : base(ProxyType.Socks4, host, port, username, (string) null)
    {
    }

    public static Socks4ProxyClient Parse(string proxyAddress)
    {
      return ProxyClient.Parse(ProxyType.Socks4, proxyAddress) as Socks4ProxyClient;
    }

    public static bool TryParse(string proxyAddress, out Socks4ProxyClient result)
    {
      ProxyClient result1;
      if (!ProxyClient.TryParse(ProxyType.Socks4, proxyAddress, out result1))
      {
        result = (Socks4ProxyClient) null;
        return false;
      }
      result = result1 as Socks4ProxyClient;
      return true;
    }

    public override TcpClient CreateConnection(
      string destinationHost,
      int destinationPort,
      TcpClient tcpClient = null)
    {
      this.CheckState();
      switch (destinationHost)
      {
        case null:
          throw new ArgumentNullException(nameof (destinationHost));
        case "":
          throw ExceptionHelper.EmptyString(nameof (destinationHost));
        default:
          if (!ExceptionHelper.ValidateTcpPort(destinationPort))
            throw ExceptionHelper.WrongTcpPort(nameof (destinationHost));
          TcpClient connection = tcpClient ?? this.CreateConnectionToProxy();
          try
          {
            this.SendCommand(connection.GetStream(), (byte) 1, destinationHost, destinationPort);
          }
          catch (Exception ex)
          {
            connection.Close();
            switch (ex)
            {
              case IOException _:
              case SocketException _:
                throw this.NewProxyException(Resources.ProxyException_Error, ex);
              default:
                throw;
            }
          }
          return connection;
      }
    }

    private void SendCommand(
      NetworkStream nStream,
      byte command,
      string destinationHost,
      int destinationPort)
    {
      byte[] ipAddressBytes = this.GetIpAddressBytes(destinationHost);
      byte[] portBytes = Socks4ProxyClient.GetPortBytes(destinationPort);
      byte[] numArray1 = string.IsNullOrEmpty(this._username) ? new byte[0] : Encoding.ASCII.GetBytes(this._username);
      byte[] buffer1 = new byte[9 + numArray1.Length];
      buffer1[0] = (byte) 4;
      buffer1[1] = command;
      byte[] numArray2 = buffer1;
      portBytes.CopyTo((Array) numArray2, 2);
      byte[] numArray3 = buffer1;
      ipAddressBytes.CopyTo((Array) numArray3, 4);
      numArray1.CopyTo((Array) buffer1, 8);
      buffer1[8 + numArray1.Length] = (byte) 0;
      nStream.Write(buffer1, 0, buffer1.Length);
      byte[] buffer2 = new byte[8];
      nStream.Read(buffer2, 0, buffer2.Length);
      byte command1 = buffer2[1];
      if (command1 == (byte) 90)
        return;
      this.HandleCommandError(command1);
    }

    private byte[] GetIpAddressBytes(string destinationHost)
    {
      IPAddress address;
      if (IPAddress.TryParse(destinationHost, out address))
        return address.GetAddressBytes();
      try
      {
        IPAddress[] hostAddresses = Dns.GetHostAddresses(destinationHost);
        if (hostAddresses.Length != 0)
          address = hostAddresses[0];
      }
      catch (Exception ex)
      {
        switch (ex)
        {
          case SocketException _:
          case ArgumentException _:
            throw new ProxyException(string.Format(Resources.ProxyException_FailedGetHostAddresses, (object) destinationHost), (ProxyClient) this, ex);
          default:
            throw;
        }
      }
      return address.GetAddressBytes();
    }

    protected static byte[] GetPortBytes(int port)
    {
      return new byte[2]
      {
        (byte) (port / 256),
        (byte) (port % 256)
      };
    }

    protected void HandleCommandError(byte command)
    {
      string str;
      switch (command)
      {
        case 91:
          str = Resources.Socks4_CommandReplyRequestRejectedOrFailed;
          break;
        case 92:
          str = Resources.Socks4_CommandReplyRequestRejectedCannotConnectToIdentd;
          break;
        case 93:
          str = Resources.Socks4_CommandReplyRequestRejectedDifferentIdentd;
          break;
        default:
          str = Resources.Socks_UnknownError;
          break;
      }
      throw new ProxyException(string.Format(Resources.ProxyException_CommandError, (object) str, (object) this.ToString()), (ProxyClient) this);
    }
  }
}
