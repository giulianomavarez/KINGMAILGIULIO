﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.Randomizer
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System;
using System.Security.Cryptography;

#nullable disable
namespace Leaf.xNet
{
  public static class Randomizer
  {
    private static readonly RNGCryptoServiceProvider Generator = new RNGCryptoServiceProvider();
    [ThreadStatic]
    private static Random _rand;

    private static Random Generate()
    {
      byte[] data = new byte[4];
      Randomizer.Generator.GetBytes(data);
      return new Random(BitConverter.ToInt32(data, 0));
    }

    public static Random Instance => Randomizer._rand ?? (Randomizer._rand = Randomizer.Generate());
  }
}
