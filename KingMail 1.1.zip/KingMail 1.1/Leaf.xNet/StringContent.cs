﻿// Decompiled with JetBrains decompiler
// Type: Leaf.xNet.StringContent
// Assembly: Leaf.xNet, Version=7.0.54.0, Culture=neutral, PublicKeyToken=null
// MVID: 29E6055E-8BA2-4CEA-B840-DBDC2523273F
// Assembly location: C:\Users\Giulio\Downloads\Telegram Desktop\KingMail 1.1\KingMail 1.1\Leaf.xNet.dll

using System;
using System.Text;

#nullable disable
namespace Leaf.xNet
{
  public class StringContent : BytesContent
  {
    public StringContent(string content)
      : this(content, Encoding.UTF8)
    {
    }

    public StringContent(string content, Encoding encoding)
    {
      if (content == null)
        throw new ArgumentNullException(nameof (content));
      this.Content = encoding?.GetBytes(content) ?? throw new ArgumentNullException(nameof (encoding));
      this.Offset = 0;
      this.Count = this.Content.Length;
      this.MimeContentType = "text/plain";
    }
  }
}
